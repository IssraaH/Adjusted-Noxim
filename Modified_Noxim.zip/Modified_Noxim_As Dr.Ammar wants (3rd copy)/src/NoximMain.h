/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the declaration of the top-level of Noxim
 */

#ifndef __NOXIMMAIN_H__
#define __NOXIMMAIN_H__

#include <cassert>
#include <systemc.h>
#include <vector>
#include <queue>

using namespace std;

// Define the directions as numbers
#define DIRECTIONS             4                         
#define DIRECTION_NORTH        0
#define DIRECTION_EAST         1
#define DIRECTION_SOUTH        2
#define DIRECTION_WEST         3
#define DIRECTION_LOCAL        4
#define DIRECTION_UP           5 			//add by ammar

// Generic not reserved resource
#define NOT_RESERVED          -2

// To mark invalid or non exhistent values
#define NOT_VALID             -1

// themal management mode <Nizar>

#define THERMAL                        0
#define NO_THERMAL                     1

// To specify wheather there will be dark PE (turned off)
#define NO_DARK_SCI                    0
#define DARK_SCI                       1


// Routing algorithms
#define ROUTING_XY             0
#define ROUTING_WEST_FIRST     1
#define ROUTING_NORTH_LAST     2
#define ROUTING_NEGATIVE_FIRST 3
#define ROUTING_ODD_EVEN       4
#define ROUTING_DYAD           5
#define ROUTING_FULLY_ADAPTIVE 8
#define ROUTING_TABLE_BASED    9
//#define ROUTING_ODD_EVEN_SW    10			//add by ammar
#define ROUTING_SPF	       11			//add by ammar
#define INVALID_ROUTING       -1

// Selection strategies
#define SEL_RANDOM             0
#define SEL_BUFFER_LEVEL       1
#define SEL_NOP                2
#define SEL_W_RANDOM	       3			//add by ammar
#define INVALID_SELECTION     -1

// Traffic distribution
#define TRAFFIC_RANDOM         0
#define TRAFFIC_TRANSPOSE1     1
#define TRAFFIC_TRANSPOSE2     2
#define TRAFFIC_HOTSPOT        3
#define TRAFFIC_TABLE_BASED    4
#define TRAFFIC_BIT_REVERSAL   5
#define TRAFFIC_SHUFFLE        6
#define TRAFFIC_BUTTERFLY      7
#define INVALID_TRAFFIC       -1

// Verbosity levels
#define VERBOSE_OFF            0 
#define VERBOSE_LOW            1
#define VERBOSE_MEDIUM         2
#define VERBOSE_HIGH           3

// Broadcast/Multicast Modes
#define UNICAST			0 
#define HYBRID_ARCH		1
#define VCT			2
#define FANOUT			3

// Global arbiteration type
#define PERIOD_ARB			0 
#define HOLD_RR_ARB			1
#define HOLD_TIME_ARB			2
#define DISTRIBUTED_ARB			3

// Benchmark type
#define B_NORMAL			0 
#define B_MULTICAST			1


// Default configuration can be overridden with command-line arguments
#define DEFAULT_VERBOSE_MODE               VERBOSE_OFF
#define DEFAULT_TRACE_MODE                       false
#define DEFAULT_TRACE_FILENAME                      ""
#define DEFAULT_MESH_DIM_X                           4
#define DEFAULT_MESH_DIM_Y                           4
#define DEFAULT_MESH_DIM_CHIP_X                      3           //Dr. Ammar and Issraa
#define DEFAULT_MESH_DIM_CHIP_Y                      3          //Dr. Ammar and Issraa
//#define DEFAULT_POWER_LINK_FLAG                      0       //Dr. Ammar and Issraa
#define DEFAULT_NO_C                                 0 		// add by ammar
#define DEFAULT_BUFFER_DEPTH                         3        //4   Ammar
#define DEFAULT_MAX_PACKET_SIZE                      14		
#define DEFAULT_MIN_PACKET_SIZE                      3		
#define DEFAULT_ROUTING_ALGORITHM           ROUTING_XY
#define DEFAULT_ROUTING_TABLE_FILENAME              ""
#define DEFAULT_SELECTION_STRATEGY          SEL_RANDOM
#define DEFAULT_PACKET_INJECTION_RATE             0.01
#define DEFAULT_PROBABILITY_OF_RETRANSMISSION     0.01
#define DEFAULT_TRAFFIC_DISTRIBUTION   TRAFFIC_RANDOM
#define DEFAULT_TRAFFIC_TABLE_FILENAME              ""
#define DEFAULT_RESET_TIME                        1000
#define DEFAULT_SIMULATION_TIME                  10000
#define DEFAULT_STATS_WARM_UP_TIME  DEFAULT_RESET_TIME
#define DEFAULT_DETAILED                         false
#define DEFAULT_DYAD_THRESHOLD                     0.6
#define DEFAULT_MAX_VOLUME_TO_BE_DRAINED             0
#define DEFAULT_Broadcast_RATE		             0			// add by ammar	
#define DEFAULT_Virtual_Channel		             1			// add by ammar	
#define DEFAULT_BROADCAST_MODE		       UNICAST			// add by ammar	
#define FREQ                			    2e9			// add by Ammar
#define NO_SIM                			    1			// add by Ammar number of NoC simulations (thermal sample periods)

// TODO by Fafa - this MUST be removed!!! Use only STL vectors instead!!!
#define MAX_STATIC_DIM 18
#define MAX_STATIC_VC 12//16							//changed by Ammar
#define MAX_VCT 1000//16							//changed by Ammar
// NoximFlitType -- Flit type enumeration
enum NoximFlitType {
    FLIT_TYPE_HEAD, FLIT_TYPE_BODY, FLIT_TYPE_TAIL
};

// NoximPayload -- Payload definition
struct NoximPayload {
    sc_uint<32> data;	// Bus for the data to be exchanged

    inline bool operator ==(const NoximPayload & payload) const {
	return (payload.data == data);
}};

// NoximFlit -- Flit definition

struct NoximFlit {
    int src_id;
    int dst_id;
    NoximFlitType flit_type;	// The flit type (FLIT_TYPE_HEAD, FLIT_TYPE_BODY, FLIT_TYPE_TAIL)
    int sequence_no;		// The sequence number of the flit inside the packet
    NoximPayload payload;	// Optional payload
    double timestamp;		// Unix timestamp at packet generation
    int hop_no;			// Current number of hops from source to destination
    bool MB;			// Broadcast bit						add by Ammar
    int VCID;			/// Virtual channel identifier to link op-to-ip VC		add by Ammar
    vector < bool > MAB;	// multicast address bit					add by Ammar
    bool VCTsetup;		// setup VCT header bit						add by Ammar
    bool VCT_ID;		// ID bit store in VCT to recognize eneryes updates		add by Ammar
    int  VCTentry;		//the enery number in VCT (table)				add by Ammar
    int Tag;			// the tag for the distributed arbiteration 			add by Ammar
    int size;			// the size of the packet in case ==1				add by Ammar
    int delay_offchip_link;      // delay off_chip                                         Dr. Ammar and Issraa
   bool power_link_flag;         // The flag that indicate the routers on the edge if=1    Dr. Ammar and Issraa

    inline bool operator ==(const NoximFlit & flit) const {
	return (flit.src_id == src_id && flit.dst_id == dst_id
		&& flit.flit_type == flit_type
		&& flit.sequence_no == sequence_no
		&& flit.payload == payload && flit.timestamp == timestamp
		&& flit.hop_no == hop_no 
		&& flit.MB == MB && flit.VCID ==VCID && flit.MAB == MAB
		&& flit.VCTsetup ==VCTsetup   && flit.VCT_ID ==VCT_ID
		&& flit.VCTentry ==VCTentry  && flit.size == size  && flit.delay_offchip_link ==delay_offchip_link &&    flit.power_link_flag==power_link_flag);				//Ammar
}};

struct SWI_reserve{										//add by Ammar
	vector<int> Reserve_MAB;
	vector<int> Reserve_BM;

};

struct G_siganl {
	 //public:										//add by Ammar
	double req_id;
	int vc;
        inline bool operator ==(const G_siganl & grant_signal) const {
	return (grant_signal.req_id == req_id && grant_signal.vc == vc);	
}};

// NoximGlobalParams -- used to forward configuration to every sub-block
struct NoximGlobalParams {
    static int verbose_mode;
    static int trace_mode;
    static char trace_filename[128];
    static int mesh_dim_x;
    static int mesh_dim_y;
    static int mesh_dim_chip_x;                    // Dr. Ammar and Issraa
    static int mesh_dim_chip_y;                   // Dr. Ammar and Issraa
    //static bool power_link_flag;               // Dr. Ammar and Issraa
    static int buffer_depth;
    static int min_packet_size;
    static int max_packet_size;
    static int routing_algorithm;
    static char routing_table_filename[128];
    static int selection_strategy;
    static float packet_injection_rate;
    static float probability_of_retransmission;
    static int traffic_distribution;
    static char traffic_table_filename[128];
    static int simulation_time;
    static int stats_warm_up_time;
    static int rnd_generator_seed;
    static bool detailed;
    static vector <pair <int, double> > hotspots;
    static float dyad_threshold;
    static unsigned int max_volume_to_be_drained;
    static int SW_channel;					//add by ammar 
    static queue <NoximFlit> SW_Buf[2000];			//add by Ammar   
    static int SW_reserve[2000][MAX_STATIC_VC];			//add by Ammar  
    static int Broadcast_RATE;					//add by Ammar
    static int RF_Weight;					//add by Ammar
    static int VC_No;						//add by Ammar 
    static int BM_Mode;						//add by Ammar
    static vector<int> Reserve_BM;				//add by Ammar
    static vector<int> Reserve_MAB;				//add by Ammar
    static SWI_reserve SWI[MAX_STATIC_VC];			//add by Ammar
    static int Multicast;					//add by Ammar
    static int Master_node[MAX_STATIC_DIM];			//add by Ammar
    static int Arbitration_period;				//add by Ammar
    static int SWI_Free_slots[MAX_STATIC_DIM*MAX_STATIC_DIM][MAX_STATIC_VC];	//add by Ammar
    static int Arbitration_type;				//add by Ammar    
    static int Master_aloc;					//add by Ammar 
    static int EntryVCT;					//add by Ammar 
    static int BenchMark;					//add by Ammar 
    static double StopTime;					//add by Ammar
    static int TAG;						//add by ammar 
    static int Thermal;						//add by ammar 
    static int NoSample;					//add by ammar
    static int Dark;						//add by ammar
    static int Dark_pattren;						//add by ammar
    static bool Dark_PE[MAX_STATIC_DIM*MAX_STATIC_DIM];		//add by ammar
};


// NoximCoord -- XY coordinates type of the Tile inside the Mesh
class NoximCoord {
  public:
    int x;			// X coordinate
    int y;			// Y coordinate

    inline bool operator ==(const NoximCoord & coord) const {
	return (coord.x == x && coord.y == y);
}};

// NoximPacket -- Packet definition
struct NoximPacket {
    int src_id;
    int dst_id;
    double timestamp;		// SC timestamp at packet generation
    int size;
    int flit_left;		// Number of remaining flits inside the packet
    bool MB;			// Broadcast bit 						add by Ammar
    int VCID;			///vc id							add by Amamr
    vector < bool > MAB;	//Ammar multicast address bit					add by Ammar
    bool VCTsetup;		// setup VCT header bit						add by Ammar
    bool VCT_ID;		// ID bit store in VCT to recognize enteryes updates		add by Ammar
    int  VCTentry;		//the enery number in VCT (table)				add by Ammar
    vector < bool > MAB2;	//Ammar multicast address bit					add by Ammar

    // Constructors
    NoximPacket() { }
    NoximPacket(const int s, const int d, const double ts, const int sz,
		const bool B , const int v, const vector < bool > m, const bool VCTs,
		const bool VCTi ,const int VCTn, const vector < bool > m2)			//ammar
	 {	
		make(s, d, ts, sz, B, v,m, VCTs, VCTi, VCTn,m2);				
    	}

    void make(const int s, const int d, const double ts, const int sz, const bool B,
	      const int v, const vector < bool > m, const bool VCTs,const bool VCTi 
	     ,const int VCTn, const vector < bool > m2)		 				//ammar
    {													
	src_id = s;
	dst_id = d;
	timestamp = ts;
	size = sz;
	flit_left = sz;
	MB=B;
	VCID = v;										//ammar
	MAB = m;										//ammar
        VCTsetup = VCTs;									//ammar
	VCT_ID = VCTi;										//ammar
	VCTentry = VCTn;									//ammar
	MAB2 = m2;										//ammar
    }
};

// NoximRouteData -- data required to perform routing
struct NoximRouteData {
    int current_id;
    int src_id;
    int dst_id;
    int dir_in;			// direction from which the packet comes from
    bool MB;
    vector <bool> MAB;
    bool VCTsetup;
    bool VCT_ID;
    int VCTentry;
    int VC_in;			//VC for input port
};

struct NoximChannelStatus {
    int free_slots;		// occupied buffer slots
    bool available;		// 
    inline bool operator ==(const NoximChannelStatus & bs) const {
	return (free_slots == bs.free_slots && available == bs.available);
    };
};

// NoximNoP_data -- NoP Data definition
struct NoximNoP_data {
    int sender_id;
    NoximChannelStatus channel_status_neighbor[DIRECTIONS];

    inline bool operator ==(const NoximNoP_data & nop_data) const {
	return (sender_id == nop_data.sender_id &&
		nop_data.channel_status_neighbor[0] ==
		channel_status_neighbor[0]
		&& nop_data.channel_status_neighbor[1] ==
		channel_status_neighbor[1]
		&& nop_data.channel_status_neighbor[2] ==
		channel_status_neighbor[2]
		&& nop_data.channel_status_neighbor[3] ==
		channel_status_neighbor[3]);
    };
};



// Output overloading

inline ostream & operator <<(ostream & os, const NoximFlit & flit)
{

    if (NoximGlobalParams::verbose_mode == VERBOSE_HIGH) {

	os << "### FLIT ###" << endl;
	os << "Source Tile[" << flit.src_id << "]" << endl;
	os << "Destination Tile[" << flit.dst_id << "]" << endl;
	switch (flit.flit_type) {
	case FLIT_TYPE_HEAD:
	    os << "Flit Type is HEAD" << endl;
	    break;
	case FLIT_TYPE_BODY:
	    os << "Flit Type is BODY" << endl;
	    break;
	case FLIT_TYPE_TAIL:
	    os << "Flit Type is TAIL" << endl;
	    break;
	}
	os << "Sequence no. " << flit.sequence_no << endl;
	os << "Payload printing not implemented (yet)." << endl;
	os << "Unix timestamp at packet generation " << flit.
	    timestamp << endl;
	os << "Total number of hops from source to destination is " <<
	    flit.hop_no << endl;
    } else {
	os << "[type: ";
	switch (flit.flit_type) {
	case FLIT_TYPE_HEAD:
	    os << "H";
	    break;
	case FLIT_TYPE_BODY:
	    os << "B";
	    break;
	case FLIT_TYPE_TAIL:
	    os << "T";
	    break;
	}

	os << ", seq: " << flit.sequence_no << ", " << flit.src_id << "-->" << flit.dst_id << "]";
    }

    return os;
}

inline ostream & operator <<(ostream & os, const G_siganl & grant)
{

	os << "VC: " << grant.vc << " Req ID: " << grant.req_id;
    return os;
}

inline ostream & operator <<(ostream & os,
			     const NoximChannelStatus & status)
{
    char msg;
    if (status.available)
	msg = 'A';
    else
	msg = 'N';
    os << msg << "(" << status.free_slots << ")";
    return os;
}

inline ostream & operator <<(ostream & os, const NoximNoP_data & NoP_data)
{
    os << "      NoP data from [" << NoP_data.sender_id << "] [ ";

    for (int j = 0; j < DIRECTIONS; j++)
	os << NoP_data.channel_status_neighbor[j] << " ";

    cout << "]" << endl;
    return os;
}

inline ostream & operator <<(ostream & os, const NoximCoord & coord)
{
    os << "(" << coord.x << "," << coord.y << ")";

    return os;
}

// Trace overloading

inline void sc_trace(sc_trace_file * &tf, const NoximFlit & flit, string & name)
{
    sc_trace(tf, flit.src_id, name + ".src_id");
    sc_trace(tf, flit.dst_id, name + ".dst_id");
    sc_trace(tf, flit.sequence_no, name + ".sequence_no");
    sc_trace(tf, flit.timestamp, name + ".timestamp");
    sc_trace(tf, flit.hop_no, name + ".hop_no");
}

inline void sc_trace(sc_trace_file * &tf, const NoximNoP_data & NoP_data, string & name)
{
    sc_trace(tf, NoP_data.sender_id, name + ".sender_id");
}

inline void sc_trace(sc_trace_file * &tf, const NoximChannelStatus & bs, string & name)
{
    sc_trace(tf, bs.free_slots, name + ".free_slots");
    sc_trace(tf, bs.available, name + ".available");
}

// Misc common functions

inline NoximCoord id2Coord(int id)
{
    NoximCoord coord;

    coord.x = id % NoximGlobalParams::mesh_dim_x;
    coord.y = id / NoximGlobalParams::mesh_dim_x;

    assert(coord.x < NoximGlobalParams::mesh_dim_x);
    assert(coord.y < NoximGlobalParams::mesh_dim_y);

    return coord;

}

inline int coord2Id(const NoximCoord & coord)
{
    int id = (coord.y * NoximGlobalParams::mesh_dim_x) + coord.x;

    assert(id < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);

    return id;
}

inline vector<bool> Integer2Bin(const unsigned long long i)
{
	assert(i < 2^(NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y));
	vector<bool> b;
	int a=i;
	while (a>0)
	{
		b.push_back(a%2);
		a=a/2;
	}
	if(b.size()!= (NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y))
		for(int j=b.size(); j<NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; j++)
			b.push_back(0);

	/*cout<<"Integer2Bin: binary number: ";
	for(int j=0; j<b.size(); j++)
		{
		cout<<b[j];
		}
	cout<<" integer: "<<i<<endl;*/

    return b;
}

inline unsigned long long Bin2Integ(const vector<bool> & b)
{
    	unsigned long long i=0;
	//cout<<"Bin2Integ: binary number: ";
    	assert(b.size() == NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
	unsigned long long w=1;
    	for(int j=0; j<b.size(); j++)
		{
		//i=i +(((int) pow(2.0,j))*b[j]);
		i=i +(w*b[j]);
		w=w*2;
		//cout<<b[j];
		}
	//cout<<" integer: "<<i<<endl;
    return i;
}

inline vector <bool> VectorOR(const vector < bool > & b, const vector < bool > & a)
{
	cout<<"Bin2Integ: binary number: ";
	vector < bool > c;
    	assert(b.size() == NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
	assert(a.size() == NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
    	for(int j=0; j < b.size(); j++)
		{
			if(b[j] || a[j])
				c[j] = 1;
			else
				c[j]=0;
		}
	cout<<" integer: "<<b.size()<<endl;
    return c;
}



inline int MABsize(const vector<bool> & b)
{
    	int i=0;
	//cout<<"Bin2Integ: binary number: ";
    	assert(b.size() == NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
    	for(int j=0; j<b.size(); j++)
		{
		i=i +b[j];
		//cout<<b[j];
		}
	//cout<<" integer: "<<i<<endl;
    return i;
}

inline int Ones(const vector<bool> & b, int size)
{
    	int i=0;
	//cout<<"Bin2Integ: binary number: ";
    	assert(b.size() == size);
    	for(int j=0; j<b.size(); j++)
		{
		i=i +b[j];
		//cout<<b[j];
		}
	//cout<<" integer: "<<i<<endl;
    return i;
}

inline int Need2Drain(const vector<bool> & b)
{
    	int i=0;
	int k=0;
	//cout<<"Bin2Integ: binary number: ";
    	assert(b.size() == NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
    	for(int j=0; j<b.size(); j++)
		{
		if(b[j]==1)
			{
			i=j;
			k++;
			}	
		}
	if (k>1)
	    return -1;
	else
	    return i;
}

inline bool set_SWI()						//add by Ammar
{
	//cout<<" set channel 1"<<endl; 	
	int channel=NoximGlobalParams::SW_channel;
	if(NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB && NoximGlobalParams::SW_channel>0)
        	NoximGlobalParams::TAG = NoximGlobalParams::SW_channel;
	//int res_chan[channel];
	double size=NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y;
	if((channel > 0)&&(NoximGlobalParams::Master_aloc==0))
	{/*
		//if(size!=36)
		NoximGlobalParams::Master_node[0]=0;
		for(int i=1; i<channel; i++)
		{
		NoximGlobalParams::Master_node[i]=((int)((size/channel)+5)*i) % ((int)size);
	 	for(int j=i-1 ; j>=0; j--)
			{
			if(NoximGlobalParams::Master_node[i]==NoximGlobalParams::Master_node[j])
				NoximGlobalParams::Master_node[i]=((int)((size/channel)+7)*i) % ((int)size);
			}
		//cout<<"channel "<<i<<" node "<<NoximGlobalParams::Master_node[i]<<endl;
		}
	for(int i=1; i<channel; i++)
	 for(int j=i-1 ; j>=0; j--)
		if(NoximGlobalParams::Master_node[i]==NoximGlobalParams::Master_node[j])
			cout<<"error"<<endl<<endl<<endl<<endl<<endl<<endl<<endl;*/
	if(channel == 4 && size ==36){
		NoximGlobalParams::Master_node[0]=28;
		NoximGlobalParams::Master_node[1]=7;
		NoximGlobalParams::Master_node[2]=10;
		NoximGlobalParams::Master_node[3]=25;
		}
	else if(channel == 4 && size ==24){
		NoximGlobalParams::Master_node[0]=16;
		NoximGlobalParams::Master_node[1]=7;
		NoximGlobalParams::Master_node[2]=3;
		NoximGlobalParams::Master_node[3]=20;
		}
	else if(channel == 4 && size ==25){
		NoximGlobalParams::Master_node[0]=8;
		NoximGlobalParams::Master_node[1]=23;
		NoximGlobalParams::Master_node[2]=16;
		NoximGlobalParams::Master_node[3]=1;
		}
	else if(channel == 2&& size ==24)
		{
		NoximGlobalParams::Master_node[0]=7;
		NoximGlobalParams::Master_node[1]=16;
		}
	else if(channel == 3&& size ==24)
		{
		NoximGlobalParams::Master_node[0]=6;
		NoximGlobalParams::Master_node[1]=10;
		NoximGlobalParams::Master_node[2]=14;
		}
	else if(channel == 5 && size ==24)
		{
		NoximGlobalParams::Master_node[0]=2;
		NoximGlobalParams::Master_node[1]=15;
		NoximGlobalParams::Master_node[2]=11;
		NoximGlobalParams::Master_node[3]=19;
		NoximGlobalParams::Master_node[4]=6;
		}
	else if(channel == 5 && size ==64)
		{
		NoximGlobalParams::Master_node[0]=35;
		NoximGlobalParams::Master_node[1]=9;
		NoximGlobalParams::Master_node[2]=54;
		NoximGlobalParams::Master_node[3]=14;
		NoximGlobalParams::Master_node[4]=57;
		}
	else if(channel == 5 && size ==80)
		{
		NoximGlobalParams::Master_node[0]=45;
		NoximGlobalParams::Master_node[1]=19;
		NoximGlobalParams::Master_node[2]=64;
		NoximGlobalParams::Master_node[3]=24;
		NoximGlobalParams::Master_node[4]=67;
		}
	else if(channel == 5 && size ==49)
		{
		NoximGlobalParams::Master_node[0]=8;
		NoximGlobalParams::Master_node[1]=31;
		NoximGlobalParams::Master_node[2]=36;
		NoximGlobalParams::Master_node[3]=19;
		NoximGlobalParams::Master_node[4]=40;
		}
	else if(channel == 4 && size ==49)
		{
		NoximGlobalParams::Master_node[0]=29;
		NoximGlobalParams::Master_node[1]=8;
		NoximGlobalParams::Master_node[2]=19;
		NoximGlobalParams::Master_node[3]=40;
		}
	else if(channel == 6 && size ==100)
		{
		NoximGlobalParams::Master_node[0]=48;
		NoximGlobalParams::Master_node[1]=20;
		NoximGlobalParams::Master_node[2]=16;
		NoximGlobalParams::Master_node[3]=76;
		NoximGlobalParams::Master_node[4]=81;
		NoximGlobalParams::Master_node[5]=44;
		}
	else if(channel == 8 && size ==144)
		{
		NoximGlobalParams::Master_node[0]=18;
		NoximGlobalParams::Master_node[1]=109;
		NoximGlobalParams::Master_node[2]=51;
		NoximGlobalParams::Master_node[3]=33;
		NoximGlobalParams::Master_node[4]=129;
		NoximGlobalParams::Master_node[5]=124;
		NoximGlobalParams::Master_node[6]=12;
		NoximGlobalParams::Master_node[7]=80;
		}
	else if(channel == 3 && size ==16)
		{
		NoximGlobalParams::Master_node[0]=5;
		NoximGlobalParams::Master_node[1]=7;
		NoximGlobalParams::Master_node[2]=10;
		}
	else if(channel == 2 && size ==9)
		{
		NoximGlobalParams::Master_node[0]=6;
		NoximGlobalParams::Master_node[1]=1;
		}
	else if(channel == 1 && size ==9)			//for testing
		{
		NoximGlobalParams::Master_node[0]=4;

		}
	else
		cout <<"fatel error SWI no mappeing available !!!!!!!!!!!!!!!!!!!!!!!"<<endl;
	}
/////////sorting the SWI nodes to avoid diffrent results for the same nodes 
	int temp;	
	for(int i=0; i<channel; i++)
	   for(int j=0; j<channel-1; j++)
	   {
		if(NoximGlobalParams::Master_node[j]>NoximGlobalParams::Master_node[j+1])
		{
			temp=NoximGlobalParams::Master_node[j];
			NoximGlobalParams::Master_node[j]=NoximGlobalParams::Master_node[j+1];
			NoximGlobalParams::Master_node[j+1]=temp;
		}
	   }	

//for(int i=0; i<channel; i++)
  //cout<<"channel "<<i<<" node "<<NoximGlobalParams::Master_node[i]<<endl;

//cout<<" set channel 2"<<endl;
	return 1;
}

inline int check_reserv_SW(int node_ID)						//add by Ammar
{
	//cout<<" check res channel 1"<<endl;
	int channel=NoximGlobalParams::SW_channel;
	//int res_chan[channel];
	int j;
	j=-1;
        
	for (int i=0; i<channel;i++)
		{
		if(node_ID == NoximGlobalParams::Master_node[i])
		  j =i;
	 	 // cout<<"X1  ";
		}
	//cout <<j<<" check_reserv_SW "<<channel<<res_chan[0]<<"node ID: "<<node_ID<<endl;
	//cout<<" check res channel 1"<<endl;
	return j;
}

// to avoid deadlock these 2 function allow one broadcast to use the surface wave at time or 2 multicasts or more if there is no shared multicasting group members

/*inline int reserv_SW_BM(int node_ID, vector<bool> MAB)						//add by Ammar
{
	//cout<<" VC no:"<<NoximGlobalParams::VC_No<<endl;
   for(int v=0; v<NoximGlobalParams::VC_No; v++ )
   {
	//cout<<"start reserv size: "<<NoximGlobalParams::SWI[v].Reserve_BM.size()<<endl;
	if (NoximGlobalParams::SWI[v].Reserve_BM.empty())
	{
	        cout<<"reserving ["<<0<<"]["<<v<<"] for node: "<<node_ID<<endl;
		NoximGlobalParams::SWI[v].Reserve_BM.push_back(node_ID);
		NoximGlobalParams::SWI[v].Reserve_MAB.push_back(Bin2Integ(MAB));
		return v;
	}
	else
	{
	    for(int i=0 ; i< NoximGlobalParams::SWI[v].Reserve_BM.size();i++)
		{if(NoximGlobalParams::SWI[v].Reserve_BM[i] == node_ID)
			{
			//cout<<"already reserved VC: "<<v<<" Node: "<<node_ID<<endl;
			return v;			//already reserved	
			}
		}
	    if(NoximGlobalParams::Multicast != 0)
	    {
		bool X=0;				//flag of multicast shared sinks nodes if =1 do not reserve
		//cout<<"check for shared members, node: "<<node_ID<<" MAB: "<< Bin2Integ(MAB)<<
		//"reserve size: "<<NoximGlobalParams::SWI[v].Reserve_BM.size()<<endl;
		for(int i=0 ; i< NoximGlobalParams::SWI[v].Reserve_BM.size();i++)
			{
			vector <bool> Reserve_MAB= Integer2Bin(NoximGlobalParams::SWI[v].Reserve_MAB[i]);
			//cout<<"check MAB["<<i<<"]["<<v<<"] "<<NoximGlobalParams::SWI[v].Reserve_MAB[i]<<endl;
			for (int j=0; j<NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_]_y;j++)
				{if((Reserve_MAB[j] ==1) && (MAB[j]==1) )
					{
					X=1;
					//cout<<"find shared member reserved MAB:"<<NoximGlobalParams::SWI[v].Reserve_MAB
					//[i]<<" and request MAB: "<<Bin2Integ(MAB)<<endl;
					}
				}
			}
		if(X==0)			//if multicasting groups does not has shared members
		{
		   cout<<"reserving ["<<NoximGlobalParams::SWI[v].Reserve_BM.size()-1
		       <<"]["<<v<<"] for node: "<<node_ID<<endl;
		   NoximGlobalParams::SWI[v].Reserve_BM.push_back(node_ID);
		   NoximGlobalParams::SWI[v].Reserve_MAB.push_back(Bin2Integ(MAB));
		   return v;
		} 
	    }			
	}//end else not empty
      }//end for of VC	

    return NOT_RESERVED;
}*/

inline int release_SW_BM(int node_ID)						//add by Ammar
{

   for(int v=0; v<NoximGlobalParams::VC_No; v++ )
   {
	//cout<<"start release size now: "<<NoximGlobalParams::SWI[v].Reserve_BM.size()<<endl;
    	if(NoximGlobalParams::SWI[v].Reserve_BM.empty())
		return v;
	else 
	{								//search for reserving node to remove it
	    for(int v=0; v<NoximGlobalParams::VC_No; v++ )
   	    {
		for(int i=0 ; i< NoximGlobalParams::SWI[v].Reserve_BM.size();i++)
			if(NoximGlobalParams::SWI[v].Reserve_BM[i] == node_ID)				
			{
			   NoximGlobalParams::SWI[v].Reserve_BM.erase(NoximGlobalParams::SWI[v].Reserve_BM.begin()+i);
			   NoximGlobalParams::SWI[v].Reserve_MAB.erase(NoximGlobalParams::SWI[v].Reserve_MAB.begin()+i);
			   cout<<"releasing size now: "<<NoximGlobalParams::SWI[v].Reserve_BM.size()<<endl;
			   return v;
			}
	    } 	
	}
   }//end for VC
    return NOT_RESERVED;
}

inline NoximFlit DomyFlit()
{
    NoximFlit flit;

    flit.src_id = 0;
    flit.dst_id = 0;
    flit.timestamp = sc_time_stamp().to_double() / 1000;;
    flit.sequence_no = 0;
    flit.hop_no = 0;
    flit.MB= 0;									//add by ammar
    flit.VCID=0;								//add by ammar
    flit.MAB= Integer2Bin (0);									//add by ammar
    flit.flit_type = FLIT_TYPE_TAIL;

    return flit;
}

inline vector <bool> ResetVector(int s)
{
	vector <bool> V;
	V.resize(s);
	for (int i=0; i<s; i++)
		V[i]=0;

	return V;
}

#endif
