/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the buffer
 */

#include "NoximBuffer.h"

NoximBuffer::NoximBuffer()
{
    SetMaxBufferSize(NoximGlobalParams::buffer_depth);
}

void NoximBuffer::SetMaxBufferSize(const unsigned int bms)
{

 // cout<<sc_time_stamp().to_double()/1000 <<" max_buffer_size1"<< max_buffer_size <<endl;
  
    assert(bms > 0);

    max_buffer_size = bms;
    
  //  cout<<sc_time_stamp().to_double()/1000 <<" max_buffer_size2"<< max_buffer_size <<endl;
}

unsigned int NoximBuffer::GetMaxBufferSize() const
{
    return max_buffer_size;
}

bool NoximBuffer::IsFull() const
{
    return buffer.size() == max_buffer_size;
}

bool NoximBuffer::IsEmpty() const
{
    return buffer.size() == 0;
}

void NoximBuffer::Drop(const NoximFlit & flit) const
{

  cout<<sc_time_stamp().to_double()/1000 <<" Drop1"<< max_buffer_size <<endl;
  
    assert(false);
    
     cout<<sc_time_stamp().to_double()/1000 <<" Drop2"<< max_buffer_size <<endl;
}

void NoximBuffer::Empty() const
{

 // cout<<sc_time_stamp().to_double()/1000 <<" Empty1" <<endl;
 
    assert(false);
    
   // cout<<sc_time_stamp().to_double()/1000 <<" Empty2"<<endl;         here is the error
}

void NoximBuffer::Push(const NoximFlit & flit)
{
    if (IsFull())
	Drop(flit);
	
	 //cout<<sc_time_stamp().to_double()/1000 <<" Push1"<<endl;
    else
	buffer.push(flit);
	
	//cout<<sc_time_stamp().to_double()/1000 <<" Push2"<<endl;
}

NoximFlit NoximBuffer::Pop()
{
    NoximFlit f;

    if (IsEmpty())
	Empty();
	
	 //cout<<sc_time_stamp().to_double()/1000 <<" POP1"<<endl;
    else {
	f = buffer.front();
	buffer.pop();
	
	//cout<<sc_time_stamp().to_double()/1000 <<" POP2"<<endl;
    }

    return f;
}

NoximFlit NoximBuffer::Front() const
{
    NoximFlit f;

    if (IsEmpty())
	Empty();
    else
	f = buffer.front();

    return f;
}

void NoximBuffer::Update(const NoximFlit & flit) 
{
    NoximFlit f;

    if (IsEmpty())
	Empty();
    else
	buffer.front()= flit;

}

unsigned int NoximBuffer::Size() const
{
    return buffer.size();
}

unsigned int NoximBuffer::getCurrentFreeSlots() const
{
    return (GetMaxBufferSize() - Size());
}
