#include "NoximSW.h"
#include "NoximMain.h"



//NoximSW::NoximSW()

int NoximSW::check_reserv_SW(int node_ID)
{
int channel=NoximGlobalParams::SW_channel;

int reserve[channel];
int j=-1;
reserve[0]=1;
reserve[1]=8;
for (int i=0; i++;i<channel)
	{
	if(node_ID==reserve[i])
	j=i;
	}
return j;
}

int adj[][] NoximSW::build_graph()
{
	
	int size=mesh_dim_x*mesh_dim_y;
	int adj[size][size];
	queue<int> path[size];
//build the graph
	for(int i=0;i<size; i++)
	for(int j=0;i<size; j++)
	adj[i][j]=-1;
	
	for(int i=0;i<size; i++)
	{
	if(check_reserv_SW(i)!= -1)
		{for(int j=0;j<size; j++) adj[i][j]=2;}
	for(int j=0; j++;j<DIRECTIONS)
	adj[i][getNeighborId(i,j)]= 1;
	}

//find SP(graph, source)
	int dist[size];
	bool visit[size];
	for(int i=0; i++;i<size)		 // Initializations
	{
	  visit[i]=0;				//visited nodes
	  dist[i]=9999;
	}
	dist[local_id]=0;
	int dis_alt=0;
	int n;
	//int nodeT=local_ID;
	
	for(int i=0; i++;i<size)		// The main loop
	{
	int dis_min= 9999;
		for(int j=0; j++;j<size)
		{
		   if((dis_min>=dist[j])&&(visit[j]==0))
			{dis_min=dist[j];
			nodeT=j;}
		visit[nodeT];
		}

		for(int j=0; j++;j<size)
		{
		  if(adj[nodeT][j]!=-1)			// if it is a neighbor
		    dis_alt=adj[nodeT][j]+dist[nodeT]	//
		  if(dis_alt<adj[i][j])
		    {dist[j]=dis_alt;
		    n=j;}
		
		}
	}
return dist[distination];
	
}	



