/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the top-level of Noxim
 */

#include "NoximMain.h"
#include "NoximNoC.h"
#include "NoximGlobalStats.h"
#include "NoximCmdLineParser.h"
using namespace std;
#include <unistd.h>

// need to be globally visible to allow "-volume" simulation stop
unsigned int drained_volume;

// hotspot files creation
void create_ptrace_file(int dz);
void create_floorplan_files(int dx, int dy, int dz);
void DarkPattrenOdd(int dx, int dy);

// Initialize global configuration parameters (can be overridden with command-line arguments)
int NoximGlobalParams::verbose_mode = DEFAULT_VERBOSE_MODE;
int NoximGlobalParams::trace_mode = DEFAULT_TRACE_MODE;
int NoximGlobalParams::SW_channel = DEFAULT_NO_C;                      			 // add by Ammar
char NoximGlobalParams::trace_filename[128] = DEFAULT_TRACE_FILENAME;
int NoximGlobalParams::mesh_dim_x = DEFAULT_MESH_DIM_X;
int NoximGlobalParams::mesh_dim_y = DEFAULT_MESH_DIM_Y; 
int NoximGlobalParams::mesh_dim_chip_x = DEFAULT_MESH_DIM_CHIP_X;                 // Dr. Ammar and Issraa
int NoximGlobalParams::mesh_dim_chip_y = DEFAULT_MESH_DIM_CHIP_Y;                 // Dr. Ammar and Issraa
//bool NoximGlobalParams::power_link_flag = DEFAULT_POWER_LINK_FLAG;             // Dr. Ammar and Issraa
int NoximGlobalParams::buffer_depth = DEFAULT_BUFFER_DEPTH;
int NoximGlobalParams::min_packet_size = DEFAULT_MIN_PACKET_SIZE;
int NoximGlobalParams::max_packet_size = DEFAULT_MAX_PACKET_SIZE;
int NoximGlobalParams::routing_algorithm = DEFAULT_ROUTING_ALGORITHM;
char NoximGlobalParams::routing_table_filename[128] = DEFAULT_ROUTING_TABLE_FILENAME;
int NoximGlobalParams::selection_strategy = DEFAULT_SELECTION_STRATEGY;
float NoximGlobalParams::packet_injection_rate = DEFAULT_PACKET_INJECTION_RATE;
float NoximGlobalParams::probability_of_retransmission = DEFAULT_PROBABILITY_OF_RETRANSMISSION;
int NoximGlobalParams::traffic_distribution = DEFAULT_TRAFFIC_DISTRIBUTION;
char NoximGlobalParams::traffic_table_filename[128] = DEFAULT_TRAFFIC_TABLE_FILENAME;
int NoximGlobalParams::simulation_time = DEFAULT_SIMULATION_TIME;
int NoximGlobalParams::stats_warm_up_time = DEFAULT_STATS_WARM_UP_TIME;
int NoximGlobalParams::rnd_generator_seed = time(NULL);
bool NoximGlobalParams::detailed = DEFAULT_DETAILED;
float NoximGlobalParams::dyad_threshold = DEFAULT_DYAD_THRESHOLD;
unsigned int NoximGlobalParams::max_volume_to_be_drained = DEFAULT_MAX_VOLUME_TO_BE_DRAINED;
vector <pair <int, double> > NoximGlobalParams::hotspots;
queue <NoximFlit> NoximGlobalParams::SW_Buf[2000];						//add by Ammar
int NoximGlobalParams::SW_reserve[2000][MAX_STATIC_VC];						//add by Ammar
int NoximGlobalParams::Broadcast_RATE=DEFAULT_Broadcast_RATE;				        //add by Ammar
int NoximGlobalParams::RF_Weight;								//add by Ammar
int NoximGlobalParams::VC_No = DEFAULT_Virtual_Channel;                 			//add by Ammar
int NoximGlobalParams::BM_Mode = DEFAULT_BROADCAST_MODE;                 			//add by Ammar
vector<int> NoximGlobalParams::Reserve_BM ;            						//add by Ammar
vector<int> NoximGlobalParams::Reserve_MAB ;           						//add by Ammar
int NoximGlobalParams::Multicast = 0;   		              				//add by Ammar
int NoximGlobalParams::Master_node[MAX_STATIC_DIM];	              				//add by Ammar
SWI_reserve NoximGlobalParams::SWI[MAX_STATIC_VC];		              			//add by Ammar
int NoximGlobalParams::Arbitration_period=DEFAULT_MIN_PACKET_SIZE;     				//add by Ammar
int NoximGlobalParams::Arbitration_type=PERIOD_ARB;						//add by Ammar
int NoximGlobalParams::SWI_Free_slots[MAX_STATIC_DIM*MAX_STATIC_DIM][MAX_STATIC_VC];		//add by Ammar
int NoximGlobalParams::Master_aloc=0;								//add by Ammar
int NoximGlobalParams::EntryVCT=32;								//add by Ammar
int NoximGlobalParams::BenchMark =0;								//add by Ammar
double NoximGlobalParams::StopTime =0;								//add by Ammar
int NoximGlobalParams::TAG =1;									//add by Ammar
int NoximGlobalParams::Thermal   =  THERMAL; 							//add by Ammar
int NoximGlobalParams::NoSample = NO_SIM;							//add by Ammar
int NoximGlobalParams::Dark = NO_DARK_SCI;							//add by Ammar
int NoximGlobalParams::Dark_pattren=0;								//add by Ammar
bool NoximGlobalParams::Dark_PE[MAX_STATIC_DIM*MAX_STATIC_DIM];					//add by Ammar
//---------------------------------------------------------------------------

int sc_main(int arg_num, char *arg_vet[])
{
   //string ptrace_file, results_file-- hotspot
   const char * results_file;
   const char * ptrace_file;
   const char * steady_file;
   const char * initial_file;
   const char * ttrace_file;
   const char * ttrace_all_file;
   stringstream hotspot_command;
   stringstream hotspot_command2;
   ofstream fout;
   ofstream fout_ttrace;
   ifstream fin;
   ifstream fin_ttrace;
    // TEMP
    float tile_power;  
    drained_volume = 0;


			

    parseCmdLine(arg_num, arg_vet);
    // Signals
    sc_clock clock("clock", 1, SC_NS);
    sc_signal <bool> reset;

    // NoC instance
//cout<<"NoC instance begin"<<endl;
    NoximNoC *n = new NoximNoC("NoC");
//cout<<"NoC instance end"<<endl<<endl;
    n->clock(clock);

    n->reset(reset);
//============ creating floor plan and determine dark silicon pattren ==========================
    int dx=NoximGlobalParams::mesh_dim_x;
    int dy=NoximGlobalParams::mesh_dim_y;
    int dz=1;
    for(int i=0; i<dx *dy; i++)
		NoximGlobalParams::Dark_PE[i]=false;
    if(NoximGlobalParams::Dark_pattren==0)
	DarkPattrenOdd(dx, dy);
    else
        NoximGlobalParams::Dark_PE[0]=true;

    create_floorplan_files( dx,  dy, dz);  // creat the floorplan files .flp hot spot

//================================================================================================


//do this after binding the line arguments
    // Trace signals
    sc_trace_file *tf = NULL;
    if (NoximGlobalParams::trace_mode) {
	tf = sc_create_vcd_trace_file(NoximGlobalParams::trace_filename);
	sc_trace(tf, reset, "reset");
	sc_trace(tf, clock, "clock");

	for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++) {
	    for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++) {
		for (int c = 0; c < MAX_STATIC_VC ; c++) {
		char label[30];

		sprintf(label, "req_to_east(%02d)(%02d)", i, j);
		sc_trace(tf, n->req_to_east[i][j][c], label);
		sprintf(label, "req_to_west(%02d)(%02d)", i, j);
		sc_trace(tf, n->req_to_west[i][j][c], label);
		sprintf(label, "req_to_south(%02d)(%02d)", i, j);
		sc_trace(tf, n->req_to_south[i][j][c], label);
		sprintf(label, "req_to_north(%02d)(%02d)", i, j);
		sc_trace(tf, n->req_to_north[i][j][c], label);


		sprintf(label, "ack_to_east(%02d)(%02d)", i, j);
		sc_trace(tf, n->ack_to_east[i][j][c], label);
		sprintf(label, "ack_to_west(%02d)(%02d)", i, j);
		sc_trace(tf, n->ack_to_west[i][j][c], label);
		sprintf(label, "ack_to_south(%02d)(%02d)", i, j);
		sc_trace(tf, n->ack_to_south[i][j][c], label);
		sprintf(label, "ack_to_north(%02d)(%02d)", i, j);
		sc_trace(tf, n->ack_to_north[i][j][c], label);
		
	    }}
	}
    }
    // Reset the chip and run the simulation
    //cout << "Reset the chip and run the simulation"<<endl;     
  
    reset.write(1);
// cout << "Reset..."<<endl;                              //issraa_try
    srand(NoximGlobalParams::rnd_generator_seed);	// time(NULL);
    sc_start(DEFAULT_RESET_TIME, SC_NS);
    reset.write(0);
 //cout << " done! Now running for " << NoximGlobalParams::simulation_time << " cycles..." << endl;   //issraa_try
    drained_volume=0;									//add by Ammar
    //sc_start(NoximGlobalParams::simulation_time, SC_NS);				//Ammar

// ===========================  initialize the hotshpot command ========================================
	hotspot_command<<"~/thermal/HotSpot-6.0/"; 	//Ammar Ubuntu
	//hotspot_command<<"./hotspot -c hotspot.config -f scc.flp -o scc.ttrace -init_file scc.init -steady_file scc.steady";
	hotspot_command<<"hotspot -f scc.flp -o scc.ttrace  -steady_file scc.steady";

	initial_file	= "scc.init";			//-init_file 
	results_file	= "scc.steady.aggrigate";
	steady_file	= "scc.steady";
	ptrace_file 	= "scc.ptrace";
	ttrace_file 	= "scc.ttrace";
	ttrace_all_file = "scc.ttrace.all";

        hotspot_command <<" -p "<< ptrace_file;
	hotspot_command2 <<"cp "<< steady_file <<" "<< initial_file ; // copying steady file to intial file for next hotspot command
	fout.open(results_file);    			// TO EMPTY THE FILE
	assert(!fout.fail());  
    	fout.close(); 

	fout.open(ttrace_all_file);    			// TO EMPTY THE FILE
	assert(!fout.fail());  
    	fout.close(); 

	fout.open(ttrace_file);    			// TO EMPTY THE FILE
	assert(!fout.fail());  
    	fout.close(); 

	fout.open(steady_file);    			// TO EMPTY THE FILE
	assert(!fout.fail());  
    	fout.close(); 

  	// string for hotspot system command
  	const char * cc1; 
  	string cmd=hotspot_command.str();
  	cc1=cmd.c_str();  

  	// string for copying steady file to intial file for next hotspot command
  	const char * cc2; 
  	const char * cc3; 
  	const char * cc_run;

  	string cmd2=hotspot_command2.str();
  	cc2=cmd2.c_str();  

  	hotspot_command <<" -init_file  "<< initial_file << " > hs_log.txt";	// adding intial file to the hotspot command after 1st run
  


  	string cmd3=hotspot_command.str();
  	cc3=cmd3.c_str(); 
  	//cout <<"after adding initial file:" << endl;
  	//cout << cc3 << endl;
	//============================ end hotspot command====================

//============================================================================
// 			MAIN LOOP
//============================================================================
std::string  line_txt;
fout_ttrace.open(ttrace_all_file, ios::app);

//cout<< "Running Noxim for : "<<  NoximGlobalParams::NoSample<<" each run for "<< NoximGlobalParams::simulation_time<< " cycle..."<< endl;
int total_drained_flits;
int total_injected_flits;
int drained_flits[dx][dy];
int injected_flits[dx][dy];
for(int a=0; a<NoximGlobalParams::NoSample; a++) 	//run the simulation for number of times //NoximGlobalParams::no_of_samples
   {	
	cout<< ".."<< a;
	total_drained_flits=0;
	total_injected_flits=0;

    	sc_start(NoximGlobalParams::simulation_time, SC_NS);				//Ammar

 	// Read power from r->power and update the  .ptrace file hotspot
    	double pr_energy[dx][dy];			//reset energy of all routers
	for(int y=0; y<dy; y++)
	     for(int x=0; x<dx; x++)
	     {
		pr_energy[x][y]=0.0;
		drained_flits[x][y]= n->t[x][y]->r->local_drained_flit;
		injected_flits[x][y]= n->t[x][y]->r->local_injected;
		total_drained_flits= total_drained_flits +drained_flits[x][y];	// measure PE activity
		total_injected_flits= total_injected_flits + injected_flits[x][y];	// measure PE activity
		//cout<< " PE flits: "<<  drained_flits[x][y]+ injected_flits[x][y]<< endl;
	     }
	int total_PE_flit =total_drained_flits + total_injected_flits;


 	// =========== update Great power trace file =====================
  	create_ptrace_file(1);				// Read the unit names and write them  to the ptrace file hotspot
	fout.open(ptrace_file,ios::app);   		// open file for appending hotspot
	double Total_MC_power=0;
	double Total_Tiles_power=0;
	long double Total_Activity=0;

	for(int y=0; y<dy; y++)				//Step 1: calculate total tiles power
	      for(int x=0; x<dx; x++)
		    {
			int local_id=y * NoximGlobalParams::mesh_dim_x + x;
		 	double r_energy= n->t[x][y]->r->getLocalRouterPwr(local_id);
			double r_power = (FREQ*r_energy)/(NoximGlobalParams::simulation_time);
			//cout<< "r_power: "<< r_power<< endl;
			pr_energy[x][y]= r_power;			
			Total_Tiles_power= Total_Tiles_power+r_power;	//total power of all routers which is 10% of total chip power
		    }
	Total_MC_power =Total_Tiles_power* 1.9; 			// MCs power of SCC is 19%	    
	Total_Tiles_power=Total_Tiles_power* 7.1; 			// PEs power of SCC is 71%
	//cout<< "total tiles power: "<<   Total_Tiles_power<< endl; 

	for(int y=0; y<dy; y++)						//Step 2: calculate each component power and write it to ptrace file
	      for(int x=0; x<dx; x++)
		    {
			// percentage of PE activity based on total injected and drained flits
			double PE_activity= double(injected_flits[x][y] + drained_flits[x][y])/double(total_PE_flit);// measure PE activity
			Total_Activity=Total_Activity + PE_activity;
			
			double PE_power= PE_activity*Total_Tiles_power*0.5;// each core power as a percentage of the tiles power
			fout <<PE_power<< "  " <<pr_energy[x][y] << "  " << PE_power<< "  "  ;
		    } 
	for(int i=0; i<4; i++)			//power of memory controlers and DDR 19% divided by 4
		fout <<Total_MC_power*0.25<< "  ";
		
	fout << endl;
	fout.close( ); 
	//==========End of updating power trace file ====================

	// ======== run hostspot thermal simulation if required==========
        if(NoximGlobalParams::Thermal ==  THERMAL )
	   {   
		if (a==0) 
			cc_run = cc1; 			// run without intial file
		else
			cc_run= cc3;
			//cout << cc_run << endl;		// run with intial file
			system(cc_run);

		//cout<<"running hotspot..."<<endl;
		//cout << cc2 << endl;		
		system(cc2);				// copying steady file to intial file
	   }   
	fin_ttrace.open(ttrace_file, std::ifstream::in);	// keeping track of temperature for each run
	assert(!fin_ttrace.fail());
	std::getline(fin_ttrace, line_txt);
	std::getline(fin_ttrace, line_txt);
	fout_ttrace <<line_txt<<endl;
	fin_ttrace.close();
	for(int y=0; y<dy; y++)
	     for(int x=0; x<dx; x++)
  		{ 
		int local_id=y * NoximGlobalParams::mesh_dim_x + x;
		n->t[x][y]->r->stats.power.ClearLocalP(local_id);
		}

   }
   fout_ttrace.close();

       //     cout  << "\t" <<"dim_x:"<<NoximGlobalParams::mesh_dim_x << "\t" 
         //         <<"dim_y:"<<NoximGlobalParams::mesh_dim_y<<endl;
     //       cout << "\t" <<"dim_chip_x:"<<NoximGlobalParams::mesh_dim_chip_x << "\t" <<"dim_chip_y:" 
       //          <<NoximGlobalParams::mesh_dim_chip_y<<endl;   //Dr. Ammar and Issraa



 

    // ========= Close the simulation =================
    if (NoximGlobalParams::trace_mode)
	sc_close_vcd_trace_file(tf);
  //  cout << "Noxim simulation completed." << endl;      //issraa_try
 //   cout << " ( " << sc_time_stamp().to_double() /
//	1000 << " cycles executed)" << endl;           //issraa_try


    // Show statistics
	double pwr=n->getPower();
    NoximGlobalStats gs(n, pwr);
    cout<<NoximGlobalParams::packet_injection_rate <<"\t";
    gs.showStats2(std::cout, NoximGlobalParams::detailed);
			

    if ((NoximGlobalParams::max_volume_to_be_drained > 0) &&
	(sc_time_stamp().to_double() / 1000 >=
	 NoximGlobalParams::simulation_time)) {
	cout <<
	    "\nWARNING! the number of flits specified with -volume option"
	    << endl;
	cout << "has not been reached. ( " << drained_volume <<
	    " instead of " << NoximGlobalParams::
	    max_volume_to_be_drained << " )" << endl;
	cout <<
	    "You might want to try an higher value of simulation cycles" <<
	    endl;
	cout << "using -sim option." << endl;
#ifdef TESTING
	cout << "\n Sum of local drained flits: " << gs.
	    drained_total << endl;
	cout << "\n Effective drained volume: " << drained_volume;
#endif
    }


//sc_report_handler::set_actions("/IEEE_Std_1666/deprecated", SC_DO_NOTHING);
//cout<<"the end"<<endl;
    return 0;
}


//==============================================================================
//			creating power trace file from floor plan file
//==============================================================================
void create_ptrace_file(int dz)
{
   //cout<< "generate ptrace"<< endl;
   ofstream fout;
   ifstream fin;
   char temp[50];
   if (dz == 1)
   	 {	fout.open("scc.ptrace"); 
   		assert(!fout.fail());  
     }
   else 
   	 {	fout.open("teraflop3d.ptrace"); 
   		assert(!fout.fail());  
     }
     
   
   char uname[30];
   float f1, f2, f3 ,f4;
   int index =0;
   fin.open("scc.flp");
   assert(!fin.fail());
//for (int i=0; i< dz; i++) {


     while (fin.getline (temp,50)) //!fin.eof()) 
    	{
	//cout<< "read flp for ptrace"<< endl;
	index++;	
	sscanf(temp, "%s %f %f %f %f ", &uname, &f1, &f2, &f3 ,&f4);
	//cout << uname<< " ";
	fout << uname <<" ";
	} //while
     
     fin.clear();
     fin.seekg(ios::beg);// Ammar "ios::beg" begining of?

 
//} //for
fin.close();    
assert(!fin.fail( ));
fout << endl;
fout << endl;

fout.close();

}
//==============================================================================
//		creat floor plan file based on the size of NoC
//==============================================================================

void create_floorplan_files( int dx, int  dy, int  dz)
{
	ofstream fout;
	//stringstream  u_name;
	double	tile_h=5.2e-3;   
	double	tile_w=3.6e-3;
	double	r_h=1.2e-3;
	double	r_w=3.6e-3;
	double	core_w=r_w;
	double	core_h=2.0e-3;
	double	memc_h=10.4e-3;
	double	memc_w=2.5e-3;
	double left_x;
	double bot_y;
	double u_w;
	double u_h;
	int index=0;
	int tile_index=0;    
	fout.open("scc.flp");
	//cout<< "floor plane generated"<<endl;

	for (int y=1; y<=dy; y++)
		for (int x=1; x<=dx; x++)
			{
			 index++;
			 tile_index++;
			 u_w=core_w;
			 u_h=core_h;
			  left_x=(x-1)*tile_w;
			  bot_y=(y-1)*tile_h;

//                       u_name <<"u_"<<index<<"_MEM_"<< tile_idx;
			 fout << "u_" << index << "_CORE1_" << tile_index<< " " <<u_w <<" " << u_h <<" " << left_x + memc_w <<" " << bot_y << endl;
			
			 index++;
			 u_w=r_w;
	          	 u_h=r_h;
        	         left_x=(x-1)*tile_w;
	                 bot_y= (y-1)*tile_h+core_h;
			 fout << "u_" << index << "_RTR_" << tile_index<< " " <<u_w << " " << u_h << " " <<  left_x + memc_w  << " " << bot_y<< endl;	
			 index++;
		         u_w=core_w;
	                 u_h=core_h;
              	         left_x=(x-1)*tile_w;
	                 bot_y= (y-1)*tile_h + core_h + r_h;
	            	 fout << "u_" << index << "_CORE2_" << tile_index<< " " <<u_w << " " << u_h << " " <<  left_x + memc_w  << " " << bot_y<< endl;	
			}



			// Adding memory controllers

			 index=1;
		         u_w=memc_w;
	                 u_h=memc_h;
              	         left_x=0;
	                 bot_y= 0;
	            	 fout << "u_" << "_MEMC_"  << index << " " <<u_w << " " << u_h << " " <<  left_x<< " " << bot_y<< endl;	


			 index++;
	                 bot_y= memc_h;
	            	 fout << "u_" << "_MEMC_"  << index << " " <<u_w << " " << u_h << " " <<  left_x<< " " << bot_y<< endl;	


			 index++;
              	         left_x=dx*tile_w+memc_w;
	                 bot_y= 0;
	            	 fout << "u_" << "_MEMC_"  << index << " " <<u_w << " " << u_h << " " <<  left_x<< " " << bot_y<< endl;	

			 index++;
              	         left_x=dx*tile_w+memc_w;
	                 bot_y= memc_h;
	            	 fout << "u_" << "_MEMC_"  << index << " " <<u_w << " " << u_h << " " <<  left_x << " " << bot_y<< endl;	

	fout.close( );
}


void DarkPattrenOdd(int dx, int dy)
{
	for(int i=0; i<dx *dy; i++)
		if (i%2 == 1)
			NoximGlobalParams::Dark_PE[i]=true;

}

