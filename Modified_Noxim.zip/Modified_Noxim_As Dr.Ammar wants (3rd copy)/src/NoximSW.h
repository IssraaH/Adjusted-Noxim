#include "NoximMain.h"

#include "NoximCmdLineParser.h"

#include <systemc.h>
#include "NoximBuffer.h"



class NoximSW
{
	public:
	NoximSW();
	//static const int N_size;
	
	int check_reserv_SW(int Node_ID);
	
	
	
	//NoximBuffer SW_Buf[MAX_STATIC_DIM*MAX_STATIC_DIM];
	//sc_signal <bool> SW_req[mesh_dim_x*mesh_dim_y];
	//sc_signal <bool> SW_ack[mesh_dim_x*mesh_dim_y];
	//bool current_level_rx_SW[mesh_dim_x*mesh_dim_y];
//typedef DenseGRAPH<Edge> Noc_Graph build_graph();
	
	//creat_graph
};	
