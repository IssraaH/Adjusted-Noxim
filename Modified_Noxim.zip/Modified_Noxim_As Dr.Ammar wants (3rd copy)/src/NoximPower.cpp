/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the power model
 */

#include "NoximPower.h"
#include <math.h>
using namespace std;

NoximPower::NoximPower()
{
//cout <<" power 1 ";    
pwr = 0.0;
total_pwr_incoming=0.0;				        //Ammar
total_pwr_forward=0.0;						//Amamr
total_pwr_standby=0.0;						//Ammar
total_pwr_link=0.0;						//Ammar
for (int i = 0; i < MAX_STATIC_DIM *MAX_STATIC_DIM; i++)	//Ammar
	total_local_pwr[i]=0.0;

    pwr_standby = PWR_STANDBY;
    pwr_forward = PWR_FORWARD_FLIT;
    pwr_incoming = PWR_INCOMING;

    if (NoximGlobalParams::routing_algorithm == ROUTING_XY)
	pwr_routing = PWR_ROUTING_XY;
    else if (NoximGlobalParams::routing_algorithm == ROUTING_XY)
	pwr_routing = PWR_ROUTING_XY;
    else if (NoximGlobalParams::routing_algorithm == ROUTING_WEST_FIRST)
	pwr_routing = PWR_ROUTING_WEST_FIRST;
    else if (NoximGlobalParams::routing_algorithm == ROUTING_NORTH_LAST)
	pwr_routing = PWR_ROUTING_NORTH_LAST;
    else if (NoximGlobalParams::routing_algorithm ==
	     ROUTING_NEGATIVE_FIRST)
	pwr_routing = PWR_ROUTING_NEGATIVE_FIRST;
    else if(NoximGlobalParams::routing_algorithm == ROUTING_ODD_EVEN)  //|(NoximGlobalParams::routing_algorithm == ROUTING_ODD_EVEN_SW))						// changed by 		Ammar
	pwr_routing = PWR_ROUTING_ODD_EVEN;


   
    else if (NoximGlobalParams::routing_algorithm == ROUTING_DYAD)
	pwr_routing = PWR_ROUTING_DYAD;
    else if (NoximGlobalParams::routing_algorithm ==
	     ROUTING_FULLY_ADAPTIVE)
	pwr_routing = PWR_ROUTING_FULLY_ADAPTIVE;
    else if (NoximGlobalParams::routing_algorithm == ROUTING_SPF)		//add by Ammar
	pwr_routing = PWR_ROUTING_FULLY_ADAPTIVE;
    else if (NoximGlobalParams::routing_algorithm == ROUTING_TABLE_BASED)
	pwr_routing = PWR_ROUTING_TABLE_BASED;
    else
	assert(false);

    if (NoximGlobalParams::selection_strategy == SEL_RANDOM)
	pwr_selection = PWR_SEL_RANDOM;
    else if (NoximGlobalParams::selection_strategy == SEL_BUFFER_LEVEL)
	pwr_selection = PWR_SEL_BUFFER_LEVEL;
    else if (NoximGlobalParams::selection_strategy == SEL_NOP)
	pwr_selection = PWR_SEL_NOP;
    else if (NoximGlobalParams::selection_strategy == SEL_W_RANDOM )
	pwr_selection = PWR_SEL_W_RANDOM ;
    else
	assert(false);

//cout <<"power 2";
}

void NoximPower::ClearP()			//to clear power statistics after warmup time 		Ammar
{
    pwr = 0;
    total_pwr_incoming=0.0;						//Ammar
    total_pwr_forward=0.0;						//Amamr
    total_pwr_standby=0.0;						//Ammar
    total_pwr_link=0.0;							//Ammar
    for (int i = 0; i < MAX_STATIC_DIM *MAX_STATIC_DIM; i++)
	total_local_pwr[i]=0.0;
    
}
void NoximPower::ClearLocalP(int local_id)			//to clear power statistics after warmup time 		Ammar
{
	total_local_pwr[local_id]=0.0;   
}

void NoximPower::Routing(int local_id)					//changed by Ammar to inclod local iD
{
    pwr += pwr_routing;
    total_local_pwr[local_id] += pwr_routing;
}

void NoximPower::Selection(int local_id)					//changed by Ammar to inclod local iD
{
    pwr += pwr_selection;
    total_local_pwr[local_id] += pwr_selection;
}

void NoximPower::Standby(int local_id)					//changed by Ammar to inclod local iD
{
    pwr += pwr_standby;
    total_pwr_standby+= pwr_standby;
    total_local_pwr[local_id] += pwr_selection;
}

void NoximPower::Forward(int local_id)					//changed by Ammar to inclod local iD
{
    pwr += pwr_forward;
    total_pwr_forward+= pwr_forward;
    total_local_pwr[local_id] += pwr_selection;
}

void NoximPower::Incoming(int local_id)					//changed by Ammar to inclod local iD
{
    pwr += pwr_incoming;
    total_pwr_incoming+= pwr_incoming;
    total_local_pwr[local_id] += pwr_selection;
}

//calculate the power for the links 	(on_chip power function )						Ammar
void NoximPower::Link(int local,int dist, int op)
{
	NoximCoord src_coord = id2Coord(local);
	NoximCoord dist_coord = id2Coord(dist);
	int xs=src_coord.x;
	int ys=src_coord.y;
	int xd=dist_coord.x;
	int yd=dist_coord.y;
	int SC=128; 				// number of subchannels	
	

		if((op==0)||(op==2))		// moving in y direction (wire)
		{
		pwr += 1.72101E-9;
		total_pwr_link+= 1.72101E-9;		//9 or propapility 0.2 in orion, if 1:6.9252E-09;
		total_local_pwr[local] += 1.72101E-9;
		//cout<<sc_time_stamp().to_double()/1000 <<":"<< pwr<<"	"<<6.9252E-09<<endl;
		}


	else if((op==1)||(op==3))			// moving in x direction (wire)
    		{
		pwr += 1.1856E-9; 			//9 for propapility 0.2 in orion, if 1:4.77315E-09;
		total_pwr_link+=1.1856E-9; 
		total_local_pwr[local] +=1.1856E-9; 
		//cout<<sc_time_stamp().to_double()/1000 <<":"<<pwr<<"	"<<4.77315E-09<<endl;
		}	
		
	else if(op==5)				// moving in Up direction
	{				
		//pwr +=SC*( 4.80E-09 + 0.18107*5e-10*sqrt(pow(double((xs-xd)*3.6),2)+pow(double((ys-yd)*5.2),2)));
		double dis=sqrt(pow(double((xs-xd)*3.6),2)+pow(double((ys-yd)*5.2),2));
		double PdB=-15+20*log10(exp(-6.33*dis/1000));
		double Pdisp=((0.004432)-(0.004432*pow(10,double(PdB/10))))*(0.5E-9);	
		pwr+=3.84E-09 + (Pdisp*128);				//330=Z*Vdd^2 TxRx=4.80E-09
		total_pwr_link+= 3.84E-09 + Pdisp;
		total_local_pwr[local] += 3.84E-09 + (Pdisp*128);
		//cout<<pwr<<"	"<<3.84E-09 + Pdisp<<endl;
		}
}

//calculate the power for the links 	(off_chip power function )	        // Dr. Ammar and Issraa
	
void NoximPower::off_chip_Link()             
{
		
		
		//pwr +=  640E-12;    //5E-12; //65nm technology
		//total_pwr_link+= 640E-12;   //5E-12;   //65nm technology
		pwr +=  30.72E-12;                         //45nm technology
		total_pwr_link+= 30.72E-12; 		

   
}
