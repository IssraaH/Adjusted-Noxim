/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the global traffic table
 */

#include "NoximGlobalTrafficTable.h"

NoximGlobalTrafficTable::NoximGlobalTrafficTable()
{
}

bool NoximGlobalTrafficTable::load(const char *fname)
{
//cout<<"benchmark start"<<endl;
    // Open file
    ifstream fin(fname, ios::in);
    if (!fin)
	return false;

    // Initialize variables
    traffic_table.clear();

    // Cycle reading file
    while (!fin.eof()) {
	char line[512];
	fin.getline(line, sizeof(line) - 1);

	if (line[0] != '\0') {
	    if (line[0] != '%') {
		int src, dst;	// Mandatory
		int Packet_size;
		float pir, por;
		int t_on, t_off, t_period;
		int params;
		if (NoximGlobalParams::BenchMark==B_MULTICAST)
		{
			
			NoximCommunication communication;
			vector < bool > MAB;
			int M[80];
			if(NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y==36)
			params= sscanf(line, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %f", &src, &dst,&M[0],&M[1],&M[2],&M[3],&M[4],&M[5],&M[6],&M[7],&M[8],&M[9],&M[10],&M[11],&M[12],&M[13],&M[14],&M[15],&M[16],&M[17],&M[18],&M[19],&M[20],&M[21],&M[22],&M[23],&M[24],&M[25],&M[26],&M[27],&M[28],&M[29],&M[30],&M[31],&M[32],&M[33],&M[34],&M[35],&pir );

			else if (NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y==16)
			params= sscanf(line, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d  %f", &src, &dst,&M[0],&M[1],&M[2],&M[3],&M[4],&M[5],&M[6],&M[7],&M[8],&M[9],&M[10],&M[11],&M[12],&M[13],&M[14],&M[15], &pir );

			else if (NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y==64)
			params= sscanf(line, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d  %f", &src, &dst,&M[0],&M[1],&M[2],&M[3],&M[4],&M[5],&M[6],&M[7],&M[8],&M[9],&M[10],&M[11],&M[12],&M[13],&M[14],&M[15],&M[16],&M[17],&M[18],&M[19],&M[20],&M[21],&M[22],&M[23],&M[24],&M[25],&M[26],&M[27],&M[28],&M[29],&M[30],&M[31],&M[32],&M[33],&M[34],&M[35] ,&M[36],&M[37],&M[38],&M[39],&M[40],&M[41],&M[42],&M[43],&M[44],&M[45],&M[46],&M[47],&M[48],&M[49],&M[50],&M[51],&M[52],&M[53],&M[54],&M[55],&M[56],&M[57],&M[58],&M[59],&M[60],&M[61],&M[62],&M[63],&pir );

			else if (NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y==80)
			params= sscanf(line, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d  %f", &src, &dst,&M[0],&M[1],&M[2],&M[3],&M[4],&M[5],&M[6],&M[7],&M[8],&M[9],&M[10],&M[11],&M[12],&M[13],&M[14],&M[15],&M[16],&M[17],&M[18],&M[19],&M[20],&M[21],&M[22],&M[23],&M[24],&M[25],&M[26],&M[27],&M[28],&M[29],&M[30],&M[31],&M[32],&M[33],&M[34],&M[35] ,&M[36],&M[37],&M[38],&M[39],&M[40],&M[41],&M[42],&M[43],&M[44],&M[45],&M[46],&M[47],&M[48],&M[49],&M[50],&M[51],&M[52],&M[53],&M[54],&M[55],&M[56],&M[57],&M[58],&M[59],&M[60],&M[61],&M[62],&M[63], &M[64],&M[65],&M[66],&M[67],&M[68],&M[69],&M[70],&M[71],&M[72],&M[73],&M[74],&M[75],&M[76],&M[77],&M[78],&M[79] ,&Packet_size, &pir);

			else
				cout<<"error multicast benchmark error network size"<<endl;
			if(params != NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y +4)
				cout<<"error multicast benchmark error "<<endl;

			for(int i=0; i<(NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y);i++)
				{
				MAB.push_back(M[i]);
				}	
			/*for(int i=0; i<(NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y);i++)
				{
 
				sscanf(ST, "%d", &M);
				MAB.push_back(M);
				}
			sscanf(line, "%f", &pir);*/
		    	// Mandatory fields
			if (NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y!=80)
			{
		    		communication.src = src-1;
		    		communication.dst = dst-1;
				communication.Packet_size= NoximGlobalParams::max_packet_size;
			}
			else //MPSoC testbench
			{
				communication.src = src;
		    		communication.dst = dst;
				communication.Packet_size= Packet_size;
			}	
			communication.MAB =MAB;
			communication.pir = pir;
			//default parameters
			communication.t_period = DEFAULT_RESET_TIME +NoximGlobalParams::simulation_time;
			communication.por = communication.pir;
			communication.t_on = 0;
			communication.t_off =DEFAULT_RESET_TIME + NoximGlobalParams::simulation_time;
			/*cout<<src<<" "<<dst<<" ";
			for(int i=0; i<(NoximGlobalParams::mesh_dim_x *NoximGlobalParams::mesh_dim_y);i++)
				cout<<MAB[i]<<" ";
			cout<<pir<<" "<<endl;*/
			traffic_table.push_back(communication);
			
		}
		else
		{
		int params =
		    sscanf(line, "%d %d %f %f %d %d %d", &src, &dst, &pir,
			   &por, &t_on, &t_off, &t_period);
		if (params >= 2) {
		    // Create a communication from the parameters read on the line
		    NoximCommunication communication;

		    // Mandatory fields
		    communication.src = src;
		    communication.dst = dst;

		    // Custom PIR
		    if (params >= 3 && pir >= 0 && pir <= 1)
			communication.pir = pir;
		    else
			communication.pir =
			    NoximGlobalParams::packet_injection_rate;

		    // Custom POR
		    if (params >= 4 && por >= 0 && por <= 1)
			communication.por = por;
		    else
			communication.por = communication.pir;	// NoximGlobalParams::probability_of_retransmission;

		    // Custom Ton
		    if (params >= 5 && t_on >= 0)
			communication.t_on = t_on;
		    else
			communication.t_on = 0;

		    // Custom Toff
		    if (params >= 6 && t_off >= 0) {
			assert(t_off > t_on);
			communication.t_off = t_off;
		    } else
			communication.t_off =
			    DEFAULT_RESET_TIME +
			    NoximGlobalParams::simulation_time;

		    // Custom Tperiod
		    if (params >= 7 && t_period > 0) {
			assert(t_period > t_off);
			communication.t_period = t_period;
		    } else
			communication.t_period =
			    DEFAULT_RESET_TIME +
			    NoximGlobalParams::simulation_time;

		    // Add this communication to the vector of communications
		    traffic_table.push_back(communication);

		   }//else not multicast benchmark mode

		}
	    }
	}
    }
//cout<<"benchmasrk end"<<endl;
    return true;
}

double NoximGlobalTrafficTable::getCumulativePirPor(const int src_id,
						    const int ccycle,
						    const bool pir_not_por,
						    vector < pair < int,
						    double > > &dst_prob)
{
    double cpirnpor = 0.0;

    dst_prob.clear();

    for (unsigned int i = 0; i < traffic_table.size(); i++) {
	NoximCommunication comm = traffic_table[i];
	if (comm.src == src_id) {
	    int r_ccycle = ccycle % comm.t_period;
	    if (r_ccycle > comm.t_on && r_ccycle < comm.t_off) {
		cpirnpor += pir_not_por ? comm.pir : comm.por;
		pair < int, double >dp(comm.dst, cpirnpor);
		dst_prob.push_back(dp);
	    }
	}
    }

    return cpirnpor;
}

double NoximGlobalTrafficTable::getCumulativePirPorMAB(const int src_id,
						    const int ccycle,
						    const bool pir_not_por,
						    vector < pair < int,
						    double > > &dst_prob,
						    vector< vector <bool>
						    > &MAB_table, vector< int> &Packet_size)
{
    double cpirnpor = 0.0;

    dst_prob.clear();
    MAB_table.clear();

    for (unsigned int i = 0; i < traffic_table.size(); i++) {
	NoximCommunication comm = traffic_table[i];
	if (comm.src == src_id) {
	    int r_ccycle = ccycle % comm.t_period;
	    if (r_ccycle > comm.t_on && r_ccycle < comm.t_off) 
		{
		cpirnpor += pir_not_por ? comm.pir : comm.por;
		pair < int, double >dp(comm.dst, cpirnpor);
		dst_prob.push_back(dp);
		MAB_table.push_back(comm.MAB);
		Packet_size.push_back(comm.Packet_size);
	    }
	}
    }
    return cpirnpor;
}

int NoximGlobalTrafficTable::occurrencesAsSource(const int src_id)
{
    int count = 0;

    for (unsigned int i = 0; i < traffic_table.size(); i++)
	if (traffic_table[i].src == src_id)
	    count++;

    return count;
}
