/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the processing element
 */

#include "NoximProcessingElement.h"

int NoximProcessingElement::randInt(int min, int max)
{
    return min +
	(int) ((double) (max - min + 1) * rand() / (RAND_MAX + 1.0));
}

void NoximProcessingElement::rxProcess()
{
//cout <<"PE RX begin"<<endl;
    if (reset.read()) 
    {
	for (int c = 0; c < MAX_STATIC_VC ; c++)			///vc	
		{
		ack_rx[c].write(0);
		current_level_rx[c] = 0;
		}
        total_unmatch_VCT=0;
	total_match_VCT =0;
	total_flit_tx =0;
	total_flit_tx_BM=0;
	total_replace_VCT=0;
	RX_flag=0;
        MulticastCount=0;
	UnicastCount=1;
      
	for (int j = 0; j < NoximGlobalParams::EntryVCT; j++)
	{
		ActiveVCT_timestamp[j]=0.0;
		ActiveVCT_IDflag[j]=0;
	}
    } 
    else 
    {
      RX_flag=0;
	if(flit_rx.read().VCID < NoximGlobalParams::VC_No && flit_rx.read().VCID >=0 ){
	//cout<<"PE VCID:"<<flit_rx.read().VCID<<endl;
	if (req_rx[flit_rx.read().VCID].read() == 1-current_level_rx[flit_rx.read().VCID]) //flit_rx.read()	///vc
	{
	    NoximFlit flit_tmp = flit_rx.read();
	    RX_flag=1;								///vc
	 if(NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
	    {
		cout << sc_time_stamp().to_double()/1000 << ": ProcessingElement[" <<
		    local_id << "] RECEIVING " << flit_tmp <<" current_level_rx "
		<<current_level_rx[flit_rx.read().VCID]<<" VCID "<<flit_rx.read().VCID<<endl;
	    }
	    // Negate the old value for Alternating Bit Protocol (ABP)
	    current_level_rx[flit_rx.read().VCID] = 1 - current_level_rx[flit_rx.read().VCID];
	}
	ack_rx[flit_rx.read().VCID].write(current_level_rx[flit_rx.read().VCID]);
	}
    }//end else
//cout <<"PE RX end"<<endl;
}

void NoximProcessingElement::txProcess()
{
//cout <<"PE TX begin"<<endl;
    if (reset.read()) {
	for (int c = 0; c < MAX_STATIC_VC ; c++)			///vc
	{
		req_tx[c].write(0);
		current_level_tx[c] = 0;
	}
	TX_start_from=0;								///vc
	transmittedAtPreviousCycle = false;
    } else {						
	NoximPacket packet;

	if (canShot(packet)) 
	{
	 if( ! NoximGlobalParams::Dark_PE[packet.src_id] || NoximGlobalParams::Dark == NO_DARK_SCI)			//dark PE
	 {			
	    if(packet.MB==1 && NoximGlobalParams::BM_Mode==UNICAST)	//Bdoadcast treated as unicast   Ammar
   	    {
			for(int i=0;i<NoximGlobalParams::mesh_dim_x* NoximGlobalParams::mesh_dim_y; i++)
			{
			if((packet.src_id != i) && (packet.MAB[i]==1))// && !(NoximGlobalParams::Dark_PE[i]) )
				{
				packet.dst_id=i;
				packet.MB=0;
				packet_queue.push(packet);
				//cout<<"Process element: "<<packet.src_id <<" destination: "<<packet.dst_id<< endl;
				//cout<<"packet_queue.front().VCID:  "<<packet_queue.front().VCID<<endl;
				}
			}
		transmittedAtPreviousCycle = true;
	     }
	     //in case multicast using VCT
	     else if(packet.MB==1 && NoximGlobalParams::BM_Mode==VCT)	//Ammar VCT
	     {

		//cout<<"VCT";
		int oldest=0;
		bool match=0;
		int MatchEntery;
		for (int v=0; v<NoximGlobalParams::EntryVCT; v++)
		    {
		    if(ActiveVCT_timestamp[v] < ActiveVCT_timestamp[oldest])
			oldest = v;
		    if(packet.MAB==ActiveVCT_MAB[v])
			{
			match=1;
			MatchEntery=v;
			}
		    }
		if (match==1)
		{
		//cout<<" no match"<<endl;
			packet.VCTsetup =0;				
			packet.VCT_ID =	ActiveVCT_IDflag[MatchEntery];	
			packet.VCTentry = MatchEntery;
    			packet_queue.push(packet);
			transmittedAtPreviousCycle = true;
			total_match_VCT=total_match_VCT +1;
		//cout<<"multicast using VCT"<<endl;
		}
		else if (match==0)
		{
			packet.VCTsetup = 1;				
			packet.VCT_ID =	1- ActiveVCT_IDflag[oldest];
			packet.VCTentry = oldest;
			total_unmatch_VCT = total_unmatch_VCT +1;
			if(ActiveVCT_timestamp[oldest] >0.0)
				total_replace_VCT = total_replace_VCT+1;
			for(int d=0;d< NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y;d++)
			{
				if(packet.MAB[d]==1)
				{
					packet.dst_id=d;
					packet_queue.push(packet);
					transmittedAtPreviousCycle = true;
				}
			}
			ActiveVCT_MAB[oldest]=	packet.MAB;		//update ActiveVCT
			ActiveVCT_timestamp[oldest] = packet.timestamp;
			ActiveVCT_IDflag[oldest]= packet.VCT_ID;
		}	
		//cout<<sc_time_stamp().to_double()/1000 << " :PE "<<packet.src_id <<" dest: "<<packet.dst_id<< endl;	
	     }
	    else //if(packet.MB==0)					//SWI multicast or unicast
		{
		    packet.VCTsetup =0;
		    packet_queue.push(packet);
		    transmittedAtPreviousCycle = true;
		    //if(packet.MB==1 && NoximGlobalParams::BM_Mode==HYBRID_ARCH)
			//cout<<sc_time_stamp().to_double()/1000 << " :PE "<<packet.src_id <<" dest: "<<packet.dst_id<< endl;
		}
	  /*else if(packet.MB==1 && NoximGlobalParams::BM_Mode==HYBRID_ARCH)	
		{
		    packet_queue.push(packet);
		    transmittedAtPreviousCycle = true;
		}*/
	} else
	    transmittedAtPreviousCycle = false;
	//cout<<"packet_queue.front().VCID:  "<<packet_queue.front().VCID<<" is empty?: "<<packet_queue.empty()<<endl;
	if (!packet_queue.empty()) 
	{
	    if (ack_tx[packet_queue.front().VCID].read() == current_level_tx[packet_queue.front().VCID])		///vc[packet_queue.front().VCID]
	    {
		NoximFlit flit = nextFlit();		// Generate a new flit
		if (NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
		{
		    cout << sc_time_stamp().to_double() /
			1000 << ": ProcessingElement[" << local_id <<"] SENDING " << flit <<" VC: "
			<<flit.VCID<<" MAB: "<<Bin2Integ(flit.MAB)<<" MB: "<<flit.MB<<endl;
		}
			//if(local_id==4 && flit.flit_type == FLIT_TYPE_TAIL)
			//cout<<"ProcessingElement Tx flit: "<<flit<<" time: "<<sc_time_stamp().to_double() / 1000<<endl;
		flit_tx->write(flit);			// Send the generated flit
		current_level_tx[flit.VCID] = 1 - current_level_tx[flit.VCID];// Negate the old value for Alternating Bit Protocol (ABP)
		//cout<<"flit.VCID:    "<<flit.VCID<<endl;
		req_tx[flit.VCID].write(current_level_tx[flit.VCID]);	///vc[flit.VCID]
		total_flit_tx++;
		if(flit.MB==1 || MABsize(flit.MAB)>1)
			total_flit_tx_BM++;
	    }
	}
    }}
//cout <<"PE TX end"<<endl;
}

long NoximProcessingElement::getTransmitedFlits()
{
	return total_flit_tx;
}

long NoximProcessingElement::getTransmitedMulticastFlits()
{
	return total_flit_tx_BM;
}


int NoximProcessingElement::getMulticastCount()
{
	return MulticastCount;
}


NoximFlit NoximProcessingElement::nextFlit()
{
    NoximFlit flit;
    NoximPacket packet = packet_queue.front();

    flit.src_id = packet.src_id;
    flit.dst_id = packet.dst_id;
    flit.timestamp = packet.timestamp;
    flit.sequence_no = packet.size - packet.flit_left;
    flit.hop_no = 0;
    flit.MB=packet.MB;									//add by ammar
    flit.VCID=packet.VCID;								//add by ammar
    flit.MAB= packet.MAB;								//add by ammar
    flit.VCTsetup = packet.VCTsetup;							//add by ammar
    flit.VCT_ID = packet.VCT_ID;							//add by ammar
    flit.VCTentry = packet.VCTentry;							//add by ammar
    flit.Tag = 0;									//add by ammar
    flit.size = packet.size;								//add by ammar
	if(flit.VCID>0)
	   cout<<"PE: error VCID>0"<<endl<<endl;						//add by ammar
    //  flit.payload     = DEFAULT_PAYLOAD;

    if (packet.size == packet.flit_left)
	flit.flit_type = FLIT_TYPE_HEAD;
    else if (packet.flit_left == 1)
	flit.flit_type = FLIT_TYPE_TAIL;
    else
	flit.flit_type = FLIT_TYPE_BODY;

    //replicating header flit in case of VCT setup
    /*if(packet.MB==1 && NoximGlobalParams::BM_Mode==VCT  &&  
	flit.flit_type==FLIT_TYPE_HEAD && packet.VCTsetup == 1)
    {
	int d=0;
	while(d< NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y && packet.MAB2[d]==0)
		d++;
	if (d==NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y)
		packet_queue.front().flit_left--;
	else
	{
	  packet.MAB2[d]=0;
	  flit.dst_id =d;
	  if (MABsize(packet.MAB2)==0)
		packet_queue.front().flit_left--;
	}
	
    }
    else
    {}*/
    	packet_queue.front().flit_left--;
    	if (packet_queue.front().flit_left == 0)
		packet_queue.pop();

    return flit;
}

bool NoximProcessingElement::canShot(NoximPacket & packet)
{
    bool shot;
    double threshold;

    if (NoximGlobalParams::traffic_distribution != TRAFFIC_TABLE_BASED) {
	if (!transmittedAtPreviousCycle)
	    threshold = NoximGlobalParams::packet_injection_rate;
	else
	    threshold = NoximGlobalParams::probability_of_retransmission;
	double rnd_tem=(double) rand();
	shot = ((rnd_tem) / RAND_MAX < threshold);
	//if(shot==1 || local_id==0)
        	//cout << sc_time_stamp().to_double()/1000 << ":  PE "<<local_id<<" shot: "<<shot<< " transmittedAtPreviousCycle "<<transmittedAtPreviousCycle<<" probability_of_retransmission "<<
//NoximGlobalParams::probability_of_retransmission<<" threshold "<<threshold<<" RAND_MAX "<<RAND_MAX<<" rnd_tem "<<rnd_tem<<endl;
	if (shot) {
	    switch (NoximGlobalParams::traffic_distribution) {
	    case TRAFFIC_RANDOM:
		packet = trafficRandom();
		break;

	    case TRAFFIC_TRANSPOSE1:
		packet = trafficTranspose1();
		break;

	    case TRAFFIC_TRANSPOSE2:
		packet = trafficTranspose2();
		break;

	    case TRAFFIC_BIT_REVERSAL:
		packet = trafficBitReversal();
		break;

	    case TRAFFIC_SHUFFLE:
		packet = trafficShuffle();
		break;

	    case TRAFFIC_BUTTERFLY:
		packet = trafficButterfly();
		break;

	    default:
		assert(false);
	    }
	}
    } else {			// Table based communication traffic
	if (never_transmit)
	    return false;
	//cout<<"begin table shot"<<endl;
	double now = sc_time_stamp().to_double() / 1000;
	bool use_pir = (transmittedAtPreviousCycle == false);
	vector < pair < int, double > > dst_prob;
	vector <bool> MAB;
	vector< vector <bool> > MAB_table;
	vector< int > Packet_size;
	int P_size;
	bool MB;
	double threshold;
	if(NoximGlobalParams::BenchMark==B_MULTICAST)
	    {
	    threshold =
	    traffic_table->getCumulativePirPorMAB(local_id, (int) now,
					       use_pir, dst_prob,MAB_table,Packet_size);
	    /*cout<<"Router: "<<local_id<<endl;
	    for (unsigned int i = 0; i < MAB_table.size(); i++) 
		{
		  MAB=MAB_table[i];
		  for (int j=0; j<NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y;j++)
			cout<<MAB[j];
		  cout<<endl;
		}*/
	    }
	else if (NoximGlobalParams::BenchMark!=B_MULTICAST)
	    {
	    threshold =
	    traffic_table->getCumulativePirPor(local_id, (int) now,
					       use_pir, dst_prob);
	    }

	double prob = (double) rand() / RAND_MAX;
	shot = (prob < threshold);
	if (shot) {
		   if(NoximGlobalParams::BenchMark==B_MULTICAST)
		   {
	    	     for (unsigned int i = 0; i < dst_prob.size(); i++) 
	    	      {
			if (prob < dst_prob[i].second) 
			{
			   MAB=MAB_table[i];
			   P_size= Packet_size[i];
			   if(MABsize(MAB)>1)
				MB=1;
			   else
				MB=0;
			   
		    	   packet.make(local_id, dst_prob[i].first, now,
		    	   P_size, MB,0,MAB,0,0,0,MAB);	//changed by ammar (1) broadcaste
			   TX_start_from++;		    
			   break;
			}
	    	      }
		   }
		   else
		   {
		     for (int j=0; j<NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y;j++)
			MAB.push_back(1);	
		     int BM_rnd = rand() % 100;			//specifying the broadcast traffic	Ammar 
   		     if(BM_rnd >= NoximGlobalParams::Broadcast_RATE ) 
 			MB=0;	
   		     else
			{MB=1;
          	   	//cout<<"MB=1"<<endl;
			}
	    for (unsigned int i = 0; i < dst_prob.size(); i++) 
	    {
		if (prob < dst_prob[i].second) 
		{
		    vector <bool> MAB2= Generate_MAB(MB,dst_prob[i].first);
		    packet.make(local_id, dst_prob[i].first, now,
		    getRandomSize(), MB,0,MAB2,0,0,0,MAB2);	//changed by ammar (1) broadcaste
			TX_start_from++;		    
			break;
		}
	    }

		}//else bunchmark not multicast
	}
//cout<<"end table shot"<<endl;
    }
    return shot;
}

NoximPacket NoximProcessingElement::trafficRandom()
{

    int max_id =
	(NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y) -1;
    NoximPacket p;
    p.src_id = local_id;
    double rnd = rand() / (double) RAND_MAX;
//cout << sc_time_stamp().to_double()/1000 << ": PE "<<local_id<<" rnd1: "<<rnd<< endl;
    double range_start = 0.0;
//cout<<"traffic random 1"<<endl;
    //cout << "\n " << sc_time_stamp().to_double()/1000 << " PE " << local_id << " rnd = " << rnd << endl;


    // Random destination distribution
    do {
	p.dst_id = randInt(0, max_id);
	//cout<<"p.dst_id"<<p.dst_id<<endl;
	// check for hotspot destination
	for (uint i = 0; i < NoximGlobalParams::hotspots.size(); i++) {
	    //cout << sc_time_stamp().to_double()/1000 << " PE " << local_id << " Checking node " << 		NoximGlobalParams::hotspots[i].first << " with P = " << NoximGlobalParams::hotspots[i].second << endl;

	    if (rnd >= range_start
		&& rnd <
		range_start + NoximGlobalParams::hotspots[i].second) {
		if (local_id != NoximGlobalParams::hotspots[i].first) {
		    //cout << sc_time_stamp().to_double()/1000 << " PE " << local_id <<" That is ! " << endl;
		    p.dst_id = NoximGlobalParams::hotspots[i].first;
		}
		break;
	    } else
		range_start += NoximGlobalParams::hotspots[i].second;	// try next
	}
    } while (p.dst_id == p.src_id)// || (NoximGlobalParams::Dark == DARK_SCI && NoximGlobalParams::Dark_PE[p.dst_id]) ); //Dark
//cout<<" finish while"<<endl;
    p.timestamp = sc_time_stamp().to_double() / 1000;
//cout << p.src_id<< "packet time stamp " <<p.timestamp<<endl;
    p.size = p.flit_left = getRandomSize();
   double MulticastRatio=((double)MulticastCount/UnicastCount)*100;
   int BM_rnd = rand() % 100;					//specifying the broadcast traffic	Ammar 
   if(BM_rnd < NoximGlobalParams::Broadcast_RATE && MulticastRatio <= NoximGlobalParams::Broadcast_RATE) 
   {
	//cout<<"broadcast"<<endl;
	p.MB=1;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	p.MAB[local_id]=0;
	MulticastCount++;
	//cout << sc_time_stamp().to_double()/1000 << ": PE "<<local_id<<" MulticastCount: "<<MulticastCount
	// <<" rnd: "<<BM_rnd<<" p.MB "<<p.MB<< endl;
   }	
   else
   {
 	p.MB=0;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	UnicastCount++;
	//cout << sc_time_stamp().to_double()/1000 << ": PE "<<local_id<<" MulticastCount: "<<MulticastCount
	// <<" rnd: "<<BM_rnd<<" p.MB "<<p.MB<< " MulticastRatio "<<MulticastRatio<<endl;
   }	

								
    //p.VCID= TX_start_from % NoximGlobalParams::VC_No;			///vc random selection 
	p.VCID=0;	
    TX_start_from ++;
//cout<<"traffic random 2"<<endl;
    return p;
}

NoximPacket NoximProcessingElement::trafficTranspose1()
{
    NoximPacket p;
    p.src_id = local_id;
    NoximCoord src, dst;

    // Transpose 1 destination distribution
    src.x = id2Coord(p.src_id).x;
    src.y = id2Coord(p.src_id).y;
    dst.x = NoximGlobalParams::mesh_dim_x - 1 - src.y;
    dst.y = NoximGlobalParams::mesh_dim_y - 1 - src.x;
    fixRanges(src, dst);
    p.dst_id = coord2Id(dst);

    p.timestamp = sc_time_stamp().to_double() / 1000;
    p.size = p.flit_left = getRandomSize();
   int BM_rnd = rand() % 100;					//specifying the broadcast traffic	Ammar 
   if(BM_rnd >= NoximGlobalParams::Broadcast_RATE) 
   {
 	p.MB=0;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
   }	
   else
   {
	//cout<<"broadcast"<<endl;
	p.MB=1;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	p.MAB[local_id]=0;
   }									
    //p.VCID= TX_start_from % NoximGlobalParams::VC_No;			///vc random selection 
	p.VCID=0;
    return p;
}

NoximPacket NoximProcessingElement::trafficTranspose2()
{
    NoximPacket p;
    p.src_id = local_id;
    NoximCoord src, dst;

    // Transpose 2 destination distribution
    src.x = id2Coord(p.src_id).x;
    src.y = id2Coord(p.src_id).y;
    dst.x = src.y;
    dst.y = src.x;
    fixRanges(src, dst);
    p.dst_id = coord2Id(dst);

    p.timestamp = sc_time_stamp().to_double() / 1000;
    p.size = p.flit_left = getRandomSize();
    p.MB=0;										//Ammar

   int BM_rnd = rand() % 100;					//specifying the broadcast traffic	Ammar 
   if(BM_rnd >= NoximGlobalParams::Broadcast_RATE) 
   {
 	p.MB=0;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
   }	
   else
   {
	//cout<<"broadcast"<<endl;
	p.MB=1;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	p.MAB[local_id]=0;
   }									
    //p.VCID= TX_start_from % NoximGlobalParams::VC_No;			///vc random selection 
	p.VCID=0;
    
    return p;
}

void NoximProcessingElement::setBit(int &x, int w, int v)
{
    int mask = 1 << w;

    if (v == 1)
	x = x | mask;
    else if (v == 0)
	x = x & ~mask;
    else
	assert(false);
}


int NoximProcessingElement::getBit(int x, int w)
{
    return (x >> w) & 1;
}

inline double NoximProcessingElement::log2ceil(double x)
{
    return ceil(log(x) / log(2.0));
}

NoximPacket NoximProcessingElement::trafficBitReversal()
{

    int nbits =
	(int)
	log2ceil((double)
		 (NoximGlobalParams::mesh_dim_x *
		  NoximGlobalParams::mesh_dim_y));
    int dnode = 0;
    for (int i = 0; i < nbits; i++)
	setBit(dnode, i, getBit(local_id, nbits - i - 1));

    NoximPacket p;
    p.src_id = local_id;
    p.dst_id = dnode;

    p.timestamp = sc_time_stamp().to_double() / 1000;
    p.size = p.flit_left = getRandomSize();
   int BM_rnd = rand() % 100;					//specifying the broadcast traffic	Ammar 
   if(BM_rnd >= NoximGlobalParams::Broadcast_RATE) 
   {
 	p.MB=0;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
   }	
   else
   {
	//cout<<"broadcast"<<endl;
	p.MB=1;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	p.MAB[local_id]=0;
   }									
    //p.VCID= TX_start_from % NoximGlobalParams::VC_No;			///vc random selection 
	p.VCID=0;
    return p;
}

NoximPacket NoximProcessingElement::trafficShuffle()
{

    int nbits =
	(int)
	log2ceil((double)
		 (NoximGlobalParams::mesh_dim_x *
		  NoximGlobalParams::mesh_dim_y));
    int dnode = 0;
    for (int i = 0; i < nbits - 1; i++)
	setBit(dnode, i + 1, getBit(local_id, i));
    setBit(dnode, 0, getBit(local_id, nbits - 1));

    NoximPacket p;
    p.src_id = local_id;
    p.dst_id = dnode;

    p.timestamp = sc_time_stamp().to_double() / 1000;
    p.size = p.flit_left = getRandomSize();
   int BM_rnd = rand() % 100;					//specifying the broadcast traffic	Ammar 
   if(BM_rnd >= NoximGlobalParams::Broadcast_RATE) 
   {
 	p.MB=0;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
   }	
   else
   {
	//cout<<"broadcast"<<endl;
	p.MB=1;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	p.MAB[local_id]=0;
   }									
    //p.VCID= TX_start_from % NoximGlobalParams::VC_No;			///vc random selection 
	p.VCID=0;
    return p;
}

NoximPacket NoximProcessingElement::trafficButterfly()
{

    int nbits =
	(int)
	log2ceil((double)
		 (NoximGlobalParams::mesh_dim_x *
		  NoximGlobalParams::mesh_dim_y));
    int dnode = 0;
    for (int i = 1; i < nbits - 1; i++)
	setBit(dnode, i, getBit(local_id, i));
    setBit(dnode, 0, getBit(local_id, nbits - 1));
    setBit(dnode, nbits - 1, getBit(local_id, 0));

    NoximPacket p;
    p.src_id = local_id;
    p.dst_id = dnode;

    p.timestamp = sc_time_stamp().to_double() / 1000;
    p.size = p.flit_left = getRandomSize();
   int BM_rnd = rand() % 100;					//specifying the broadcast traffic	Ammar 
   if(BM_rnd >= NoximGlobalParams::Broadcast_RATE) 
   {
 	p.MB=0;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
   }	
   else
   {
	//cout<<"broadcast"<<endl;
	p.MB=1;	
	p.MAB=Generate_MAB(p.MB,p.dst_id);
	p.MAB[local_id]=0;
   }									
    //p.VCID= TX_start_from % NoximGlobalParams::VC_No;			///vc random selection 
	p.VCID=0;
    return p;
}

vector<bool> NoximProcessingElement::Generate_MAB(bool MB, int dst)
{
     vector <bool> MAB;

	if(MB==0)								//unicast
	{	
		//for (int j=0; j<NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y;j++)
			MAB= Integer2Bin (0);
			MAB[dst]=1;
	int dumy=rand();			//dumy call for rand fun. to verify newer version
        //cout << sc_time_stamp().to_double()/1000 << ": PE "<<local_id<<" dumy: "<<dumy<< endl;
		return MAB;
	}	
	else 								//Broadcasting /multicasting
	{
		//cout<<"broadcast"<<endl;
	    if(NoximGlobalParams::Multicast == 0)			///only broadcast
            {
		for (int j=0; j<NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y;j++)
		    {
		     if(j != local_id)
			MAB.push_back(1);
		     else
			MAB.push_back(0);
		    }
		//cout<<"broadcast"<<endl;
		int dumy=rand();
		//cout << sc_time_stamp().to_double()/1000 << ": PE "<<local_id<<" dumy: "<<dumy<< endl;
		return MAB;
	    }
    	    else							///multicasting
     	    {
		//cout<<"multicast"<<endl;
		/*if (local_id==3)
			return Integer2Bin(503);
		else if(local_id ==4)
			return Integer2Bin(292);
		else if(local_id ==8)
			return Integer2Bin(73);*/
		MAB=Integer2Bin(0); 
		while(MABsize(MAB)<2)
		{
			unsigned long long M_rnd = rand() % ((int) pow
					(2.0,NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y));
			MAB=Integer2Bin(M_rnd);
			MAB[local_id]=0;
		//cout<< "multicast, MAB: " << M_rnd<<endl;
		}
		
		return 	MAB;
            }
	}

}

void NoximProcessingElement::fixRanges(const NoximCoord src,
				       NoximCoord & dst)
{
    // Fix ranges
    if (dst.x < 0)
	dst.x = 0;
    if (dst.y < 0)
	dst.y = 0;
    if (dst.x >= NoximGlobalParams::mesh_dim_x)
	dst.x = NoximGlobalParams::mesh_dim_x - 1;
    if (dst.y >= NoximGlobalParams::mesh_dim_y)
	dst.y = NoximGlobalParams::mesh_dim_y - 1;
}

int NoximProcessingElement::getRandomSize()
{
    return randInt(NoximGlobalParams::min_packet_size,
		   NoximGlobalParams::max_packet_size);
}
