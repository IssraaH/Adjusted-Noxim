/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file represents the top-level testbench
 */

#ifndef __NOXIMNOC_H__
#define __NOXIMNOC_H__

#include <systemc.h>
#include "NoximTile.h"
#include "NoximGlobalRoutingTable.h"
#include "NoximGlobalTrafficTable.h"
#include "NoximPower.h"

#define PWR_GA_Dyn              2.3982E-12 			
#define PWR_GA_STANDBY          2.965E-14 /2.0
#define PWR_GA_TxRx         	6E-3 * 0.5E-9 *36		//MAB(24), Req/Rel(1), TimeStamp(10)

using namespace std;

SC_MODULE(NoximNoC)
{

    // I/O Ports
    sc_in_clk clock;		// The input clock for the NoC
    sc_in < bool > reset;	// The reset signal for the NoC
    int start_from_port;
    int start_from_vc;
    int start_from_chan; 	//used in allocation of hold and release
    double pwr;
    //NoximPower power2;				//Ammar

    sc_in < NoximFlit > req_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];			//input of global arbiter	Ammar
    sc_out < NoximFlit > grant_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];//G_siganl	//output of gloabl arbiter	Ammar

    /////SWI data ports and signals 
    sc_mutex  SWI[MAX_STATIC_DIM * MAX_STATIC_DIM]; 	// the SWI data channel reservation
    sc_signal <NoximFlit> SWI_Data[MAX_STATIC_DIM * MAX_STATIC_DIM * MAX_STATIC_VC]; //physical data channel of the SWI	

    sc_signal < bool >  req_SWI_D_signal[MAX_STATIC_DIM * MAX_STATIC_DIM * MAX_STATIC_DIM* MAX_STATIC_DIM ];   // input of the SWI request to the local arbiter		AmmarAs 
    sc_signal < bool >  grant_SWI_D_signal[MAX_STATIC_DIM * MAX_STATIC_DIM * MAX_STATIC_DIM * MAX_STATIC_DIM ];   // input of the SWI request to the local arbiter		Ammar

    sc_signal < bool >  ready_SWI_signal[MAX_STATIC_DIM * MAX_STATIC_DIM* MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter		Ammar
    sc_signal < bool >  ack_SWI_signal[MAX_STATIC_DIM * MAX_STATIC_DIM* MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter		Ammar

    sc_signal < bool >  ready_dume[MAX_STATIC_DIM * MAX_STATIC_DIM* MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter		Ammar
    sc_signal < bool >  ack_dume[MAX_STATIC_DIM * MAX_STATIC_DIM* MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter		Ammar


    bool done[MAX_STATIC_DIM + 1];					//reservation is done
    int grant[MAX_STATIC_DIM + 1];					//grant is done
    int grant_MAB[MAX_STATIC_DIM + 1];					//identify which slaves is reserved
    double  grant_ID[MAX_STATIC_DIM + 1];				//grant id timestamp
    int  grant_ID_src[MAX_STATIC_DIM + 1];				//grant id traffic source
    vector < bool > SWI_Reserve_MAB [MAX_STATIC_VC][MAX_STATIC_DIM];	//identify which slaves will be reserved
    int SWI_Reserve_BM[MAX_STATIC_VC][MAX_STATIC_DIM];			//identify reservation channel-to-VC 
    int SWI_Reserve_BM2[MAX_STATIC_VC][MAX_STATIC_DIM];			//to add delay 2 cycle between reservation and alocation 
    int period;
    bool Hold[MAX_STATIC_DIM * MAX_STATIC_DIM];		//to prevent forwarding more than a flit in one cycle

    // Signals
    sc_signal <NoximFlit> req_SWI_signal[MAX_STATIC_DIM * MAX_STATIC_DIM];//signals of global arbiter	
    sc_signal <NoximFlit> grant_SWI_signal[MAX_STATIC_DIM * MAX_STATIC_DIM];//signals of global arbiter 

    sc_signal <bool> req_to_east[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];//[MAX_STATIC_VC]
    sc_signal <bool> req_to_west[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <bool> req_to_south[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <bool> req_to_north[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];

    sc_signal <bool> ack_to_east[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <bool> ack_to_west[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <bool> ack_to_south[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <bool> ack_to_north[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];

    sc_signal <NoximFlit> flit_to_east[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1];
    sc_signal <NoximFlit> flit_to_west[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1];
    sc_signal <NoximFlit> flit_to_south[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1];
    sc_signal <NoximFlit> flit_to_north[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1];

    sc_signal <int> free_slots_to_east[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <int> free_slots_to_west[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <int> free_slots_to_south[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];
    sc_signal <int> free_slots_to_north[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1][MAX_STATIC_VC];

    // NoP
    sc_signal <NoximNoP_data> NoP_data_to_east[MAX_STATIC_DIM][MAX_STATIC_DIM];
    sc_signal <NoximNoP_data> NoP_data_to_west[MAX_STATIC_DIM][MAX_STATIC_DIM];
    sc_signal <NoximNoP_data> NoP_data_to_south[MAX_STATIC_DIM][MAX_STATIC_DIM];
    sc_signal <NoximNoP_data> NoP_data_to_north[MAX_STATIC_DIM][MAX_STATIC_DIM];

    // Matrix of tiles
    NoximTile *t[MAX_STATIC_DIM][MAX_STATIC_DIM];

    // Global tables
    NoximGlobalRoutingTable grtable;
    NoximGlobalTrafficTable gttable;

    //---------- Mau experiment <start>
    void flitsMonitor() {

	if (!reset.read()) {
	    //      if ((int)sc_simulation_time() % 5)
	    //        return;

	    unsigned int count = 0;
	    for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++)
		for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++)
		    count += t[i][j]->r->getFlitsCount();
	    cout << count << endl;
	}
    }
    //---------- Mau experiment <stop>

    // Constructor

    SC_CTOR(NoximNoC) {
//cout<<"noc cons"<<endl;
	//---------- Mau experiment <start>
	/*
	   SC_METHOD(flitsMonitor);
	   sensitive(reset);
	   sensitive_pos(clock);
	 */
	//---------- Mau experiment <stop>

	// Build the Mesh
	buildMesh();

	SC_METHOD(GlobalArbiter);
	  sensitive << reset;
	  sensitive << clock.pos();

	//SC_METHOD(GlobalArbiterAlo);
	 // sensitive << reset;
	  //sensitive << clock.pos();
//cout<<"noc cons end"<<endl;
    }

    // Support methods
    NoximTile *searchNode(const int id) const;

  void GlobalArbiter();
  //void GlobalArbiterAlo();
    void GAdyn();									//Ammar
    void GAstatic();									//Ammar
    void GAtxrx();									//Ammar
  double getPower();									//Ammar

  
//NoximStats stats;		                // Statistics

  private:

    void buildMesh();

};

#endif
