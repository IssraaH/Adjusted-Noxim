/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the Network-on-Chip
 */

#include "NoximNoC.h"



void NoximNoC::buildMesh()
{
	// cout <<"buildMesh 1"<<endl;
	set_SWI();
	int dume = NoximGlobalParams::SW_channel;
	int dume2 = NoximGlobalParams::SW_channel * NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y;
	int dume3 = 0;
	int GrandSiganl = 0;
	int DataSiganl = 0;
	// int ReqSignal =0;
	//  Check for routing table availability
	if (NoximGlobalParams::routing_algorithm == ROUTING_TABLE_BASED)
		assert(grtable.load(NoximGlobalParams::routing_table_filename));

	// Check for traffic table availability
	if (NoximGlobalParams::traffic_distribution == TRAFFIC_TABLE_BASED)
		assert(gttable.load(NoximGlobalParams::traffic_table_filename));

	// Create the mesh as a matrix of tiles
	for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++)
	{
		for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++)
		{
			// Create the single Tile with a proper name
			char tile_name[20];
			sprintf(tile_name, "Tile[%02d][%02d]", i, j);
			t[i][j] = new NoximTile(tile_name);
			// cout<<"tile "<<i<<j<<" build"<<endl;
			//  Tell to the router its coordinates
			t[i][j]->r->configure(j * NoximGlobalParams::mesh_dim_x + i,
								  NoximGlobalParams::stats_warm_up_time,
								  NoximGlobalParams::buffer_depth,
								  grtable);
			// cout<<"tile "<<i<<j<<" finish router conf"<<endl;
			//  Tell to the PE its coordinates
			t[i][j]->pe->local_id = j * NoximGlobalParams::mesh_dim_x + i;
			t[i][j]->pe->traffic_table = &gttable; // Needed to choose destination
			t[i][j]->pe->never_transmit = (gttable.occurrencesAsSource(t[i][j]->pe->local_id) == 0);

			// Map clock and reset
			t[i][j]->clock(clock);
			t[i][j]->reset(reset);

			// Map Rx signals
			t[i][j]->flit_rx[DIRECTION_NORTH](flit_to_south[i][j]);
			t[i][j]->flit_rx[DIRECTION_EAST](flit_to_west[i + 1][j]);
			t[i][j]->flit_rx[DIRECTION_SOUTH](flit_to_north[i][j + 1]);
			t[i][j]->flit_rx[DIRECTION_WEST](flit_to_east[i][j]);
			// Map Tx signals
			t[i][j]->flit_tx[DIRECTION_NORTH](flit_to_north[i][j]);
			t[i][j]->flit_tx[DIRECTION_EAST](flit_to_east[i + 1][j]);
			t[i][j]->flit_tx[DIRECTION_SOUTH](flit_to_south[i][j + 1]);
			t[i][j]->flit_tx[DIRECTION_WEST](flit_to_west[i][j]);

			// connecting master to the global arbiter
			int s = check_reserv_SW(j * NoximGlobalParams::mesh_dim_x + i);
			if (s != -1)
			{
				t[i][j]->req_SWI(req_SWI_signal[s]);
				t[i][j]->grant_SWI(grant_SWI_signal[s]);
				req_SWI[s](req_SWI_signal[s]);
				grant_SWI[s](grant_SWI_signal[s]);
				// cout<<"binding Abitor with Node: "<<j * NoximGlobalParams::mesh_dim_x + i<<" channel: "<<s<<endl;
				// s++;
			}
			else if (s == -1) /// dumy links
			{
				t[i][j]->req_SWI(req_SWI_signal[dume]);
				t[i][j]->grant_SWI(grant_SWI_signal[dume]);
				req_SWI[dume](req_SWI_signal[dume]);
				grant_SWI[dume](grant_SWI_signal[dume]);
				// G_siganl not_valid;
				// not_valid.req_id=NOT_VALID;
				// not_valid.vc=NOT_VALID;
				NoximFlit not_valid = DomyFlit();
				not_valid.timestamp = NOT_VALID;
				not_valid.VCID = NOT_VALID;
				grant_SWI_signal[dume].write(not_valid);
				req_SWI_signal[dume].write(not_valid);
				// cout<<"dume binding Abitor with Node: "<<j * NoximGlobalParams::mesh_dim_x + i<<" channel: "<<dume<<endl;
				dume++;
			}
			else
				cout << "error in NoC!!!" << endl;

			// cout<< "Tile["<<i<<"]["<<j<<"]"<<endl;

			for (int c = 0; c < MAX_STATIC_VC; c++)
			{
				// Map Rx signals
				t[i][j]->req_rx[DIRECTION_NORTH][c](req_to_south[i][j][c]); // cout <<" binding req_rx: "<< t[i][j]->pe->local_id <<" vc: "<< c <<endl;
				t[i][j]->ack_rx[DIRECTION_NORTH][c](ack_to_north[i][j][c]); // cout <<" binding req_rx: "<< t[i][j]->pe->local_id<<" vc: "<< c <<endl;

				t[i][j]->req_rx[DIRECTION_EAST][c](req_to_west[i + 1][j][c]);
				t[i][j]->ack_rx[DIRECTION_EAST][c](ack_to_east[i + 1][j][c]);

				t[i][j]->req_rx[DIRECTION_SOUTH][c](req_to_north[i][j + 1][c]);
				t[i][j]->ack_rx[DIRECTION_SOUTH][c](ack_to_south[i][j + 1][c]);

				t[i][j]->req_rx[DIRECTION_WEST][c](req_to_east[i][j][c]);
				t[i][j]->ack_rx[DIRECTION_WEST][c](ack_to_west[i][j][c]);
				// cout<<"tile "<<i<<j<<" finish Rx signals"<<endl;
				//  Map Tx signals
				t[i][j]->req_tx[DIRECTION_NORTH][c](req_to_north[i][j][c]);
				t[i][j]->ack_tx[DIRECTION_NORTH][c](ack_to_south[i][j][c]);

				t[i][j]->req_tx[DIRECTION_EAST][c](req_to_east[i + 1][j][c]);
				t[i][j]->ack_tx[DIRECTION_EAST][c](ack_to_west[i + 1][j][c]);

				t[i][j]->req_tx[DIRECTION_SOUTH][c](req_to_south[i][j + 1][c]);
				t[i][j]->ack_tx[DIRECTION_SOUTH][c](ack_to_north[i][j + 1][c]);

				t[i][j]->req_tx[DIRECTION_WEST][c](req_to_west[i][j][c]);
				t[i][j]->ack_tx[DIRECTION_WEST][c](ack_to_east[i][j][c]);

				t[i][j]->free_slots[DIRECTION_NORTH][c](free_slots_to_north[i][j][c]);
				t[i][j]->free_slots[DIRECTION_EAST][c](free_slots_to_east[i + 1][j][c]);
				t[i][j]->free_slots[DIRECTION_SOUTH][c](free_slots_to_south[i][j + 1][c]);
				t[i][j]->free_slots[DIRECTION_WEST][c](free_slots_to_west[i][j][c]);

				t[i][j]->free_slots_neighbor[DIRECTION_NORTH][c](free_slots_to_south[i][j][c]);
				t[i][j]->free_slots_neighbor[DIRECTION_EAST][c](free_slots_to_west[i + 1][j][c]);
				t[i][j]->free_slots_neighbor[DIRECTION_SOUTH][c](free_slots_to_north[i][j + 1][c]);
				t[i][j]->free_slots_neighbor[DIRECTION_WEST][c](free_slots_to_east[i][j][c]);
			}
			// cout<<"tile "<<i<<j<<" finish Tx signals"<<endl;
			//  Map buffer level signals (analogy with req_tx/rx port mapping)

			// cout<<"tile "<<i<<j<<" finish buffer"<<endl;
			//  NoP
			t[i][j]->NoP_data_out[DIRECTION_NORTH](NoP_data_to_north[i][j]);
			t[i][j]->NoP_data_out[DIRECTION_EAST](NoP_data_to_east[i + 1][j]);
			t[i][j]->NoP_data_out[DIRECTION_SOUTH](NoP_data_to_south[i][j + 1]);
			t[i][j]->NoP_data_out[DIRECTION_WEST](NoP_data_to_west[i][j]);

			t[i][j]->NoP_data_in[DIRECTION_NORTH](NoP_data_to_south[i][j]);
			t[i][j]->NoP_data_in[DIRECTION_EAST](NoP_data_to_west[i + 1][j]);
			t[i][j]->NoP_data_in[DIRECTION_SOUTH](NoP_data_to_north[i][j + 1]);
			t[i][j]->NoP_data_in[DIRECTION_WEST](NoP_data_to_east[i][j]);
			// cout<<"tile "<<i<<j<<" finish Nop"<<endl;
		} // end for j
	}	  // end for i

	// connecting masters to slaves local arbiters (distributed arbiteration)/////////////////////////////////////
	// int s=check_reserv_SW(j * NoximGlobalParams::mesh_dim_x + i);
	for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++)
	{
		for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++)
		{
			int s = check_reserv_SW(j * NoximGlobalParams::mesh_dim_x + i);
			if (s != -1)
			{
				for (int m = 0; m < NoximGlobalParams::mesh_dim_x; m++)
					for (int n = 0; n < NoximGlobalParams::mesh_dim_y; n++)
					{
						if (m != i || n != j)
						{
							int TileID = n * NoximGlobalParams::mesh_dim_x + m;
							t[i][j]->grant_SWI_D_Master[TileID](grant_SWI_D_signal[GrandSiganl]);
							t[m][n]->grant_SWI_D[s](grant_SWI_D_signal[GrandSiganl]);
							t[i][j]->req_SWI_D_Master[TileID](req_SWI_D_signal[GrandSiganl]);
							t[m][n]->req_SWI_D[s](req_SWI_D_signal[GrandSiganl]);

							t[i][j]->ack_tx_SWI[TileID](ack_SWI_signal[GrandSiganl]);
							t[m][n]->ack_rx_SWI[s](ack_SWI_signal[GrandSiganl]);
							t[i][j]->ready_tx_SWI[TileID](ready_SWI_signal[GrandSiganl]);
							t[m][n]->ready_rx_SWI[s](ready_SWI_signal[GrandSiganl]);
							// cout<<"t["<<m<<"]["<<n<<"]"<<endl;
							/*if((i==1 && j==1)||(m==1 && n==1))
							{
								cout<<"t["<<i<<"]["<<j<< "]-> ready_tx_SWI["<<TileID<<
									"](ready_SWI_signal["<<GrandSiganl<<"])::::::::::::"<<endl;
								cout<<"t["<<i<<"]["<<j<< "]-> ack_tx_SWI["<<TileID<<
									"](ack_SWI_signal["<<GrandSiganl<<"]);"<<endl;
								cout<<"t["<<m<<"]["<<n<< "]-> ready_rx_SWI["<<s<<
									"](ready_SWI_signal["<<GrandSiganl<<"]);"<<endl;
								cout<<"t["<<m<<"]["<<n<< "]-> ack_rx_SWI["<<s<<
									"](ack_SWI_signal["<<GrandSiganl<<"]);"<<endl;
							}
							/*	cout<< "1"<<endl;
								cout<<"t["<<i<<"]["<<j<<"]-> grant_SWI_D_Master["<<TileID<<
									"](grant_SWI_D_signal["<<GrandSiganl<<"]);"<<endl;
								cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D_Master["<<TileID<<
									"](req_SWI_D_signal["<<GrandSiganl<<"])"<<endl;
							//}
							//if(m==1 && n==0)
							//{
								cout<<"t["<<m<<"]["<<n<<"]->req_SWI_D["<<s<<"](req_SWI_D_signal["
									<<GrandSiganl<<"])"<<endl;
								cout<<"t["<<m<<"]["<<n<<"]->grant_SWI_D["<<s<<"](grant_SWI_D_signal["
									<<GrandSiganl<<"])"<<endl;
							}*/
							GrandSiganl++;
						}
						else
						{
							// extra dumy liks in master nodes
							int TileID2 = j * NoximGlobalParams::mesh_dim_x + i;
							t[i][j]->ack_tx_SWI[TileID2](ack_dume[dume3]);
							t[i][j]->ready_tx_SWI[TileID2](ready_dume[dume3]);
							ready_dume[dume3].write(0); //+
							ack_dume[dume3].write(0);	//+
							dume2++;					//+
							t[i][j]->ready_rx_SWI[s](ready_dume[dume3]);
							t[i][j]->ack_rx_SWI[s](ack_dume[dume3]);
							ready_dume[dume3].write(0);
							ack_dume[dume3].write(0);

							t[i][j]->grant_SWI_D_Master[TileID2](grant_SWI_D_signal[dume2]);
							t[i][j]->req_SWI_D_Master[TileID2](req_SWI_D_signal[dume2]);
							req_SWI_D_signal[dume2].write(0);	//+
							grant_SWI_D_signal[dume2].write(0); //+
							dume2++;							//+
							t[i][j]->req_SWI_D[s](req_SWI_D_signal[dume2]);
							t[i][j]->grant_SWI_D[s](grant_SWI_D_signal[dume2]);
							req_SWI_D_signal[dume2].write(0);
							grant_SWI_D_signal[dume2].write(0);
							/*if(i==1 && j==1)
							{	cout<<"t["<<i<<"]["<<j<< "]-> ready_tx_SWI["<<TileID2<<
									"](ready_dume["<<dume3-1<<"])::::::::::::"<<endl;
								cout<<"t["<<i<<"]["<<j<< "]-> ack_tx_SWI["<<TileID2<<
									"](ack_dume["<<dume3-1<<"]);"<<endl;
								cout<<"t["<<i<<"]["<<j<< "]-> ready_rx_SWI["<<s<<
									"](ready_dume["<<dume3<<"]);"<<endl;
								cout<<"t["<<i<<"]["<<j<< "]-> ack_rx_SWI["<<s<<
									"](ack_dume["<<dume3<<"]);"<<endl;
							}
							/*{
								cout<< "2"<<endl;
								cout<<"t["<<i<<"]["<<j<<"]-> grant_SWI_D_Master["<<TileID2<<
									"](grant_SWI_D_signal["<<dume2<<"]);"<<endl;
								cout<<"t["<<i<<"]["<<j<<"]->grant_SWI_D["<<s<<"](grant_SWI_D_signal["
									<<dume2<<"])"<<endl;
								cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D_Master["<<TileID2<<"](req_SWI_D_signal["
									<<dume2<<"])"<<endl;
								cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D["<<s<<"](req_SWI_D_signal["
									<<dume2<<"])"<<endl;
							}*/
							dume2++;
							dume3++;
						}
					}

				// cout<<"binding Abitor with Node: "<<TileID2<<" channel: "<<s<<endl;
				// connecting the dumy liks for master signals
				for (int m = NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y;
					 m < MAX_STATIC_DIM * MAX_STATIC_DIM; m++)
				{
					t[i][j]->grant_SWI_D_Master[m](grant_SWI_D_signal[dume2]);
					t[i][j]->req_SWI_D_Master[m](req_SWI_D_signal[dume2]);
					req_SWI_D_signal[dume2].write(0);
					grant_SWI_D_signal[dume2].write(0);

					t[i][j]->ack_tx_SWI[m](ack_dume[dume3]);
					t[i][j]->ready_tx_SWI[m](ready_dume[dume3]);
					ready_dume[dume3].write(0);
					ack_dume[dume3].write(0);
					/*if(i==1 && j==1)
					{
							cout<<"t["<<i<<"]["<<j<< "]-> ready_tx_SWI["<<m<<
								"](ready_dume["<<dume3<<"])::::::::::::"<<endl;
							cout<<"t["<<i<<"]["<<j<< "]-> ack_tx_SWI["<<m<<
								"](ack_dume["<<dume3<<"]);"<<endl;
					}
					/*{
						cout<< "3"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]-> grant_SWI_D_Master["<<m<<
								"](grant_SWI_D_signal["<<dume2<<"]);"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D_Master["<<m<<"](req_SWI_D_signal["
								<<dume2<<"])"<<endl;
					}*/
					dume2++;
					dume3++;
				}
				for (int z = NoximGlobalParams::SW_channel; z < MAX_STATIC_VC; z++)
				{
					t[i][j]->req_SWI_D[z](req_SWI_D_signal[dume2]);
					t[i][j]->grant_SWI_D[z](grant_SWI_D_signal[dume2]);
					req_SWI_D_signal[dume2].write(0);
					grant_SWI_D_signal[dume2].write(0);

					t[i][j]->ready_rx_SWI[z](ready_dume[dume3]);
					t[i][j]->ack_rx_SWI[z](ack_dume[dume3]);
					ready_dume[dume3].write(0);
					ack_dume[dume3].write(0);
					/*if(i==1 && j==1)
						{
							cout<<"t["<<i<<"]["<<j<< "]-> ready_rx_SWI["<<z<<
								"](ready_dume["<<dume3<<"]);"<<endl;
							cout<<"t["<<i<<"]["<<j<< "]-> ack_rx_SWI["<<z<<
								"](ack_dume["<<dume3<<"]);"<<endl;
						}
					/*{
						cout<< "4"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]->grant_SWI_D["<<z<<"](grant_SWI_D_signal["
								<<dume2<<"])"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D["<<z<<"](req_SWI_D_signal["
								<<dume2<<"])"<<endl;
					}*/
					dume2++;
					dume3++;
				}
			}
			else if (s == -1) /// dumy links
			{
				// cout<<"dummy "<<dume2<< endl;
				for (int d = 0; d < MAX_STATIC_DIM * MAX_STATIC_DIM; d++)
				{
					t[i][j]->grant_SWI_D_Master[d](grant_SWI_D_signal[dume2]);
					t[i][j]->req_SWI_D_Master[d](req_SWI_D_signal[dume2]);
					req_SWI_D_signal[dume2].write(0);
					grant_SWI_D_signal[dume2].write(0);

					t[i][j]->ack_tx_SWI[d](ack_dume[dume3]);
					t[i][j]->ready_tx_SWI[d](ready_dume[dume3]);
					ready_dume[dume3].write(0);
					ack_dume[dume3].write(0);
					/*if(i==1 && j==1)
					{
						cout<<"t["<<i<<"]["<<j<< "]-> ready_tx_SWI["<<d<<
							"](ready_dume["<<dume3<<"]):::::::"<<endl;
						cout<<"t["<<i<<"]["<<j<< "]-> ack_tx_SWI["<<d<<
							"](ack_dume["<<dume3<<"]);"<<endl;
					}
					/*{
						cout<< "5"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]-> grant_SWI_D_Master["<<d<<
							"](grant_SWI_D_signal["<<dume2<<"]);"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D_Master["<<d<<"](req_SWI_D_signal["
							<<dume2<<"])"<<endl;
					}*/
					dume2++;
					dume3++;
				}
				for (int z = NoximGlobalParams::SW_channel; z < MAX_STATIC_VC; z++)
				{
					t[i][j]->req_SWI_D[z](req_SWI_D_signal[dume2]);
					t[i][j]->grant_SWI_D[z](grant_SWI_D_signal[dume2]);
					req_SWI_D_signal[dume2].write(0);
					grant_SWI_D_signal[dume2].write(0);

					t[i][j]->ready_rx_SWI[z](ready_dume[dume3]);
					t[i][j]->ack_rx_SWI[z](ack_dume[dume3]);
					ready_dume[dume3].write(0);
					ack_dume[dume3].write(0);
					/*if(i==1 && j==1)
					{
						cout<<"t["<<i<<"]["<<j<< "]-> ready_rx_SWI["<<z<<
							"](ready_dume["<<dume3<<"]);"<<endl;
						cout<<"t["<<i<<"]["<<j<< "]-> ack_rx_SWI["<<z<<
							"](ack_dume["<<dume3<<"]);"<<endl;
					}
					/*{
						cout<< "6"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]->grant_SWI_D["<<z<<"](grant_SWI_D_signal["
							<<dume2<<"])"<<endl;
						cout<<"t["<<i<<"]["<<j<<"]->req_SWI_D["<<z<<"](req_SWI_D_signal["
							<<dume2<<"])"<<endl;
					}*/
					dume2++;
					dume3++;
				}
				// dume3++;
				// cout<<"dummy2"<<endl;
			}
			else
				cout << "error in NoC!!!" << endl;

		} // end for j
	}	  // end for i

	////end connecting local arbiters///////////////////////////////////////////////////////////////////////////

	/// Connecting SWI data channels////////////////////////////////////////////////////////////////////////////
	/*for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++)
	{
		  for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++)
		  {
		int s=check_reserv_SW(j * NoximGlobalParams::mesh_dim_x + i);
		if(s !=-1)
		{
			for (int m = 0; m < NoximGlobalParams::mesh_dim_x; m++)
			for (int n = 0; n < NoximGlobalParams::mesh_dim_y; n++)
			{
			   if(m !=i || n != j)
			   {
				int TileID = n* NoximGlobalParams::mesh_dim_x + m;
				t[i][j]->SWI_Master[TileID](SWI_Data[DataSiganl]);
					t[m][n]->SWI_Slave(SWI_Data[DataSiganl]);
				DataSiganl++;
				   }
			}


			 //dummy limks in master
			 for(int z= NoximGlobalParams::SW_channel; z< MAX_STATIC_DIM * MAX_STATIC_DIM; z++)
			 {
			 t[i][j]->SWI_Master[z](SWI_Data[dume3]);
			 dume3 ++;
			 }
		}
		else
		{
			 for(int z= 0; z< MAX_STATIC_DIM * MAX_STATIC_DIM; z++)
			 {
			 t[i][j]->SWI_Master[z](SWI_Data[dume3]);
			 dume3 ++;
			 }
		}//end else not master
		  }// end for j
	}// end for i*/

	/// end connecting SWI data channels//////////////////////////////////////////////////////////////////////////

	// dummy NoximNoP_data structure
	NoximNoP_data tmp_NoP;

	tmp_NoP.sender_id = NOT_VALID;

	for (int i = 0; i < DIRECTIONS; i++)
	{
		tmp_NoP.channel_status_neighbor[i].free_slots = NOT_VALID;
		tmp_NoP.channel_status_neighbor[i].available = false;
	}

	// Clear signals for borderline nodes
	for (int i = 0; i <= NoximGlobalParams::mesh_dim_x; i++)
	{
		for (int c = 0; c < MAX_STATIC_VC; c++) /// vc
		{
			req_to_south[i][0][c] = 0;
			ack_to_north[i][0][c] = 0;
			req_to_north[i][NoximGlobalParams::mesh_dim_y][c] = 0;
			ack_to_south[i][NoximGlobalParams::mesh_dim_y][c] = 0;

			free_slots_to_south[i][0][c].write(NOT_VALID);
			free_slots_to_north[i][NoximGlobalParams::mesh_dim_y][c].write(NOT_VALID);
		}

		NoP_data_to_south[i][0].write(tmp_NoP);
		NoP_data_to_north[i][NoximGlobalParams::mesh_dim_y].write(tmp_NoP);
	}

	for (int j = 0; j <= NoximGlobalParams::mesh_dim_y; j++)
	{
		for (int c = 0; c < MAX_STATIC_VC; c++) /// vc
		{
			req_to_east[0][j][c] = 0;
			ack_to_west[0][j][c] = 0;
			req_to_west[NoximGlobalParams::mesh_dim_x][j][c] = 0;
			ack_to_east[NoximGlobalParams::mesh_dim_x][j][c] = 0;

			free_slots_to_east[0][j][c].write(NOT_VALID);
			free_slots_to_west[NoximGlobalParams::mesh_dim_x][j][c].write(NOT_VALID);
		}

		NoP_data_to_east[0][j].write(tmp_NoP);
		NoP_data_to_west[NoximGlobalParams::mesh_dim_x][j].write(tmp_NoP);
	}

	// invalidate reservation table entries for non-exhistent channels
	for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++)
	{
		t[i][0]->r->reservation_table.invalidate(DIRECTION_NORTH);
		// cout <<"invalidate node: "<<t[i][0]->pe->local_id<<" port: "<<DIRECTION_NORTH<<endl;
		t[i][NoximGlobalParams::mesh_dim_y - 1]->r->reservation_table.invalidate(DIRECTION_SOUTH);
		// cout <<"invalidate node: "<<t[i][NoximGlobalParams::mesh_dim_y - 1]->pe->local_id<<" port: "<<DIRECTION_SOUTH<<endl;
	}
	for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++)
	{
		t[0][j]->r->reservation_table.invalidate(DIRECTION_WEST);
		// cout <<"invalidate node: "<<t[0][j]->pe->local_id<<" port: "<<DIRECTION_WEST<<endl;
		t[NoximGlobalParams::mesh_dim_x - 1][j]->r->reservation_table.invalidate(DIRECTION_EAST);
		// cout <<"invalidate node: "<<t[NoximGlobalParams::mesh_dim_x - 1][j]->pe->local_id<<" port: "<<DIRECTION_EAST<<endl;
	}

	NoximFlit not_valid = DomyFlit();
	not_valid.timestamp = NOT_VALID;
	not_valid.VCID = NOT_VALID;
	if (dume < MAX_STATIC_DIM * MAX_STATIC_DIM)
	{ // cout<<"invalidate Abitor port starting with: "<<dume<<endl;
		for (int j = dume; j < MAX_STATIC_DIM * MAX_STATIC_DIM; j++)
		{
			assert(j >= 0 && j < MAX_STATIC_DIM * MAX_STATIC_DIM); // Ammar
			// cout<<"dume binding Abitor port: "<<j<<endl;
			req_SWI[j](req_SWI_signal[j]);
			grant_SWI[j](grant_SWI_signal[j]);
			// G_siganl not_valid;
			// not_valid.req_id=NOT_VALID;
			// not_valid.vc=NOT_VALID;
			grant_SWI_signal[j].write(not_valid);
			req_SWI_signal[j].write(not_valid);
		}
	}
	// cout <<"buildMesh end"<<endl;
}

// Global Arbiter to control abitration and allocation for the resources for the SWI
void NoximNoC::GlobalArbiter()
{
	// cout <<"Arbiter start"<<endl;
	if (reset.read())
	{
		start_from_port = 0;
		start_from_vc = 0;
		period = 0;
		for (int j = 0; j < NoximGlobalParams::SW_channel; j++)
		{
			done[j] = 0;
			grant[j] = NOT_RESERVED;
			NoximFlit grant_siganl = DomyFlit();
			grant_siganl.timestamp = NOT_RESERVED;
			grant_siganl.VCID = NOT_RESERVED;
			grant_SWI[j].write(grant_siganl);
			grant_MAB[j] = 0;
			grant_ID[j] = NOT_RESERVED;
			grant_ID_src[j] = NOT_RESERVED;
			for (int i = 0; i < NoximGlobalParams::VC_No; i++)
			{
				SWI_Reserve_BM[i][j] = NOT_RESERVED;
				SWI_Reserve_MAB[i][j] = Integer2Bin(0);
			}
		}
		for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
			Hold[b] = 0;
	}

	else
	{

		if (NoximGlobalParams::Arbitration_type == PERIOD_ARB)
		{
			// cout<<"fixed period"<<endl;
			// Release
			// search for reserving node to remove it
			for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
			{
				NoximFlit flit = req_SWI[i];
				if ((flit.flit_type == FLIT_TYPE_TAIL) && (grant[i] != NOT_RESERVED))
				{
					assert(grant[i] >= 0 && grant[i] < NoximGlobalParams::VC_No); // Ammar
					SWI_Reserve_BM[grant[i]][i] = NOT_RESERVED;
					SWI_Reserve_MAB[grant[i]][i] = Integer2Bin(0);
					// cout<<sc_time_stamp().to_double()/1000<<"*releasing vc: "<<grant[i]<<" channel: "<<i<<endl;
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					// G_siganl grant_siganl;
					// grant_siganl.req_id=NOT_RESERVED;
					// grant_siganl.vc=NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
					grant[i] = NOT_RESERVED;
					grant_ID[i] = NOT_RESERVED;
					grant_ID_src[i] = NOT_RESERVED;
					// grant_MAB[i]=0;
				}
				else if ((flit.flit_type == FLIT_TYPE_HEAD) && (grant[i] != NOT_RESERVED) &&
						 (grant_ID[i] != flit.timestamp)) //&& (grant_ID_src[i]==flit.src_id ))
				{
					assert(grant[i] >= 0 && grant[i] < NoximGlobalParams::VC_No); // Ammar
					SWI_Reserve_BM[grant[i]][i] = NOT_RESERVED;
					SWI_Reserve_MAB[grant[i]][i] = Integer2Bin(0);
					// cout<<sc_time_stamp().to_double()/1000<<"releasing vc: "<<grant[i]<<" channel: "<<i<<endl;
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					// G_siganl grant_siganl;
					// grant_siganl.req_id=NOT_RESERVED;
					// grant_siganl.vc=NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
					grant[i] = NOT_RESERVED;
					grant_ID[i] = NOT_RESERVED;
					grant_ID_src[i] = NOT_RESERVED;
					// grant_MAB[i]=0;
				}
				// else
				// cout<<sc_time_stamp().to_double()/1000<<":Not releasing channel["<<i<<"], Flit type:"<<flit.flit_type<<" ,time: "<<flit.timestamp<<" grant: "<<grant[i]<< " grant_ID: "<<grant_ID[i]<<endl;
			}

			/// Reservation
			// finding the oldest reguest
			double t = NoximGlobalParams::simulation_time + DEFAULT_RESET_TIME;
			for (int j = 0; j < NoximGlobalParams::SW_channel; j++)
			{
				NoximFlit flit = req_SWI[j].read();
				// if(flit.flit_type== FLIT_TYPE_HEAD)
				// cout<<sc_time_stamp().to_double()/1000<<":request from: "<<j<<" time stamp: "<<flit.timestamp<<endl;
				if ((flit.flit_type == FLIT_TYPE_HEAD) && (flit.timestamp < t))
				{
					t = flit.timestamp;
					start_from_port = j;
				}
			}

			for (int j = 0; j < NoximGlobalParams::SW_channel; j++)
			{
				int i = (start_from_port + j) % NoximGlobalParams::SW_channel;
				NoximFlit flit = req_SWI[i];
				// cout<<sc_time_stamp().to_double()/1000<<": start reservation with port: "<<i<<endl;
				int v = 0;
				if (flit.flit_type == FLIT_TYPE_HEAD)
				{
					while ((grant[i] == NOT_RESERVED) && (v < NoximGlobalParams::VC_No))
					{
						bool X = 0; // flag of multicast shared sinks nodes if =1 do not reserve
						// cout<<"check for shared members, channel: "<<i<<" MAB: "<< Bin2Integ(flit.MAB)<<endl;
						// checking if it intersect with other granted multicast
						for (int k = 0; k < NoximGlobalParams::SW_channel; k++)
						{
							if ((grant[k] != NOT_RESERVED) && (k != i)) //
							{
								assert(grant[k] >= 0 && grant[k] < NoximGlobalParams::VC_No);
								vector<bool> Reserve_MAB = SWI_Reserve_MAB[v][k];
								// cout<<"check MAB["<<v<<"]["<<k<<"] "<<NoximGlobalParams::SWI[v].Reserve_MAB[i]<<endl;
								for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
								{
									if ((Reserve_MAB[b] == 1) && (flit.MAB[b] == 1))
									{
										X = 1;
										// cout<<"find shared member reserved MAB:"<<NoximGlobalParams::SWI[v].Reserve_MAB
										//[k]<<" and request MAB: "<<Bin2Integ(flit.MAB)<<endl;
									}
								}
							}
						}			// end for ...check intersect
						if (X == 0) // if multicasting groups does not has shared members
						{
							SWI_Reserve_BM[v][i] = 1;
							SWI_Reserve_MAB[v][i] = flit.MAB;
							// cout<<"reserving ["<<v<<"]["<<i<<"] for Chan: "<<i<<endl;
							grant[i] = v;
							grant_ID[i] = flit.timestamp;
							grant_ID_src[i] = flit.src_id;
							GAdyn();
							GAtxrx();
						}
						v++;
					} // end for of VC (while)
				}	  // end no request
			}		  // end for round robin
			// start_from_port ++;

			/// Allocation Round robin for fixed period of time
			period++;
			if ((period % NoximGlobalParams::Arbitration_period) == 0)
			{
				for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
				{
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
				}
				int vc = 0;
				int Alocated = 0;
				while (vc < NoximGlobalParams::VC_No && Alocated == 0)
				{
					int v = (start_from_vc + vc) % (NoximGlobalParams::VC_No);
					for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
					{
						if (SWI_Reserve_BM2[v][i] == 1)
						{
							NoximFlit grant_siganl = DomyFlit();
							grant_siganl.timestamp = grant_ID[i];
							grant_siganl.src_id = grant_ID_src[i];
							grant_siganl.VCID = v;
							// G_siganl grant_siganl;
							// grant_siganl.req_id=flit.timestamp;
							// grant_siganl.vc=v;
							grant_SWI[i].write(grant_siganl);
							// cout<<sc_time_stamp().to_double()/1000<<": Grant to channel: "<<i<<" Vc: "<<v<<" Timestamp: "<<grant_siganl.timestamp<<" MAP: "<<Bin2Integ(SWI_Reserve_MAB[v][i])<<endl;
							Alocated = 1;
							GAtxrx();
						}
					}
					if (Alocated == 1)
						start_from_vc++;
					vc++;

				} // while
			}	  // switch end of allocation

			for (int v = 0; v < NoximGlobalParams::VC_No; v++) // to add 2 cycle delay
				for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
					SWI_Reserve_BM2[v][i] = SWI_Reserve_BM[v][i];
                 	//   cout << "Time1: " << sc_time_stamp().to_double() / 1000 
                 	       
                 	//   << endl; // issraa_try  <<SWI_Reserve_BM[v][i]
			
			
		}																	 // end if global fixed period

		///////////////////////////Global Hold and release Round Robin////////////////////////////////////////////////
		else if (NoximGlobalParams::Arbitration_type == HOLD_RR_ARB)
		{
			// cout<<"hold release"<<endl;
			// Release
			// search for reserving node to remove it
			for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
			{
				NoximFlit flit = req_SWI[i];
				if ((flit.flit_type == FLIT_TYPE_TAIL) && (grant[i] != NOT_RESERVED))
				{

					assert(grant[i] >= 0 && grant[i] < NoximGlobalParams::VC_No);
					SWI_Reserve_BM[grant[i]][i] = NOT_RESERVED;
					SWI_Reserve_MAB[grant[i]][i] = Integer2Bin(0);
					// cout<<sc_time_stamp().to_double()/1000<<"*********releasing vc: "<<grant[i]<<" channel: "<<i<<endl;
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					// G_siganl grant_siganl;
					// grant_siganl.req_id=NOT_RESERVED;
					// grant_siganl.vc=NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
					grant[i] = NOT_RESERVED;
					grant_ID[i] = NOT_RESERVED;
					grant_ID_src[i] = NOT_RESERVED;
					// grant_MAB[i]=0;
				}
				if ((flit.flit_type == FLIT_TYPE_HEAD) && (grant[i] != NOT_RESERVED) &&
					(grant_ID[i] != flit.timestamp)) //&& (grant_ID_src[i]==flit.src_id ))
				{

					assert(grant[i] >= 0 && grant[i] < NoximGlobalParams::VC_No);
					SWI_Reserve_BM[grant[i]][i] = NOT_RESERVED;
					SWI_Reserve_MAB[grant[i]][i] = Integer2Bin(0);
					// cout<<sc_time_stamp().to_double()/1000<<"********releasing vc: "<<grant[i]<<" channel: "<<i<<endl;
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					// G_siganl grant_siganl;
					// grant_siganl.req_id=NOT_RESERVED;
					// grant_siganl.vc=NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
					grant[i] = NOT_RESERVED;
					grant_ID[i] = NOT_RESERVED;
					grant_ID_src[i] = NOT_RESERVED;
					// grant_MAB[i]=0;
				}
			}

			/// Reservation
			for (int j = 0; j < NoximGlobalParams::SW_channel; j++)
			{
				int i = (start_from_port + j) % NoximGlobalParams::SW_channel;
				NoximFlit flit = req_SWI[i];
				// cout<<sc_time_stamp().to_double()/1000<<": start reservation with port: "<<i<<endl;
				int v = 0;
				if (flit.flit_type == FLIT_TYPE_HEAD)
				{
					while ((grant[i] == NOT_RESERVED) && (v < NoximGlobalParams::VC_No))
					{
						bool X = 0; // flag of multicast shared sinks nodes if =1 do not reserve
						// cout<<"check for shared members, channel: "<<i<<" MAB: "<< Bin2Integ(flit.MAB)<<
						// checking if it intersect with other granted multicast
						for (int k = 0; k < NoximGlobalParams::SW_channel; k++)
						{
							if ((grant[k] != NOT_RESERVED) && (k != i)) //
							{
								vector<bool> Reserve_MAB = SWI_Reserve_MAB[v][k];
								// cout<<"check MAB["<<v<<"]["<<k<<"] "<<NoximGlobalParams::SWI[v].Reserve_MAB[i]<<endl;
								for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
								{
									if ((Reserve_MAB[b] == 1) && (flit.MAB[b] == 1))
									{
										X = 1;
										// cout<<"find shared member reserved MAB:"<<NoximGlobalParams::SWI[v].Reserve_MAB
										//[k]<<" and request MAB: "<<Bin2Integ(flit.MAB)<<endl;
									}
								}
							}
						}			// end for ...check intersect
						if (X == 0) // if multicasting groups does not has shared members
						{
							SWI_Reserve_BM[v][i] = 1;
							SWI_Reserve_MAB[v][i] = flit.MAB;
							// cout<<"reserving ["<<v<<"]["<<i<<"] for Chan: "<<i<<endl;
							grant[i] = v;
							grant_ID[i] = flit.timestamp;
							grant_ID_src[i] = flit.src_id;
							NoximFlit grant_siganl = DomyFlit();
							grant_siganl.timestamp = grant_ID[i];
							grant_siganl.src_id = grant_ID_src[i];
							grant_siganl.VCID = v;
							grant_SWI[i].write(grant_siganl);
						}
						v++;
					} // end for of VC (while)
				}	  // end no request
			}		  // end for round robin
			start_from_port++;

		} // end hold and release Rond robin

		///////////////////////////////////////hold and release time stamp///////////////////////
		else if (NoximGlobalParams::Arbitration_type == HOLD_TIME_ARB)
		{
			// cout<<"hold release"<<endl;
			// Release
			// search for reserving node to remove it
			for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
			{
				NoximFlit flit = req_SWI[i];
				if ((flit.flit_type == FLIT_TYPE_TAIL) && (grant[i] != NOT_RESERVED))
				{

					assert(grant[i] >= 0 && grant[i] < NoximGlobalParams::VC_No);
					SWI_Reserve_BM[grant[i]][i] = NOT_RESERVED;
					// SWI_Reserve_BM2[grant[i] ][i]=NOT_RESERVED;
					vector<bool> Reserve_MAB = SWI_Reserve_MAB[grant[i]][i];
					for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
					{
						if (Reserve_MAB[b] == 1)
						{
							Hold[b] = 0;
						}
					}
					SWI_Reserve_MAB[grant[i]][i] = Integer2Bin(0);
					// cout<<sc_time_stamp().to_double()/1000<<"*********releasing vc: "<<grant[i]<<" channel: "<<i<<endl;
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					// G_siganl grant_siganl;
					// grant_siganl.req_id=NOT_RESERVED;
					// grant_siganl.vc=NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
					grant[i] = NOT_RESERVED;
					grant_ID[i] = NOT_RESERVED;
					grant_ID_src[i] = NOT_RESERVED;
					// grant_MAB[i]=0;
				}
				if ((flit.flit_type == FLIT_TYPE_HEAD) && (grant[i] != NOT_RESERVED) &&
					(grant_ID[i] != flit.timestamp)) //&& (grant_ID_src[i]==flit.src_id ))
				{

					assert(grant[i] >= 0 && grant[i] < NoximGlobalParams::VC_No);
					SWI_Reserve_BM[grant[i]][i] = NOT_RESERVED;
					// SWI_Reserve_BM2[grant[i] ][i]=NOT_RESERVED;
					vector<bool> Reserve_MAB = SWI_Reserve_MAB[grant[i]][i];
					for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
					{
						if (Reserve_MAB[b] == 1)
						{
							Hold[b] = 0;
						}
					}
					SWI_Reserve_MAB[grant[i]][i] = Integer2Bin(0);
					// cout<<sc_time_stamp().to_double()/1000<<"********releasing vc: "<<grant[i]<<" channel: "<<i<<endl;
					NoximFlit grant_siganl = DomyFlit();
					grant_siganl.timestamp = NOT_RESERVED;
					grant_siganl.VCID = NOT_RESERVED;
					// G_siganl grant_siganl;
					// grant_siganl.req_id=NOT_RESERVED;
					// grant_siganl.vc=NOT_RESERVED;
					grant_SWI[i].write(grant_siganl);
					grant[i] = NOT_RESERVED;
					grant_ID[i] = NOT_RESERVED;
					grant_ID_src[i] = NOT_RESERVED;
					// grant_MAB[i]=0;
				}
			}

			/// Reservation
			// finding the oldest reguest
			double t = NoximGlobalParams::simulation_time + DEFAULT_RESET_TIME;
			for (int j = 0; j < NoximGlobalParams::SW_channel; j++)
			{
				NoximFlit flit = req_SWI[j].read();
				// if(flit.flit_type== FLIT_TYPE_HEAD)
				// cout<<sc_time_stamp().to_double()/1000<<":request from: "<<j<<" time stamp: "<<flit.timestamp<<endl;
				if ((flit.flit_type == FLIT_TYPE_HEAD) && (flit.timestamp < t))
				{
					t = flit.timestamp;
					start_from_port = j;
					// cout<<"flit.timestamp"<<flit.timestamp<<endl;   //issraa_try
				}
			}
			// cout<<" "<<start_from_port;
			for (int j = 0; j < NoximGlobalParams::SW_channel; j++)
			{
				int i = (start_from_port + j) % NoximGlobalParams::SW_channel;
				NoximFlit flit = req_SWI[i];
				// cout<<sc_time_stamp().to_double()/1000<<": start reservation with port: "<<i<<endl;
				int v = 0;
				if (flit.flit_type == FLIT_TYPE_HEAD)
				{
					while ((grant[i] == NOT_RESERVED) && (v < NoximGlobalParams::VC_No))
					{
						bool X = 0; // flag of multicast shared sinks nodes if =1 do not reserve
						// cout<<"check for shared members, channel: "<<i<<" MAB: "<< Bin2Integ(flit.MAB)<<
						// checking if it intersect with other granted multicast
						for (int k = 0; k < NoximGlobalParams::SW_channel; k++)
						{
							if ((grant[k] != NOT_RESERVED) && (k != i)) //
							{
								vector<bool> Reserve_MAB = SWI_Reserve_MAB[v][k];
								// cout<<"check MAB["<<v<<"]["<<k<<"] "<<NoximGlobalParams::SWI[v].Reserve_MAB[i]<<endl;
								for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
								{
									if ((Reserve_MAB[b] == 1) && (flit.MAB[b] == 1))
									{
										X = 1;
										// cout<<"find shared member reserved MAB:"<<NoximGlobalParams::SWI[v].Reserve_MAB
										//[k]<<" and request MAB: "<<Bin2Integ(flit.MAB)<<endl;
									}
								}
							}
						}			// end for ...check intersect
						if (X == 0) // if multicasting groups does not has shared members
						{
							SWI_Reserve_BM[v][i] = 1;
							SWI_Reserve_MAB[v][i] = flit.MAB;
							// cout<<sc_time_stamp().to_double()/1000<<": reserve["<<v<<"]["<<i<<"] for Chan: "<<i<<endl;
							for (int k = 0; k < NoximGlobalParams::SW_channel; k++)
							{
								NoximFlit f = req_SWI[k];
								// cout<<" Req["<<k<<"]: "<<f.flit_type<<" MAB "<<Bin2Integ(f.MAB)<<" time: "
								//<<f.timestamp<<" Src "<<f.src_id<<", ";
							}
							// cout<<endl<<endl;
							grant[i] = v;
							grant_ID[i] = flit.timestamp;
							grant_ID_src[i] = flit.src_id;
							NoximFlit grant_siganl = DomyFlit();
							// grant_siganl.timestamp = grant_ID[i];
							// grant_siganl.src_id = grant_ID_src[i];
							// grant_siganl.VCID=v;
							// grant_SWI[i].write(grant_siganl);
						}
						v++;
					} // end for of VC (while)
				}	  // end no request
			}		  // end for round robin
			// start_from_port ++;

			/// Allocation Round robin for Hold and release
			for (int vc = 0; vc < NoximGlobalParams::VC_No; vc++)
			{
				int v = (start_from_vc + vc) % (NoximGlobalParams::VC_No);

				for (int ii = 0; ii < NoximGlobalParams::SW_channel; ii++)
				{
					int i = (start_from_chan + ii) % (NoximGlobalParams::SW_channel);

					if (SWI_Reserve_BM2[v][i] == 1)
					{
						// cout<< "reserved channel: "<<i<<endl;
						int H = 0;
						vector<bool> Reserve_MAB = SWI_Reserve_MAB[v][i];
						for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
						{
							if ((Reserve_MAB[b] == 1) && (Hold[b] == 1))
							{
								H = 1;
								// cout<<"find intersect with hold signal bit:"<<b
								//<<" and request MAB: "<<Bin2Integ(Reserve_MAB)<<endl;
							}
						}
						if (H == 0)
						{
							for (int b = 0; b < NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y; b++)
							{
								if (Reserve_MAB[b] == 1)
								{
									Hold[b] = 1;
								}
							}
							NoximFlit grant_siganl = DomyFlit();
							grant_siganl.timestamp = grant_ID[i];
							grant_siganl.src_id = grant_ID_src[i];
							grant_siganl.VCID = v;
							grant_SWI[i].write(grant_siganl);
							// cout<<sc_time_stamp().to_double()/1000<<": Grant to channel: "<<i<<" Vc: "<<v<<" Timestamp: "<<grant_siganl.timestamp<<" MAP: "<<Bin2Integ(SWI_Reserve_MAB[v][i])<<endl;
							GAtxrx();
						}
					} // if reserved
				}	  // for channels
			}		  // for vc
			start_from_vc++;
			start_from_chan++;
			for (int v = 0; v < NoximGlobalParams::VC_No; v++) // to add 2 cycle delay
				for (int i = 0; i < NoximGlobalParams::SW_channel; i++)
					SWI_Reserve_BM2[v][i] = SWI_Reserve_BM[v][i];
			// cout << "Time2: "<< sc_time_stamp().to_double() / 1000 << endl;   //issraa_try
		} // end hold and release time stamp
	}	  // else reset=0

	GAstatic();
	// cout <<"Arbiter end"<<endl;
}

void NoximNoC::GAdyn()
{
	// double PWR_GA_Dyn= 2.3982E-12;
	pwr += PWR_GA_Dyn;
}

void NoximNoC::GAstatic()
{
	// double PWR_GA_STANDBY =2.965E-14 /2.0;
	pwr += PWR_GA_STANDBY;
}

void NoximNoC::GAtxrx()
{
	// double PWR_GA_TxRx = 6E-3 * 0.5E-9 *36;		//MAB(24), Req/Rel(1), TimeStamp(10)
	pwr += PWR_GA_TxRx;
}

double NoximNoC::getPower() // Ammar
{
	return pwr;
}

NoximTile *NoximNoC::searchNode(const int id) const
{
	for (int i = 0; i < NoximGlobalParams::mesh_dim_x; i++)
		for (int j = 0; j < NoximGlobalParams::mesh_dim_y; j++)
			if (t[i][j]->r->local_id == id)
				return t[i][j];

	return NULL;
}
