./noxim -dimx 6 -dimy 6 -channel 2 -traffic table RT -routing oddevenSW -pir .01 0 >> mesh01
./noxim -dimx 6 -dimy 6 -channel 2 -traffic table RT -routing oddevenSW -pir .02 0 >> mesh01
