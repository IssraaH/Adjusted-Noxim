/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the switch reservation table
 */

#include "NoximReservationTable.h"
//int NoximReservationTable::Check_Dir()
//{
//int k;
//if(NoximGlobalParams::SW_channel>0)
//  k=2;
//else
//  k=1;
//return k;
//};
NoximReservationTable::NoximReservationTable()
{
    clear();
}

void NoximReservationTable::clear()
{
//cout<<"reservation table clear"<<endl;
int k=1;
if(NoximGlobalParams::SW_channel>0)
 k=2;

    //rtable.resize((DIRECTIONS + k)* MAX_STATIC_VC *NoximGlobalParams::SW_channel);    ///vc +k Ammar
    rtable.resize((DIRECTIONS + k)* NoximGlobalParams::VC_No *NoximGlobalParams::TAG );    ///vc +k Ammar
    //cout<<"resize"<<(DIRECTIONS + k)*NoximGlobalParams::VC_No<<endl;
    // note that NOT_VALID entries should remain untouched
    if(NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB)
    {
        for (int i= 0; i <(DIRECTIONS + k)*NoximGlobalParams::VC_No *NoximGlobalParams::TAG ; i++) ///vc
	{
	    if (rtable[i] != NOT_VALID)
	    {
		int out =i %  ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);
		int tag =i /  ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);
		//unvalidate the reservation table enteries with tag>0 except for up and local ports
		if(tag ==0 || out % (DIRECTIONS + k)==DIRECTION_LOCAL ||out% (DIRECTIONS + k) ==DIRECTION_UP)
			{rtable[i] = NOT_RESERVED;}
		else
		{
			rtable[i] = NOT_VALID;
			//if(i==40)
			//	cout<<"ERRRRRRRRRRRRRRRRRRRRROR out: "<<out<<" tag "<<tag<<endl;
		}		
	    }
	}
    }
    else
    {
        for (int i = 0; i < (DIRECTIONS + k)*NoximGlobalParams::VC_No ; i++)			///vc
	{
	    if (rtable[i] != NOT_VALID)
	    {
		//else if((rtable[i]%(DIRECTIONS + k)) <NoximGlobalParams::VC_No) //MAX_STATIC_VC
		//else if((i % (DIRECTIONS + k)) <NoximGlobalParams::VC_No) //
			{rtable[i] = NOT_RESERVED;}
	    	//else
			//{rtable[i] = NOT_VALID;}
	    }
	}
     }
}

bool NoximReservationTable::isAvailable(const int port_out) const
{
int k=1;
if(NoximGlobalParams::SW_channel>0)
 k=2;
//if(!(port_out >= 0 && port_out < ((DIRECTIONS + k)* NoximGlobalParams::VC_No* NoximGlobalParams::TAG) ))
//cout<<"is available: port out: "<<port_out<<" tag "<<NoximGlobalParams::TAG<<endl;
assert(port_out >= 0 && port_out < ((DIRECTIONS + k)* NoximGlobalParams::VC_No* NoximGlobalParams::TAG) ); ///vc +k Ammar
    return (rtable[port_out] == NOT_RESERVED);
}

void NoximReservationTable::reserve(const int port_in, const int port_out, const bool MB, const int local_id)
{
//if(local_id==6 )
//{
//cout<< sc_time_stamp().to_double()/1000 <<", reserve"<<",Router_id["<<local_id<<"],port_in ["<<port_in<<"],port_out["<<port_out<<"],"<<endl;               //Issraa
//cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< "], local_coord.x [" << local_coord.x
			  //    << "], local_coord.y [" << local_coord.y << "]," << "], Input["  << i <<"] try to reserve to Output[" <<o<<"], flit: " 
			    //  <<flit <<" curently reserved to: " << reservation_table.getInputPort(i) <<endl;
//}
int k=1;
if(NoximGlobalParams::SW_channel>0)
 k=2;
    // reservation of reserved/not valid ports is illegal. Correctness
    // should be assured by NoximReservationTable users
    assert(isAvailable(port_out));
    // check for previous reservation to be released
    vector<int> port = getOutputPort(port_in);

//When we do have tag=0 then this step will be pointless so no need for a conditional statment
int Tagi= port_in / ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);//i for input
int OUTi= port_in % ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);
int Tago_res= port[0] / ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);//o for output
int OUTo_res= port[0] % ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);
int Tago= port_out / ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);//o for output
int OUTo= port_out % ((DIRECTIONS + k)	* NoximGlobalParams::VC_No);
//this part to release already reserved ports by the same  input port except in few multicasting cases forking or if the direction is up and the request already then sended to the arbiter 
if(!(MB==0 && (OUTo_res % (DIRECTIONS + k))==DIRECTION_UP))//so it will not request SWI from GA and back down
{
  if(NoximGlobalParams::BM_Mode==HYBRID_ARCH && MB==1 )
  {
     if(!( ((OUTo% (DIRECTIONS + k))==DIRECTION_LOCAL) && (OUTo_res % (DIRECTIONS + k))==DIRECTION_UP))
     {
	//cout <<"do not Fork MB: "<<MB<<" port out: "<<port_out<<"currently reserve"<<port[0]<<endl;
        if (port[0] != NOT_RESERVED)
	  release(port[0], local_id);
     }
     else if ( (OUTo % (DIRECTIONS + k))==DIRECTION_LOCAL && (OUTo_res % (DIRECTIONS + k)) == DIRECTION_UP && port.size() >= 2)
     {
	for(int i =1; i<port.size(); i++)
	{
	    if (port[i] != NOT_RESERVED)
		release(port[i], local_id);
	}
     }
  }
  else if (NoximGlobalParams::BM_Mode==VCT && MB==1)
  {
     //if (port[0] != NOT_RESERVED)
	//release(port[0]);
  }
  else
  {
     if(port.size()>1)
     	{cout<<sc_time_stamp().to_double()/1000<<": Error Baseline Arch and reserve more than one port:";
	for(int z=0; z<port.size();z++)
		cout<<port[z];
	cout<<endl<<endl;
	
	}
     if (port[0] != NOT_RESERVED)
	release(port[0], local_id);
  }

 rtable[port_out] = port_in;
}//end if not reserved by UP

//issraa
//if(local_id==6)
//	{cout <<"&&&&&&&& reserve port: "<<port_out<<" for port in: "<<port_in<<endl;
	//cout<<"RT[";
	//for(int i = 0; i < (DIRECTIONS + k)*NoximGlobalParams::VC_No* NoximGlobalParams::TAG; i++)	
		//cout<<rtable[i]<<",";
	//cout<<"]"<<endl;
//	}
}

void NoximReservationTable::release(const int port_out, const int local_id)
{
    int k=1;
    if(NoximGlobalParams::SW_channel>0)
 	k=2;
    //cout <<"NoximReservationTable::release 1";
   //if(local_id==25)
    //cout<<rtable[port_out]<<" release: port out: "<< port_out <<"^^^^^^%%%%%%^^^^^^"<<endl<<endl;
    ///vc +k Ammar tag
    assert(port_out >= 0 && port_out <((DIRECTIONS + k)*NoximGlobalParams::VC_No*NoximGlobalParams::TAG));
    // there is a valid reservation on port_out ///vc
    assert(rtable[port_out] >= 0 && rtable[port_out] < (DIRECTIONS + k)* NoximGlobalParams::VC_No *
	 NoximGlobalParams::TAG); 
    rtable[port_out] = NOT_RESERVED;
}

vector <int> NoximReservationTable::getOutputPort(const int port_in) const
{
    int k=1;
    if(NoximGlobalParams::SW_channel>0)						//Ammar
 	k=2;
    	///vc
   // cout <<"NoximReservationTable::getOutputPort: for port in: "<< port_in<<" vc "<< NoximGlobalParams::VC_No <<"NoximGlobalParams::TAG"<<NoximGlobalParams::TAG<<endl;
    assert(port_in >= 0 && port_in < ((DIRECTIONS + k)* NoximGlobalParams::VC_No * NoximGlobalParams::TAG));
    vector <int> ports;
    for (int i = 0; i < (DIRECTIONS + k)*NoximGlobalParams::VC_No* NoximGlobalParams::TAG; i++)		///vc 
	if (rtable[i] == port_in)
		ports.push_back(i);			// port_in reserved outport(s) i

    if(ports.size() == 0)
	ports.push_back(NOT_RESERVED);			// semantic: port_in currently doesn't reserve any out port
//if( port_in==3)
//{
//cout <<"NoximReservationTable::getOutputPort: for port in: "<< port_in<<endl;
 //for (int i = 0; i < ports.size(); i++)  
//	cout<<" "<<ports[i];
//cout<<endl;
//}
	 	
    return ports;							
}


int NoximReservationTable::getInputPort(const int port_out) const
{
    int k=1;
    if(NoximGlobalParams::SW_channel>0)						//Ammar
 	k=2;
    //cout <<"NoximReservationTable::getOutputPort";
    ///vc
    assert(port_out >= 0 && port_out < ((DIRECTIONS + k)* NoximGlobalParams::VC_No* NoximGlobalParams::TAG));
	    return rtable[port_out];						// port_in reserved outport i
}

// makes port_out no longer available for reservation/release
void NoximReservationTable::invalidate(const int port_out)
{
   int k=1;
   if(NoximGlobalParams::SW_channel>0)
  	k=2;
   int channel;
   if(NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB)
   {
      for(int t=0; t< NoximGlobalParams::TAG; t++ )
	for (int c = 0; c < NoximGlobalParams::VC_No ; c++)			///vc
	{
		channel= port_out+ (DIRECTIONS + k)*c + (DIRECTIONS + k)*NoximGlobalParams::VC_No* t;	//
//cout <<"invalidate "<<channel<<" vc: "<<channel/(DIRECTIONS + k)<<" port: "<<channel%(DIRECTIONS + k)<<endl;
    		rtable[channel] = NOT_VALID;
	}
   }
   else
   {
	for (int c = 0; c < NoximGlobalParams::VC_No ; c++)			///vc
	{
		channel = port_out+ (DIRECTIONS + k)* c;			///vc + ((DIRECTIONS + k)
//cout <<"invalidate "<<channel<<" vc: "<<channel/(DIRECTIONS + k)<<" port: "<<channel%(DIRECTIONS + k)<<endl;
    		rtable[channel] = NOT_VALID;
	}
    }
}
