/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the declaration of the global statistics
 */

#ifndef __NOXIMGLOBALSTATS_H__
#define __NOXIMGLOBALSTATS_H__

#include <iostream>
#include <vector>
#include <iomanip>
#include "NoximNoC.h"
#include "NoximTile.h"
using namespace std;

class NoximGlobalStats {

  public:

    NoximGlobalStats(const NoximNoC * _noc, const double pwr);

    // Returns the aggragated average delay (cycles)
    double getAverageDelay();

    // Returns the aggragated average delay (cycles) for communication src_id->dst_id
    double getAverageDelay(const int src_id, const int dst_id);

    // Returns the max delay
    double getMaxDelay();

    // Returns the max delay (cycles) experimented by destination
    // node_id. Returns -1 if node_id is not destination of any
    // communication
    double getMaxDelay(const int node_id);

    // Returns the max delay (cycles) for communication src_id->dst_id
    double getMaxDelay(const int src_id, const int dst_id);

    // Returns tha matrix of max delay for any node of the network
     vector < vector < double > > getMaxDelayMtx();

    // Returns the aggragated average throughput (flits/cycles)
    double getAverageThroughput();

    // Returns the aggragated average throughput (flits/cycles) for
    // communication src_id->dst_id
    double getAverageThroughput(const int src_id, const int dst_id);

    // Returns the total number of received packets
    unsigned int getReceivedPackets();

    // Returns the total number of received flits
    unsigned int getReceivedFlits();

    // Returns the total number of received and injectd by certine PE flits
    unsigned int getPEFlits(const int node_id);

    // Returns the maximum value of the accepted traffic
    double getThroughput();
    
    // Returns the the percentage of routers that routed through RF link			Ammar
    unsigned long  getRoutedFlitsUP();

    // Returns the total drained Broadcast flits	
    unsigned long  getBroadcastFlits();						//Ammar

    // Returns the average waiting cycles for flits to Broadcasted on SWI	
    double  getSWIwaitingCycles();						//Ammar

    // Returns the number of routed flits for each router
     vector < vector < unsigned long > > getRoutedFlitsMtx();

    // print out the over all packet deay distribution 
    void getDelayVariation();					//Ammar

    // print out the SWI channels Ideal cycles ratio  
    double getSWIidealcycles();					//Ammar

    // Returns the total power
    double getPower();
    double getincomingPower();
    double getforwardPower();
    double getstaticPower();
    double getlinkPower();
    unsigned long  getTotalHop();
    unsigned long  getTotalRFHops();
    unsigned long  getTotalHopSaving();
    unsigned long  getTransmitedFlits();
    unsigned long  getTransmitedMulticastFlits();
    unsigned long getVCTreplacedPackets();
    unsigned long getVCTmatchedPackets();
    unsigned long getVCTunmatchedPackets();
    unsigned long getMulticastCount();

    // Shows global statistics
    void showStats(std::ostream & out = std::cout, bool detailed = false);
	
    void showStats2(std::ostream & out, bool detailed);

#ifdef TESTING
    unsigned int drained_total;
#endif

  private:
    const NoximNoC *noc;
	double pwr2;
};

#endif
