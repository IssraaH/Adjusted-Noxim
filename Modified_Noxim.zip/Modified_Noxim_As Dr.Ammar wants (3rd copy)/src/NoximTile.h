/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the declaration of the tile
 */

#ifndef __NOXIMTILE_H__
#define __NOXIMTILE_H__

#include <systemc.h>
#include "NoximRouter.h"
#include "NoximProcessingElement.h"

using namespace std;

SC_MODULE(NoximTile)
{

    // I/O Ports
    sc_in_clk clock;		                // The input clock for the tile
    sc_in <bool> reset;	                        // The reset signal for the tile

    sc_in <NoximFlit> flit_rx[DIRECTIONS];	// The input channels
    sc_in <bool> req_rx[DIRECTIONS][MAX_STATIC_VC];	        //vc The requests associated with the input channels
    sc_out <bool> ack_rx[DIRECTIONS][MAX_STATIC_VC];	        ///vc The outgoing ack signals associated with the input channels

    sc_out <NoximFlit> flit_tx[DIRECTIONS];	// The output channels
    sc_out <bool> req_tx[DIRECTIONS][MAX_STATIC_VC];	        ///vc The requests associated with the output channels
    sc_in <bool> ack_tx[DIRECTIONS][MAX_STATIC_VC];	        ///vc The outgoing ack signals associated with the output channels

    sc_out <int> free_slots[DIRECTIONS][MAX_STATIC_VC];
    sc_in <int> free_slots_neighbor[DIRECTIONS][MAX_STATIC_VC];

    //connection to arbiter
    sc_out <NoximFlit> req_SWI;
    sc_in <NoximFlit> grant_SWI;

    // SWI data ports and signals
    //sc_out <NoximFlit> SWI_Master[MAX_STATIC_DIM * MAX_STATIC_DIM];
    //sc_in <NoximFlit> SWI_Slave;

    sc_in <bool> ready_rx_SWI[MAX_STATIC_VC];	/// vc The requests associated with the input channels
    sc_out <bool> ack_rx_SWI[MAX_STATIC_VC];  ///vc The outgoing ack signals associated with the input channels
    sc_out <bool> ready_tx_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];  ///vc The requests associated with the output channels
    sc_in <bool> ack_tx_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];	  ///vc The outgoing ack signals associated with the output channels

    // NoP related I/O
    sc_out < NoximNoP_data > NoP_data_out[DIRECTIONS];
    sc_in < NoximNoP_data > NoP_data_in[DIRECTIONS];

    // Signals
    sc_signal <NoximFlit> flit_rx_local;		// The input channels
    sc_signal <bool> req_rx_local[MAX_STATIC_VC];      ///vc The requests associated with the input channels
    sc_signal <bool> ack_rx_local[MAX_STATIC_VC];	///vc The outgoing ack signals associated with the input channels

    sc_signal <NoximFlit> flit_tx_local;		// The output channels
    sc_signal <bool> req_tx_local[MAX_STATIC_VC];	///vc The requests associated with the output channels
    sc_signal <bool> ack_tx_local[MAX_STATIC_VC];	///vc The outgoing ack signals associated with the output channels

    sc_signal <int> free_slots_local[MAX_STATIC_VC];
    sc_signal <int> free_slots_neighbor_local[MAX_STATIC_VC];

    sc_in < bool >  req_SWI_D[MAX_STATIC_VC];   // input of the SWI request to the local arbiter	Ammar

    sc_out < bool >  grant_SWI_D[MAX_STATIC_VC];   // input of the SWI request to the local arbiter	Ammar

    sc_out < bool >  req_SWI_D_Master[MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter	Ammar

    sc_in < bool >  grant_SWI_D_Master[MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter		Ammar

    // Instances
    NoximRouter *r;		                // Router instance
    NoximProcessingElement *pe;	                // Processing Element instance

    // Constructor

    SC_CTOR(NoximTile) {

	// Router pin assignments
//cout <<" Build Tile "<<endl;
	r = new NoximRouter("Router");
	r->clock(clock);
	r->reset(reset);
	for (int i = 0; i < DIRECTIONS; i++) 
        {
	  for (int c = 0; c < MAX_STATIC_VC ; c++) 
	  {
	    
	    r->req_rx[i][c] (req_rx[i][c]);				///vc
	    r->ack_rx[i][c] (ack_rx[i][c]);

	    
	    r->req_tx[i][c] (req_tx[i][c]);
	    r->ack_tx[i][c] (ack_tx[i][c]);

	    r->free_slots[i][c] (free_slots[i][c]);
	    r->free_slots_neighbor[i][c] (free_slots_neighbor[i][c]);

	  }
		r->flit_rx[i](flit_rx[i]);
		r->flit_tx[i] (flit_tx[i]);



	    // NoP 
	    r->NoP_data_out[i] (NoP_data_out[i]);
	    r->NoP_data_in[i] (NoP_data_in[i]);
	}

	r->flit_rx[DIRECTION_LOCAL] (flit_tx_local);
	  for (int c = 0; c < MAX_STATIC_VC ; c++) 			///vc
	  {
		r->req_rx[DIRECTION_LOCAL][c]  (req_tx_local[c] );
		r->ack_rx[DIRECTION_LOCAL][c]  (ack_tx_local[c] );

		r->req_tx[DIRECTION_LOCAL][c]  (req_rx_local[c] );
		r->ack_tx[DIRECTION_LOCAL][c]  (ack_rx_local[c] );

		r->free_slots[DIRECTION_LOCAL][c] (free_slots_local[c]);
		r->free_slots_neighbor[DIRECTION_LOCAL][c](free_slots_neighbor_local[c]);


	  }
	r->flit_tx[DIRECTION_LOCAL] (flit_rx_local);


	// Processing Element pin assignments
//cout <<" Processing Element pin assignments"<<endl;
	pe = new NoximProcessingElement("ProcessingElement");
	pe->clock(clock);
	pe->reset(reset);

	pe->flit_rx(flit_rx_local);//cout <<" binding flit_rx: "<< pe->local_id <<endl;
	for (int c = 0; c < MAX_STATIC_VC ; c++) 			///vc
	  {
	   pe->req_rx[c](req_rx_local[c]);//cout <<" binding req_rx: "<< pe->local_id <<" vc: "<< c <<endl;
	   pe->ack_rx[c](ack_rx_local[c]);//cout <<" binding ack_rx: "<< pe->local_id <<" vc: "<< c <<endl;
	
	   pe->req_tx[c](req_tx_local[c]);//cout <<" binding req_tx: "<< pe->local_id <<" vc: "<< c <<endl;
	   pe->ack_tx[c](ack_tx_local[c]);//cout <<" binding ack_tx: "<< pe->local_id <<" vc: "<< c <<endl;

   	   pe->free_slots_neighbor[c](free_slots_neighbor_local[c]);
	  }

	pe->flit_tx(flit_tx_local);//cout <<" binding flit_rx: "<< pe->local_id <<endl;

	//connections to global arbiter 
	//if(check_reserv_SW(r->local_id)!=-1)
 	{
	  r->req_SWI(req_SWI);
      	  r->grant_SWI(grant_SWI);
       	}
	//connections for the local arbiter 
	for (int c = 0; c < MAX_STATIC_VC ; c++) 
	{
	   r->req_SWI_D[c](req_SWI_D[c]);
      	   r->grant_SWI_D[c](grant_SWI_D[c]);
	}
	for (int c = 0; c < MAX_STATIC_DIM * MAX_STATIC_DIM ; c++) 
	{
	   r->req_SWI_D_Master[c](req_SWI_D_Master[c]);
      	   r->grant_SWI_D_Master[c](grant_SWI_D_Master[c]);
	}
	//connection SWI data links and signals
	/*for (int c = 0; c < MAX_STATIC_DIM * MAX_STATIC_DIM ; c++) 
	   r->SWI_Master[c](SWI_Master[c]);
	r->SWI_Slave(SWI_Slave);*/

	for (int c = 0; c < MAX_STATIC_VC ; c++) 
	{
	   r->ready_rx_SWI[c](ready_rx_SWI[c]);
      	   r->ack_rx_SWI[c](ack_rx_SWI[c]);
	}

	for (int c = 0; c < MAX_STATIC_DIM * MAX_STATIC_DIM ; c++) 
	{
	   r->ready_tx_SWI[c](ready_tx_SWI[c]);
      	   r->ack_tx_SWI[c](ack_tx_SWI[c]);
	}

	

//cout <<" buildTile 2"<< endl;
 }

};

#endif
