/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the declaration of the router
 */

#ifndef __NOXIMROUTER_H__
#define __NOXIMROUTER_H__

#include <systemc.h>
#include "NoximMain.h"
#include "NoximBuffer.h"
#include "NoximStats.h"
#include "NoximGlobalRoutingTable.h"
#include "NoximLocalRoutingTable.h"
#include "NoximReservationTable.h"
#include <queue>

using namespace std;

extern unsigned int drained_volume;

SC_MODULE(NoximRouter)
{

    // I/O Ports
    sc_in_clk clock;		                  // The input clock for the router
    sc_in <bool> reset;                           // The reset signal for the router

    sc_in <NoximFlit> flit_rx[DIRECTIONS + 1];	  // The input channels (including local one)
    sc_in <bool> req_rx[DIRECTIONS + 1][MAX_STATIC_VC];	///[MAX_STATIC_VC] vc The requests associated with the input channels
    sc_out <bool> ack_rx[DIRECTIONS + 1][MAX_STATIC_VC];  ///vc The outgoing ack signals associated with the input channels

    sc_out <NoximFlit> flit_tx[DIRECTIONS + 1];   // The output channels (including local one)
    sc_out <bool> req_tx[DIRECTIONS + 1][MAX_STATIC_VC];  ///vc The requests associated with the output channels
    sc_in <bool> ack_tx[DIRECTIONS + 1][MAX_STATIC_VC];	  ///vc The outgoing ack signals associated with the output channels


/////Distriputer arbiter and SWI data signals
    sc_in < bool >  req_SWI_D[MAX_STATIC_VC];   // input of the SWI request to the local arbiter	
    sc_out < bool >  grant_SWI_D[MAX_STATIC_VC];   // input of the SWI request to the local arbiter	
    sc_out < bool >  req_SWI_D_Master[MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter
    sc_in < bool >  grant_SWI_D_Master[MAX_STATIC_DIM * MAX_STATIC_DIM];   // input of the SWI request to the local arbiter	

    sc_in < bool > ready_rx_SWI[MAX_STATIC_VC];	/// vc The requests associated with the input channels
    sc_out < bool > ack_rx_SWI[MAX_STATIC_VC];  ///vc The outgoing ack signals associated with the input channels
    sc_out < bool > ready_tx_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];  ///vc The requests associated with the output channels
    sc_in < bool > ack_tx_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];	  ///vc The outgoing ack signals associated with the output channels

    sc_out <int> free_slots[DIRECTIONS + 1][MAX_STATIC_VC];
    sc_in <int> free_slots_neighbor[DIRECTIONS + 1][MAX_STATIC_VC];

    // Neighbor-on-Path related I/O
    sc_out < NoximNoP_data > NoP_data_out[DIRECTIONS];
    sc_in < NoximNoP_data > NoP_data_in[DIRECTIONS];

    //connection to arbiter
    sc_out <NoximFlit> req_SWI;						
    //sc_in <int> ack_rx_SWI[MAX_STATIC_DIM + 1][MAX_STATIC_DIM + 1];    
    //sc_out <int> ack_tx_SWI;
    sc_in <NoximFlit> grant_SWI;

    // SWI data ports
    //sc_out <NoximFlit> SWI_Master[MAX_STATIC_DIM * MAX_STATIC_DIM];
    //sc_in <NoximFlit> SWI_Slave;

    // Registers

    /*
       NoximCoord position;                     // Router position inside the mesh
     */
    
    int Nearest_RF;		                // nearest RF node using Dijk()			//Ammar
    int Farest_node;		                // Farest node using Dijk()			//Ammar
    int local_id;		                // Unique ID					
    int routing_type;		                // Type of routing algorithm
    int selection_type;
					// Buffer for each input channel 	+1 Ammar & add VC
    NoximBuffer buffer[DIRECTIONS + 2][MAX_STATIC_VC];  ///vc
    bool current_level_rx[DIRECTIONS + 1][MAX_STATIC_VC];	// Current level for Alternating Bit Protocol (ABP)
    bool current_level_tx[DIRECTIONS + 1][MAX_STATIC_VC];	// Current level for Alternating Bit Protocol (ABP)
    bool current_level_rx_SWI[MAX_STATIC_VC];	// Current level for Alternating Bit Protocol (ABP) SWI
    bool current_level_tx_SWI[MAX_STATIC_DIM * MAX_STATIC_DIM];	// Current level for Alternating Bit Protocol (ABP)
    //bool SWI_level_tx;			// SWI Current level for Alternating Bit Protocol (ABP) Ammar
    //bool SWI_level_rx;			// SWI Current level for Alternating Bit Protocol (ABP) Ammar
    int Wire_Busy[DIRECTIONS + 1];
    NoximStats stats;		                // Statistics
    NoximLocalRoutingTable routing_table;	// Routing table
    NoximReservationTable reservation_table;	// Switch reservation table
    int start_from_port;	                // Port from which to start the reservation cycle
    int start_from_VC;	                	/// VC from which to start the reservation cycle
    bool CB_input[DIRECTIONS + 2];		///CB flag that the input used in this cycle
    bool CB_output[DIRECTIONS + 2];		///CB flag that the output used in this cycle
    int RX_flag [DIRECTIONS + 2];		///vc flag to make sure that one flit recieved per cycle
    unsigned long routed_flits;
    int start_from_Master;	                // SWI channel from which to start the local arb.    	Ammar
    unsigned long routed_UP_flits;		//flits routed toward RF link				Ammar
    unsigned long drained_MB_flits;		//MB flits that drained 				Ammar
    unsigned long hops;				//total no. of hops	 				Ammar
    unsigned long hopFR;			//total no. of RF hops	 				Ammar
    unsigned long hop_saving;			//total no. of hops saved by RF				Ammar
    unsigned long wait_SWI_BM;                  //total no. of cycles waiting to broadcast in SWI	Ammar
    //NoximSW SW;										//   	Ammar
    unsigned long Not_Ideal;			// total number of non ideal SWI cycles			Ammar
    unsigned long Ideal;			// total number of ideal SWI cycles			Ammar
    bool TX_SWI;				// SWI transmision flag					Ammar

    // parameters for the VCT table and forking							Ammar
    bool VCTdir[MAX_STATIC_DIM*MAX_STATIC_DIM * MAX_VCT][DIRECTIONS + 1];//VCT table [VCT*source_id+VCT][output]
    bool VCT_ID[MAX_STATIC_DIM*MAX_STATIC_DIM][MAX_VCT];		//VCT table ID[source_id][VCT]
    int VCT_fork[MAX_STATIC_DIM*MAX_STATIC_DIM][MAX_VCT];		//VCT table ID[source_id][VCT]
    bool forkRes[(DIRECTIONS + 1)*MAX_STATIC_VC][DIRECTIONS + 1];//for reserve forking in VCT [input][output]
    int forkFor[(DIRECTIONS + 1)*MAX_STATIC_VC][DIRECTIONS + 2];//for forward forking in VCT [input][output+flit.sequence_no]
    int forkCounter[(DIRECTIONS + 1)*MAX_STATIC_VC];		//for count where to forward next in VCT [input]



    // Functions

    void rxProcess();		// The receiving process

    void txProcess();		// The transmitting process

    void bufferMonitor();
    void configure(const int _id, const double _warm_up_time,
		   const unsigned int _max_buffer_size,
		   NoximGlobalRoutingTable & grt);

    unsigned long getRoutedFlits();	// Returns the number of routed flits 
    unsigned long getRoutedFlitsUP();	// Returns the number of routed flits to the RF link			Ammar
    unsigned long getdrainedBroadcastFlits();// Returns the number of drained broadcast flits			Ammar
    unsigned int getFlitsCount();	// Returns the number of flits into the router
    double getPower();		        // Returns the total power dissipated by the router
    double getincomingPower();		//									Ammar
    double getforwardPower();		//									Ammar
    double getstaticPower();		//									Ammar
    double getlinkPower();		//									Ammar
    double getLocalRouterPwr(int local_id);								// Ammar
    unsigned long getTotalHops();									//	Ammar
    unsigned long getTotalRFHops();									//	Ammar
    unsigned long getTotalHopSaving();  								//Ammar
    unsigned long getSWIwaitingCycles();    								//Ammar
    double getSWIidealcycles();  								//Ammar

    bool TryWire(const int port,const int VC);
    void ReleaseWire();

    // Constructor

    SC_CTOR(NoximRouter) {



	SC_METHOD(rxProcess);
	sensitive << reset;
	sensitive << clock.pos();

	SC_METHOD(txProcess);
	sensitive << reset;
	sensitive << clock.pos();

	SC_METHOD(bufferMonitor);
	sensitive << reset;
	sensitive << clock.pos();
        



    }

  private:

    // performs actual routing + selection
    int route( NoximRouteData & route_data);
    int dist_SPF[MAX_STATIC_DIM*MAX_STATIC_DIM][4];  //distance vector from neighbors to all distinations	Ammar 
    int dist_Hop[MAX_STATIC_DIM*MAX_STATIC_DIM];     //wire hops vector from local to all distinations		Ammar   
    // wrappers
    int selectionFunction(const vector <int> &directions,
			  const NoximRouteData & route_data);
    vector < int >routingFunction(const NoximRouteData & route_data);

    // selection strategies
    int selectionRandom(const vector <int> & directions);
    int selectionBufferLevel(const vector <int> & directions);
    int selectionNoP(const vector <int> & directions,
		     const NoximRouteData & route_data);
    int selectionWRandom(const vector < int >&directions,
		     const NoximRouteData & route_data);			// add by Ammar

    // routing functions
    vector < int > SPFrouting(const int destinationS);				// add by Ammar
    void Dijk();								// add by Ammar

    vector < int >routingXY(const NoximCoord & current,
			    const NoximCoord & destination);
    vector < int >routingWestFirst(const NoximCoord & current,
				   const NoximCoord & destination);
    vector < int >routingNorthLast(const NoximCoord & current,
				   const NoximCoord & destination);
    vector < int >routingNegativeFirst(const NoximCoord & current,
				       const NoximCoord & destination);
    vector < int >routingOddEven(const NoximCoord & current,
				 const NoximCoord & source,
				 const NoximCoord & destination);
    //vector < int >routingOddEvenSW(const NoximCoord & current,				// add by Ammar
				// const NoximCoord & source,
				// const NoximCoord & destination);
    vector < int >routingDyAD(const NoximCoord & current,
			      const NoximCoord & source,
			      const NoximCoord & destination);
    vector < int >routingLookAhead(const NoximCoord & current,
				   const NoximCoord & destination);
    vector < int >routingFullyAdaptive(const NoximCoord & current,
				       const NoximCoord & destination);
    vector < int >routingTableBased(const int dir_in,
				    const NoximCoord & current,
				    const NoximCoord & destination);
    NoximNoP_data getCurrentNoPData() const;
    void NoP_report() const;
    int NoPScore(const NoximNoP_data & nop_data, const vector <int> & nop_channels) const;
    int reflexDirection(int direction) const;
    
    bool inCongestion();

  public:

    unsigned int local_drained;
    unsigned int local_injected;						// added by ammar
    unsigned int local_drained_flit;						// added by ammar
    int getNeighborId(int _id, int direction) const;
   
};

#endif
