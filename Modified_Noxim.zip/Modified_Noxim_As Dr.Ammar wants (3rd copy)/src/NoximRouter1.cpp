/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementation of the router
 */

#include "NoximRouter.h"
#include <queue>
void NoximRouter::rxProcess()
{
//cout <<"RX 1"<<endl;
int k=1;
if(NoximGlobalParams::SW_channel>0)				//where k is increase no. of dier
{ 
k=2;
//cout<<"SW_channel>0"<<k<<endl;
}
    if(int(sc_time_stamp().to_double()/1000) % NoximGlobalParams::simulation_time == 0)
    {
	local_injected=0;	 						//Ammar
	local_drained_flit=0;							//Ammar	
    }
    if (reset.read()) 	
    {
	//Clear outputs and indexes of receiving protocol
		//check_reserv_SW(local_id)=-1			//if the node is RF clear channel Ammar	
	for (int i = 0; i < DIRECTIONS+1; i++) 
	{   
	    for (int c = 0; c < NoximGlobalParams::VC_No ; c++)			
	    	{
		ack_rx[i][c].write(0);
	    	current_level_rx[i][c] = 0;
		for(int f=0;f<DIRECTIONS + 2;f++)
			forkFor[ i + (DIRECTIONS + 1)* c][f]=NOT_RESERVED;
		}
        	CB_input[i]=0;
		CB_output[i]=0;
		RX_flag [i] =0;

	}

	for(int i = 0; i < NoximGlobalParams::mesh_dim_x* NoximGlobalParams::mesh_dim_y; i++)
	{
	  for (int j = 0; j < NoximGlobalParams::EntryVCT; j++)
	  {
		for (int c = 0; c < DIRECTIONS+1 ; c++)
			VCTdir[(i*NoximGlobalParams::EntryVCT)+j][c]=0;
		VCT_ID[i][j]=0;
	  }

	}
	for(int i = 0; i < NoximGlobalParams::SW_channel; i++)
	{
	    //if (i !=check_reserv_SW(local_id))
	    {
		//cout<<"ack_rx_SWI in Rx"<<endl;
		current_level_rx_SWI[i]=0;
		ack_rx_SWI[i].write(0); 
	     }
	}
	for (int c = 0; c < NoximGlobalParams::VC_No ; c++)			///vc
		NoximGlobalParams::SW_reserve[local_id][c]=NOT_RESERVED;// clear channel reservation Ammar
	
	reservation_table.clear();
	routed_flits = 0;
	local_drained = 0;
	routed_UP_flits=0;
	drained_MB_flits=0;							//Ammar
	hops=0;									//Ammar
	hopFR=0;								//Ammar
    	hop_saving=0;								//Ammar
	wait_SWI_BM =0;								//Ammar
	Not_Ideal =0;								//Ammar
	Ideal= 0;								//Ammar
	start_from_Master =0;							//Ammar
	local_injected=0;	 						//Ammar
	local_drained_flit=0;							//Ammar
    } 
    else 
    {

	//for (int i = 0; i < DIRECTIONS+k; i++)
		//{RX_flag[i] =0;}	///vc flag to make sure that one flit recieved per cycle
						//reset the PW stats for wamup time
	// For each channel decide if a new flit can be accepted
	//
	// This process simply sees a flow of incoming flits. All arbitration
	// and wormhole related issues are addressed in the txProcess()

	for (int i = 0; i < DIRECTIONS + k ; i++) 					// add +1 by Ammar
	//{for (int c = 0; c < NoximGlobalParams::VC_No ; c++)
	{	//cout<<"flit vc"<<flit_rx[i].read().VCID<<"port"<<i<<endl;
		//		    		cout << sc_time_stamp().to_double() /
		//		1000 << ": Router[" << local_id << "], Input[" << i
		//		<< "], Received flit: " << flit_rx[i].read() << endl; 			
	    // To accept a new flit, the following conditions must match:
	    //
	    // 1) there is an incoming request 
	    // 2) there is a free slot in the input buffer of direction i
		// Rx of surface wave which should be allowed if:				Ammar
		// 1- no. of channels >0  
		// 2- there is flit waiting for this node on the channel 
		// 3- there is free slot in the input up-buffer
	    if(i==DIRECTION_UP)
	    {
		//if(local_id==0)
		//cout<<"UP "<<i<<endl;
		//it give grant to one master so check only the channel of that master if there is data ready
		int G = 1;
		int GRANTED= -1;
		if(NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB)
		{   for(int h = 0; h < NoximGlobalParams::SW_channel; h++)
		   {	
			if(grant_SWI_D[h].read())
				GRANTED=h;
		}  }  
		   if (GRANTED == -1)			//to avoid segmentation fault
		   {
			G=GRANTED;
			GRANTED=0;
		   }
		
		int Master_SWI=0;
		if(NoximGlobalParams::SW_Buf[local_id].size()!=0)//to avoid segmentation fault
		{
			Master_SWI =Master_SWI=NoximGlobalParams::SW_Buf[local_id].front().Tag;
		}
		 if (NoximGlobalParams::SW_Buf[local_id].size()!=0 &&
		 ((NoximGlobalParams::Arbitration_type != DISTRIBUTED_ARB && 
		ready_rx_SWI[Master_SWI].read() == 1- current_level_rx_SWI[Master_SWI] )|| 
		(G==1 && ready_rx_SWI[GRANTED].read() == 1- current_level_rx_SWI[GRANTED]) )  //
		    && (!buffer[i][NoximGlobalParams::SW_Buf[local_id].front().VCID].IsFull())) 
		   {
			NoximFlit received_flit = NoximGlobalParams::SW_Buf[local_id].front();
			NoximGlobalParams::SW_Buf[local_id].pop();
			if (received_flit.flit_type == FLIT_TYPE_TAIL||received_flit.size==1)
				NoximGlobalParams::SW_reserve[local_id][received_flit.VCID]=NOT_RESERVED; 
			int vi=received_flit.VCID;
			buffer[i][vi].Push(received_flit);
			grant_SWI_D[received_flit.Tag].write(0);
			
			if(NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB)
			{
			    current_level_rx_SWI[GRANTED] = 1- current_level_rx_SWI[GRANTED];
			    ack_rx_SWI[GRANTED].write(current_level_rx_SWI[GRANTED]);
			    //if(GRANTED==3 && local_id==1)
				//cout<<" change :::::: ack_rx_SWI"<<ack_rx_SWI[GRANTED].read()<<endl;
			}
			else
			{
			    current_level_rx_SWI[Master_SWI] = 1- current_level_rx_SWI[Master_SWI];
			    ack_rx_SWI[Master_SWI].write(current_level_rx_SWI[Master_SWI]);
			}
			//if(local_id==1)
			//	cout<<"grant_SWI_D[i]"<<grant_SWI_D[i]<<endl;
			start_from_Master= received_flit.Tag+1;			//round robin local arbi.
		       //NoximGlobalParams::SWI_Free_slots[local_id][vi]=buffer[i][vi].getCurrentFreeSlots();
			stats.power.Incoming(local_id);	
			if ((i==DIRECTION_LOCAL) && ((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) >
			       NoximGlobalParams::stats_warm_up_time)
				local_injected++;
			if (NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
			{
		    		cout << sc_time_stamp().to_double() /
				1000 << ": Router[" << local_id << "], Input[" << i<<"]["<<received_flit.VCID
				<<"], Received flit: " <<received_flit<<" MB: "<<received_flit.MB<< endl; 
			}
		    }
	  /*else if(local_id ==0 && i==5 && sc_time_stamp().to_double()/1000 <1060)
		{cout<<"//////// Buffer size"<< NoximGlobalParams::SW_Buf[local_id].size() << 
		 "Arbitration_type "<<NoximGlobalParams::Arbitration_type <<" G: "<< G<<" ready_rx_SWI "<<
		 ready_rx_SWI[GRANTED].read() <<" current_level_rx_SWI: "<<current_level_rx_SWI[GRANTED] <<
		 " full: "<<   buffer[i][NoximGlobalParams::SW_Buf[local_id].front().VCID].IsFull()<<endl;}*/
	    }
	   else if(flit_rx[i].read().VCID < NoximGlobalParams::VC_No && flit_rx[i].read().VCID >= 0 &&
		 (req_rx[i][flit_rx[i].read().VCID].read()==1-current_level_rx[i][flit_rx[i].read().VCID])
		   && !buffer[i][flit_rx[i].read().VCID].IsFull())//&& (RX_flag[i]==0)flit_rx[i].read().VCID
	   {
		NoximFlit received_flit = flit_rx[i].read();
		  if(NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
		   {
		    cout << sc_time_stamp().to_double() /
			1000 << ": Router[" << local_id << "], Input[" << i
			<< "]["<<received_flit.VCID<<"] Received flit: " << received_flit
			<<" MB: "<<received_flit.MB<<" MAB: "<<Bin2Integ(received_flit.MAB)<< 
			" Timestamp: "<< received_flit.timestamp<< endl;
		   }
		// Store the incoming flit in the circular buffer
		buffer[i][flit_rx[i].read().VCID].Push(received_flit);	//received_flit.VCID		

		// Negate the old value for Alternating Bit Protocol (ABP)
	        current_level_rx[i][flit_rx[i].read().VCID]=1 -current_level_rx[i][flit_rx[i].read().VCID];
		ack_rx[i][flit_rx[i].read().VCID].write(current_level_rx[i][flit_rx[i].read().VCID]);
		if ((i==DIRECTION_LOCAL)&& ((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) >
			       NoximGlobalParams::stats_warm_up_time)
				local_injected++;
		// Incoming flit
		stats.power.Incoming(local_id);
	  }	

	}//for

	//////  Local SWI arbiter //////////////////////////////////////////////////////////////////////////
	int GRANTED=0;
	for(int i = 0; i < NoximGlobalParams::SW_channel; i++)
	{
		//it give grant to one master 
	    if(grant_SWI_D[i].read())
	    {
		//if(ready_rx_SWI[i].read() != 1- current_level_rx_SWI[i])
		//	grant_SWI_D[i].write(0);
		//else
			GRANTED=1;
		//if(local_id==12)
		//	cout<<"GGGGGGGGGGGGGGGGGGGGGGGGG"<<endl;
				
	    }
	}	
	//simple round robin
	int i = 0;
	while( i < NoximGlobalParams::SW_channel && GRANTED==0)
	{
		int j = (start_from_Master + i) % NoximGlobalParams::SW_channel;
		if (req_SWI_D[j] ==1)
		{
			//if(local_id==25)
			//cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 			//             "],  send grant to Master node ID:" <<j<<endl;
			grant_SWI_D[j].write(1);

			GRANTED=1;
		}
		//else if(local_id==12 && j==4)
		//	cout<<"RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"<<endl;
		i++;
	}
	///////// End of SWI local arbiter /////////////////////////////////////////////////////////////////

     }// else not reset
	
    stats.power.Standby(local_id);
    if(((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) <NoximGlobalParams::stats_warm_up_time)
	stats.power.ClearP();
    
     //Print power of router every 10K cycle 


   /*  if((int((sc_time_stamp().to_double() /1000)-DEFAULT_RESET_TIME) % 10000 == 0) && ((sc_time_stamp().to_double() /1000) != DEFAULT_RESET_TIME))
     {
	//if (local_id ==0)
	//	cout<<endl;
	 cout << (NoximRouter::getLocalRouterPwr(local_id) )<< " ";
	stats.power.ClearLocalP(local_id);
	if (local_id == (NoximGlobalParams::mesh_dim_x* NoximGlobalParams::mesh_dim_y-1))
		cout<<endl;
     }*/

//cout <<"RX 2 "<<endl;
}

void NoximRouter::txProcess()
{
//cout <<"TX 1 "<<endl; 

int k=1;
if(NoximGlobalParams::SW_channel>0)			//where k is increase no. of dier
    {k=2;}
 //cout <<"k value: "<<k<<endl;  
if (reset.read()) 
{
	// Clear outputs and indexes of transmitting protocol
	for (int i = 0; i < DIRECTIONS + 1; i++) 
	{				
	//if(i!=5){
	Wire_Busy[i]=NOT_RESERVED;
	    for (int c = 0; c < NoximGlobalParams::VC_No ; c++)	
	    	{
		req_tx[i][c].write(0);
	    	current_level_tx[i][c] = 0;
		}
	}
	if(check_reserv_SW(local_id)!=-1)
 	{
            req_SWI=DomyFlit();
	
	    for(int i = 0; i < NoximGlobalParams::mesh_dim_x* NoximGlobalParams::mesh_dim_y; i++)
	    {
		if(i != local_id)
		{
			//cout<<"ready_tx_SWI["<<i<<"] in Tx local_id:"<<local_id<<endl;
			ready_tx_SWI[i].write(0);
	    		current_level_tx_SWI[i] = 0;
		}
	    }
	}
	//else
	//NoximGlobalParams::SW_Buf[local_id].pop();    // drain the channel Ammar
	//}
} 
else 
{
	// 1st phase: Reservation
	vector < bool > ReqVector= Integer2Bin(0);		//Req vector for the distributed arbiteration
	for (int j = 0; j < DIRECTIONS + k; j++) 		//+k       Ammar
	{
	  for (int c = 0; c < NoximGlobalParams::VC_No ; c++) 			///VC round-robin       Ammar
	  {		 							
	    int i = (start_from_port + j) % (DIRECTIONS + k);
	    int v = (start_from_VC + c) % NoximGlobalParams::VC_No;		///

	    //if(i==DIRECTION_UP){
		//if(check_reserv_SW(local_id)==-1)
		//reservation_table.invalidate(i);}         	// if not RF node desible UP   Ammar  
	     if (!buffer[i][v].IsEmpty())
	    {
    //if(local_id==1 && i==3)
//cout<<"RF buffer not empty "<<i<<endl;
		NoximFlit flit = buffer[i][v].Front();
		if (flit.flit_type == FLIT_TYPE_HEAD ) 
		{
		    // prepare data for routing
		    NoximRouteData route_data;
		    route_data.current_id = local_id;
		    route_data.src_id = flit.src_id;
		    route_data.dst_id = flit.dst_id;

		    route_data.dir_in = i;
		    route_data.MB = flit.MB;						//Ammar
		    route_data.MAB = flit.MAB;						//Ammar
		    route_data.VCTsetup = flit.VCTsetup;
    		    route_data.VCT_ID = flit.VCT_ID;
		    route_data.VCTentry = flit.VCTentry;
		    route_data.VC_in=v;
		    int o = route(route_data);

		/*if(local_id==1 && i==3 && o==2)	
			cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 		        "], Input[" << i <<"] try to reserve Output[" <<o<<"] flit: "
			<< flit <<" curently reserved to: " << reservation_table.getInputPort(i)
			<< " Timestamp: "<< flit.timestamp<< " MAB: " <<Bin2Integ(flit.MAB)<<endl;*/
		    
		    if(o != NOT_RESERVED)
		   {
		    int Channel_out = o; //(o * (DIRECTIONS + k));
		
		  //if direction is up use only VC=0 unless it is Distributed arbiteration
	            if((o==DIRECTION_UP))
		    {
			//cout<<"reserve up"<<endl;
		      if(NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB )
		      {
			//cout<<"reserve up local arb."<<endl;
			 int Channel_in=  i + (DIRECTIONS + k)* v;	///vc	
		         bool Found_VC=0;
		         int c=0;
			vector <int> out= reservation_table.getOutputPort(Channel_in);
			if(out[0]== NOT_RESERVED)
			{
		         while((Found_VC ==0) && (c < NoximGlobalParams::VC_No))	///vc
		         {
		           if (reservation_table.isAvailable(Channel_out)) 
		           {
			      //cout<<"router reserve"<<endl;			
			      reservation_table.reserve(Channel_in, Channel_out, route_data.MB, local_id);
			      Found_VC=1;
			      if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			      {
			        cout << sc_time_stamp().to_double()/1000<< ": 3 Router[" << local_id<< 
 			        "], Input["<< i <<"]["<<v<<"] channel_in "<< Channel_in <<
				"reserve Output["<<o<<"]["<<c<<"] Channel_out "<<Channel_out<<endl;
			      }
		            }

			    c++;
			    Channel_out =  o+ (DIRECTIONS + k)* c;		//Channel_out +
		         }//while
			if(Found_VC ==0)
				wait_SWI_BM =wait_SWI_BM+ Ones(flit.MAB,
					      NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
			}// end if up not reserved already
   		      }
		      else			//else if up and not distrubted arbiteration
                      {
		        if (reservation_table.isAvailable(Channel_out)) 
		         {
			  int Channel_in=  i + (DIRECTIONS + k)* v;	///vc		
			  reservation_table.reserve(Channel_in, Channel_out, route_data.MB, local_id);
			   if (NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			     cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 			    "], Input[" << i <<"]["<<v<<"] reserve Output[" <<Channel_out<<"]["<<0<<"]  "
			   <<reservation_table.isAvailable(Channel_out)<<" MAB: "<<Bin2Integ(flit.MAB)<<endl;
			   req_SWI = flit;
		         }
		       else //if(flit.MB==1)//&&(vo== NOT_RESERVED))
				wait_SWI_BM =wait_SWI_BM+ Ones(flit.MAB,
					      NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);	
    		      }
  		    }
		    // else not up and VCT but not setup packet
		    else if (NoximGlobalParams::BM_Mode==VCT && flit.MB==1 && flit.VCTsetup==0)
		    {
      		        int Channel_in=  i + (DIRECTIONS + k)* v;	///vc	
		        bool Found_VC=0;
		        int c=0;
		        while((Found_VC ==0) && (c < NoximGlobalParams::VC_No))	///vc
		        {
		            if (reservation_table.isAvailable(Channel_out)) 
		            {
			       //cout<<"router reserve"<<endl;			
			       reservation_table.reserve(Channel_in, Channel_out, route_data.MB, local_id);
			       Found_VC=1;
			        if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			       {
			         cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 			         "], Input[" << i <<"]["<<v<<"] reserve Output[" <<o<<"]["<<c<<"] "<<endl;
			       }
		            }
			    c++;
			    Channel_out =  o+ (DIRECTIONS + k)* c;		//Channel_out +
		        }//while
		        if(Found_VC==1)					//reserved done reset forking buffer
		        {
			    forkRes[Channel_in][o]=0;
			    /*if (local_id==16)//
			 	{cout<<"Fork Res: ";
				for(int j=0; j<DIRECTIONS + 1; j++)
				   cout<<forkRes[Channel_in][j];
				cout<<endl;}*/
		        }
		    }
		    else //not up and not VCT setup stage 
 		    {

			//if(local_id==19)
				//cout<<"not up and not VCT setup stage"<<endl;
			//if it is distributer arbiteration from UP to Local
			if (i ==DIRECTION_UP && o ==DIRECTION_LOCAL && 
				NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
			{
				bool Found_VC=0;
		       		int c=0;
				if(NoximGlobalParams::BM_Mode != HYBRID_ARCH)
					cout<<"!!! error wrong arch. with Dist-Arb. "<<endl;
				int Channel_out= o+ (DIRECTIONS + k)* c + (DIRECTIONS + k)
						 * NoximGlobalParams::VC_No * flit.Tag;
				int Channel_in=  i + (DIRECTIONS + k)* v + (DIRECTIONS + k)
						 * NoximGlobalParams::VC_No * flit.Tag;

				while((Found_VC ==0) && (c < NoximGlobalParams::VC_No))	///vc
		           	{
				  //if(local_id==25 && (sc_time_stamp().to_double() / 1000) <1710)
				 // cout<<"distributer arb.Channel_in: "<<Channel_in<<
				  //" Channel_out "<<Channel_out<<" currently reserved by: "<<
				   //reservation_table.getInputPort(Channel_out)<<endl;
		            	    if (reservation_table.isAvailable(Channel_out)) 
		                    {
			       		//cout<<"router reserve"<<endl;			
			       	   	reservation_table.reserve(Channel_in,Channel_out,
										    route_data.MB, local_id);
			       		Found_VC=1;
			       		 if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			       		{
			         		cout << sc_time_stamp().to_double()/1000<< ": 2 Router["
						 << local_id<< "], Input[" << i<<"]["<<v<<"] reserve Output["
 						<<o<<"]["<<c<<"] "<<" Channel_in "<<Channel_in<<
						" Channel_out "<<Channel_out<<endl;
			       		}
		            	    }
			        c++;
			        Channel_out =  o+ (DIRECTIONS + k)* c + (DIRECTIONS + k)
						 * NoximGlobalParams::VC_No * flit.Tag;	//Channel_out +
		                }//while
					
			}
			//if it is distributer arbiteration drained to Local in master node 
			else if (check_reserv_SW(local_id)!= -1 && i != DIRECTION_UP && o ==DIRECTION_LOCAL  
				&& NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
			{
				flit.Tag= check_reserv_SW(local_id);
				buffer[i][v].Update(flit);
				bool Found_VC=0;
		       		int c=0;
				if(NoximGlobalParams::BM_Mode != HYBRID_ARCH)
					cout<<"!!! error wrong arch. with Dist-Arb. "<<endl;
				int Channel_out= o+ (DIRECTIONS + k)* c + (DIRECTIONS + k)
						 * NoximGlobalParams::VC_No * flit.Tag;
				int Channel_in=  i + (DIRECTIONS + k)* v + (DIRECTIONS + k)
						 * NoximGlobalParams::VC_No * flit.Tag;
				while((Found_VC ==0) && (c < NoximGlobalParams::VC_No))	///vc
		           	{
				  //if(local_id==25 && (sc_time_stamp().to_double() / 1000) <1710)
				 // cout<<"distributer arb.Channel_in: "<<Channel_in<<
				  //" Channel_out "<<Channel_out<<" currently reserved by: "<<
				   //reservation_table.getInputPort(Channel_out)<<endl;
		            	    if (reservation_table.isAvailable(Channel_out)) 
		                    {
			       		//cout<<"router reserve"<<endl;			
			       	   	reservation_table.reserve(Channel_in,Channel_out,
										    route_data.MB, local_id);
			       		Found_VC=1;
			       		 if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			       		{
			         		cout << sc_time_stamp().to_double()/1000<< ": 1 Router["
						 << local_id<< "], Input[" << i<<"]["<<v<<"] reserve Output["
 						<<o<<"]["<<c<<"] "<<" Channel_in "<<Channel_in<<
						" Channel_out "<<Channel_out<<endl;
			       		}
		            	    }
			        c++;
			        Channel_out =  o+ (DIRECTIONS + k)* c + (DIRECTIONS + k)
						 * NoximGlobalParams::VC_No * flit.Tag;	//Channel_out +
		                }//while		
			}
		       else// if it is not distributer arbiteration  to Local
		       {
		       int Channel_in=  i + (DIRECTIONS + k)* v;	///vc			
		       bool Found_VC=0;
		       int c=0;
		       while((Found_VC ==0) && (c < NoximGlobalParams::VC_No))	///vc
		       {
		           if (reservation_table.isAvailable(Channel_out)) 
		           {
			   //cout<<"router reserve"<<endl;
			      if (NoximGlobalParams::BM_Mode==VCT && flit.MB==1 && flit.VCTsetup==1)
			      {
			          reservation_table.reserve(Channel_in, Channel_out, 0, local_id);
			          if (NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			          {
			              cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 			              "], Input[" <<i<<"]["<<v<<"] reserve Output[" <<o<<"]["<<c<<
				       "]  VCT setup"<<endl;
			          }
			       Found_VC=1;
			     }
			     else		
			         reservation_table.reserve(Channel_in, Channel_out, route_data.MB, local_id);
			     Found_VC=1;
			     if (NoximGlobalParams::verbose_mode > VERBOSE_OFF)
			     {
				  //cout<<"2 Channel_in "<<Channel_in<<" Channel_out "<<Channel_out<<endl;
			          cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 			         "], Input[" << i <<"]["<<v<<"] reserve Output[" <<o<<"]["<<c<<"]"<<endl;
			     }
		           }
			   c++;
			   Channel_out =  o+ (DIRECTIONS + k)* c;		//Channel_out +
		        }//while
			}//else not distributed arbiteration
	  	    }//else not up
		   }//!= not reserved	
		   /*else 
			for(int dd = 0; dd < DIRECTIONS + k; dd++)
				if((reservation_table.getOutputPort(dd)!=NOT_RESERVED)&&(buffer[dd].IsEmpty()))
				cout<<"this is wrong!!!!!!! empty buffer :"<<dd<<"reserve"<<reservation_table.getOutputPort(dd)<<"time "<<sc_time_stamp().to_double() / 1000<<endl<<endl; 
				/*else if(reservation_table.getOutputPort(dd)!=NOT_RESERVED)
					{NoximFlit flit2 =buffer[dd].Front();
					cout << sc_time_stamp().to_double() / 1000
					<< ": R[" << local_id
					<< "], Input[" << dd << "] (" << buffer[i].
					Size() << " flits)" << ", reserved Output["
					<< reservation_table.getOutputPort(dd) << "], flit: " << flit2<< endl;}*/
	          }//if head flit
//local arbiter

		}//not empty
	    }//for v
	}//for i


	// 2nd phase: Forwarding
	TX_SWI=0;								//flag
		//NoximRouter::ReleaseWire();
	//cout<<"forwarding"<<endl;
	for (int j = 0; j < (DIRECTIONS + k); j++) 
	for (int c = 0; c < NoximGlobalParams::VC_No ; c++) 			///VC round-robin       Ammar
	  {	
	   //int port= start_from_port	 							
	   int i = (start_from_port + j) % (DIRECTIONS + k);
	   int v = (start_from_VC + c) % NoximGlobalParams::VC_No;

	    if (!buffer[i][v].IsEmpty()) 
	    {

		NoximFlit flit = buffer[i][v].Front();
		int Channel_in;			///vc
		vector <int> out;
		int Channel_out;
		int o;				///vc 
		int vo;				///vc
		int TagedDrained=0;		//flag of drained in master 
		// in case to drain flit after broadcast it it need to to be taged with current the
		// master tag to avoid deadluck
		if ( check_reserv_SW(local_id) != -1 && i != DIRECTION_UP && ((flit.MB==1 &&
		   Need2Drain(flit.MAB)== local_id)|| (flit.dst_id==local_id && flit.MB==0))
		   && NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
		{
			flit.Tag= check_reserv_SW(local_id);
			TagedDrained=1;
		}

		if ((i ==DIRECTION_UP|| TagedDrained== 1) &&	NoximGlobalParams::Arbitration_type 
		   == DISTRIBUTED_ARB)
		{
			assert(NoximGlobalParams::BM_Mode == HYBRID_ARCH);
			Channel_in= i + (DIRECTIONS + k) * v+ (DIRECTIONS + k)
						* NoximGlobalParams::VC_No * flit.Tag;		///vc
			out = reservation_table.getOutputPort(Channel_in);

			Channel_out= out[0];
			//the next 2 lines will be neglagted if tag==0
			int Tag= Channel_out / ((DIRECTIONS + k)* NoximGlobalParams::VC_No);
			int OUT= Channel_out % ((DIRECTIONS + k)* NoximGlobalParams::VC_No);
			o= OUT % (DIRECTIONS + k);				///vc 
			vo= OUT / (DIRECTIONS + k);
			//if(local_id==25&& (sc_time_stamp().to_double() / 1000) <1700)
			//cout<<"Router["<<local_id<<"] from ["<<i<<"]["<<v<<"] ->["<<o<<"] Tag "<<Tag<<
			//" Chan_out "<<Channel_out<<" Chan_in "<<Channel_in<<" flit.Tag: "<<flit.Tag<<
			//" flit: "<<flit<<" MB "<<flit.MB<<" Need2Drain "<<Need2Drain(flit.MAB)<<endl;
			if( Channel_out != NOT_RESERVED)
			{
				assert(o == DIRECTION_LOCAL || out.size()>1 || (flit.flit_type ==
					FLIT_TYPE_HEAD && o==DIRECTION_UP && flit.MB==1 && 
					Need2Drain(flit.MAB)== local_id));
				//assert(Tag == flit.Tag);
				assert(vo >= 0 && vo < NoximGlobalParams::VC_No);
				assert(o >= 0 && o < (DIRECTIONS + k));
			}
		}
		else
		{

			Channel_in= i + (DIRECTIONS + k) * v;			///vc
			out = reservation_table.getOutputPort(Channel_in);
			Channel_out= out[0];	
			o= out[0] % (DIRECTIONS + k);				///vc 
			vo= out[0] / (DIRECTIONS + k);				///vc
			if( Channel_out != NOT_RESERVED)
			{
				assert(vo >= 0 && vo < NoximGlobalParams::VC_No);
				assert(o >= 0 && o < (DIRECTIONS + k));
			}
			//if(local_id==9)
			//cout<<"^^^^2^^^^^ i: "<<i<<" o: "<<o<<" Channel_out "<<Channel_out
			//<<" Channel_in "<<Channel_in<<" flit.Tag: "<<flit.Tag<<endl;
		}
		if (out.size()>1)//(Channel_out != NOT_RESERVED)
		   {			
		//cout<< sc_time_stamp().to_double() / 1000
		   // << ": Router[" << local_id << "] need to drained or SWI            o: "<<o<<" vo: "<<vo<<endl;
		  //if a flit is not yet broadcasted to all slaves do not drain it
		  if((flit.MB==1)&& (Need2Drain(flit.MAB)!= local_id)  && (o== DIRECTION_LOCAL) &&
		   (NoximGlobalParams::BM_Mode==HYBRID_ARCH)&&(check_reserv_SW(local_id)!=-1))	//Ammar	
			{
			o= out[1] % (DIRECTIONS + k);				///vc 
			vo= out[1] / (DIRECTIONS + k);				///vc			
			Channel_out= out[1];
			if(o!=DIRECTION_UP)
				cout<<"XXXXXXXXX Error MAB: "<<Bin2Integ(flit.MAB)<<" 2^local_id: "<< 
				((int)pow(2.0,local_id))<<" up reserved to: "<<
				reservation_table.getInputPort(DIRECTION_UP)<<endl<<endl<<endl<<endl;
			}
		   // if the broadcast flit is already broadcasted using SWI then drain it 	Ammar
		  else if((flit.MB==1)&& (Need2Drain(flit.MAB)== local_id) && (o== DIRECTION_UP) &&
		   (NoximGlobalParams::BM_Mode==HYBRID_ARCH)&&(check_reserv_SW(local_id)!=-1))	//Ammar	
			{
			o= out[1] % (DIRECTIONS + k);				///vc 
			vo= out[1] / (DIRECTIONS + k);				///vc	
			Channel_out= out[1];
			if(o!=DIRECTION_LOCAL)
				cout<<"XXXXXXXXX Error MAB: "<<Bin2Integ(flit.MAB)<<" 2^local_id: "<< 
				((int)pow(2.0,local_id))<<" up reserved to: "<<
				reservation_table.getInputPort(DIRECTION_UP)<<endl<<endl<<endl<<endl;
			}
		   }// end if out > 1

		    if((flit.MB==1)&&(NoximGlobalParams::BM_Mode==VCT)&& flit.VCTsetup==0)
			{

			if(flit.sequence_no != forkFor[Channel_in][5] 
				&& NoximGlobalParams::max_packet_size != 1)
			    {
				//cout<<"reset fork counter"<<endl;
				forkCounter[Channel_in]=0;//VCT_fork[flit.src_id][flit.VCTentry];
				forkFor[Channel_in][5]=flit.sequence_no;
			    }
			//else
			    {
				int NotYetForked=NOT_RESERVED;
				int d=0;
				while(NotYetForked==NOT_RESERVED && d< out.size()) 
				{
					int counter=0;
					for(int m=0;m<DIRECTIONS + 1;m++)
					{					
						if(forkFor[Channel_in][m]!=out[d])
							counter++;
					}
					if(counter== DIRECTIONS + 1)
						NotYetForked= d;	
					d++;
				}

				if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)
				{
				  cout<<"same flit ,Node:"<<local_id<<" in: "<<Channel_in<<" out is:";
				  for(int m=0;m<out.size();m++)
					cout << " "<<out[m];
				  cout<<"   , forkFor is: ";
				  for(int n=0; n< DIRECTIONS + k; n++)
					cout << " "<<forkFor[Channel_in][n];
				  cout<<endl;
				}
				if(NotYetForked!=NOT_RESERVED)
				{
				   Channel_out= out[NotYetForked];
				   o= out[NotYetForked] % (DIRECTIONS + k);	
				   vo= out[NotYetForked] / (DIRECTIONS + k);
				   //cout<<"NotYetForked: "<<NotYetForked;		
				}
				else
					Channel_out = NOT_RESERVED;	
			    }
			}

			/*if((flit.MB==1)&&(NoximGlobalParams::BM_Mode==VCT)&& flit.VCTsetup==0 
				&&(flit.sequence_no != forkFor[Channel_in][5]) )
			    {
				cout<<"VCT2"<<endl;
				//cout<<"reset fork counter"<<endl;
				forkCounter[Channel_in]=0;//VCT_fork[flit.src_id][flit.VCTentry];
				forkFor[Channel_in][5]=flit.sequence_no;
			    }*/

		if (out.size()>2&&!((flit.MB==1)&&(NoximGlobalParams::BM_Mode==VCT)&& flit.VCTsetup==0))
			cout<<endl<<"!!!!!!!!!!!!!!! error !!!!!!!!!!!!!!!!!!!!!"<<endl<<endl;

              /* if (Channel_out == NOT_RESERVED)					//deadlock detection
		{
			if((((sc_time_stamp().to_double() / 1000)-flit.timestamp) > 100)&&(local_id==60))
			{	cout << sc_time_stamp().to_double() / 1000
						<< ": R[" << local_id 
						<< "], Input[" << i <<
						"] Output[" << o << "], flit: "
						<< flit << " deadlock!!!!!!!!!!!!!!!!!!!!! "<<endl<<endl;
				for(int dd = 0; dd < DIRECTIONS + k; dd++)
				if(reservation_table.getOutputPort(dd)!=NOT_RESERVED)
					cout << sc_time_stamp().to_double() / 1000
					<< ": R[" << local_id
					<< "], Input[" << dd << "] (" << buffer[i][v].
					Size() << " flits)" << ", reserved Output["
					<< reservation_table.getOutputPort(dd) << "], flit: " << endl;
				cout<<endl<<endl;
			
                        sc_stop() ;
			// assert(((sc_time_stamp().to_double() / 1000)-flit.timestamp)> 5000);	
			}
		}*/
		hops+=1;
		if (Channel_out != NOT_RESERVED)
		{

		//if(local_id==25 && i==5   && (sc_time_stamp().to_double() / 1000) <1700)
		//	cout<<"^^^^^^^^^^^^^^^"<<o<<" "<<vo<<" flit: "<<flit<<endl;	
                assert(o >= 0 && o < (DIRECTIONS + k));
		assert(vo >= 0 && vo < NoximGlobalParams::VC_No);
			//cout<<"notreserved>>>>>> o: "<<o<<" vo: "<<vo<<" channelout "<<Channel_out<<" i: "<<i<<endl;
		hops+=1;

			if(o == DIRECTION_UP) 
			{ 
			  NoximFlit grant_siganl=grant_SWI.read();

			  //vc under local or global arbiteration
			  int FlitVC;
			  if(NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
				FlitVC=vo;
			  else
				FlitVC=grant_siganl.VCID;
			  //if(i==1 && local_id==6 && sc_time_stamp().to_double() / 1000 <1180)
			  //cout<<"forward up <<<<<<<<<<<<< MAB[local_id]"<<flit.MAB[local_id]<<endl;
				if(flit.MB==1)						//broadcaste
				{

				   //;if((local_id==60)&&(i==1))
				   //cout<<"broadcast up"<<" MAB[local_id]"<<flit.MAB[local_id]<<endl;
				   bool Tx =0;					//
				   flit.MB=0;
				   if((grant_siganl.timestamp == flit.timestamp && grant_siganl.src_id 
				    == flit.src_id) || NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
				   {
					for(int z=0 ; z < NoximGlobalParams::mesh_dim_x *
									 NoximGlobalParams::mesh_dim_y; z++)
					{
					if ( (z != local_id) && (z != flit.src_id) &&
					   //((NoximGlobalParams::SW_reserve[z][vo]==NOT_RESERVED)
						//||(NoximGlobalParams::SW_reserve[z][vo]==local_id))
					   (NoximGlobalParams::SW_Buf[z].size()==0)  && (flit.MAB[z]==1) 
					   && (NoximGlobalParams::SWI_Free_slots[z][FlitVC]>1  
   				   	   || NoximGlobalParams::VC_No== 1)
					   && current_level_tx_SWI[z] == ack_tx_SWI[z].read() 
					   //distributed arbiteration 
					   && (NoximGlobalParams::Arbitration_type !=DISTRIBUTED_ARB ||
					  (grant_SWI_D_Master[z].read()==1 && CB_input[i]==0 && 
					  CB_output[o]==0 )) )
					  {
						if (flit.flit_type == FLIT_TYPE_HEAD) 
							NoximGlobalParams::SW_reserve[z][vo]=local_id;
						//if(NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
							flit.Tag= check_reserv_SW(local_id);
						flit.VCID= FlitVC;
						flit.dst_id=z;
						//SWI[z].lock(); 
						NoximGlobalParams::SW_Buf[z].push(flit);
						//SWI_Master[z].write(flit);
						flit.MAB[z]=0;	
						routed_flits++; 			// Update stats
						routed_UP_flits++;
						Tx =1;
						TX_SWI=1;
						current_level_tx_SWI[z] = 1- current_level_tx_SWI[z];
						//cout<<"current_level_tx "<<current_level_tx_SWI[z]<<endl;
						//cout<<"ready_tx_SWI in Tx "<<ready_tx_SWI[z].read()<<endl;
						ready_tx_SWI[z].write(current_level_tx_SWI[z]);
						if(NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
						      cout << sc_time_stamp().to_double() / 1000 << 
						      ": Router[" << local_id << "], Input[" << i <<"]["<<
						      v<<"] forward to Output[" << o << "]["<<vo<<"] flit: "
						      << flit <<" Broadcast "<<" seq: " << flit.sequence_no
						      << " Timestamp: "<< flit.timestamp<< " MAB: " 
							<<Bin2Integ(flit.MAB) <<" ready_tx "<<
							ready_tx_SWI[z].read()<<endl;
					   }
					else
					   {
					   if(NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB 
			    		   && grant_SWI_D_Master[flit.dst_id].read()==0)
						wait_SWI_BM ++;	
						 if (NoximGlobalParams::verbose_mode > VERBOSE_OFF)//(sc_time_stamp().to_double() / 1000< 1885 && local_id==10 && z==25)
						cout<< sc_time_stamp().to_double() / 1000
						      << " XXXXXXX Do not broadcast: Router[" << local_id 
						      << "], source: "<< flit.src_id<<" SW_reserve["<<z<<"]"
						      <<NoximGlobalParams::SW_reserve[z][vo]<< " SW_Buf: "<<
							 NoximGlobalParams::SW_Buf[z].size()<< " flit.MAB: " 
						     <<flit.MAB[z]<<" CB_input "<<CB_input[i]<<" CB_output " 
						     <<CB_output[o]<<" current_level_tx_SWI "<< 
							current_level_tx_SWI[z]<<" ack_tx_SWI "
				        	    <<ack_tx_SWI[z].read()<<" grant Global: "<<
						    grant_siganl.timestamp<<"grant Local:"<< 	
						 grant_SWI_D_Master[z].read()<<" timestamp: "<<flit.timestamp
						   <<" flit.dst_id "<<flit.dst_id<< " free slots: " <<
						NoximGlobalParams::SWI_Free_slots[z][FlitVC]<<endl;
						}				
					}//end for
					if(Tx ==1)
					{
					    stats.power.Forward(local_id);
					    stats.power.Link(local_id,Farest_node,o);
					    flit.MB=1;
					    flit.Tag= 0;
					    buffer[i][v].Update(flit);
					    if( MABsize(flit.MAB) ==0)
						{
						//cout<<"pop!!!!!!!!!!!!"<<Bin2Integ(flit.MAB)<<endl;
						buffer[i][v].Pop();
						if (flit.flit_type == FLIT_TYPE_TAIL ||flit.size==1)
			    			   {
						    //release_SW_BM(local_id);	
						    reservation_table.release(Channel_out,local_id);
						    if (flit.size==1)
						    {
							flit.flit_type = FLIT_TYPE_TAIL;

						    }
						   if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)  
							cout<<"Router[" << local_id<<" ] release: "<<o <<
						       " for: "<<i<<" time: "<<sc_time_stamp().to_double()
							 / 1000<<endl;
						    req_SWI=flit;
						   }
						}
					    else if ((Need2Drain(flit.MAB)== local_id)
						&&(flit.flit_type == FLIT_TYPE_TAIL|| flit.size==1))
			    			   {
						     if(NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
						        cout<<"Router[" << local_id<<" ] release: "<<o <<
						       " for: "<<i<<" time: "<<sc_time_stamp().to_double()
							 / 1000<<endl;
						     //release_SW_BM(local_id);
						     reservation_table.release(Channel_out,local_id);
						     if (flit.size==1)
						     {
							flit.flit_type = FLIT_TYPE_TAIL; 
							//cout<<"releasing signal"<<endl;
						     }
						     req_SWI=flit;
						   }
					    //else if (Tx ==0)
					      /*cout<<"MAB ok?"<<Bin2Integ(flit.MAB)<<"  "
					        <<Bin2Integ(buffer[i][v].Front().MAB)<<endl;*/
					    CB_input[i]=1;					//vc
					    CB_output[o]=1;
				     	}
				    }//end if check grant signal
				else if (NoximGlobalParams::Arbitration_type != DISTRIBUTED_ARB &&
			        (grant_siganl.timestamp!=flit.timestamp || grant_siganl.src_id!=flit.src_id))
   			       		wait_SWI_BM =wait_SWI_BM+ Ones(flit.MAB,
					      NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y);
				}//if not multicast
			   else if((NoximGlobalParams::SW_Buf[flit.dst_id].size()==0)  
			       && (NoximGlobalParams::SWI_Free_slots[flit.dst_id][FlitVC]>1 
			       || (NoximGlobalParams::VC_No== 1 )) &&
				current_level_tx_SWI[flit.dst_id] == ack_tx_SWI[flit.dst_id].read() 
			       //distributed arbiteration 
			       && ((NoximGlobalParams::Arbitration_type != DISTRIBUTED_ARB 
			       && grant_siganl.timestamp==flit.timestamp && grant_siganl.src_id==flit.src_id)
   			       ||(grant_SWI_D_Master[flit.dst_id].read()==1 && CB_input[i]==0 &&
				 CB_output[o]==0)) )
				//(NoximGlobalParams::SW_reserve[flit.dst_id][0]==NOT_RESERVED||
				//NoximGlobalParams::SW_reserve[flit.dst_id][0]==local_id))
		        	{
					CB_input[i]=1;					//vc
					CB_output[o]=1;
					flit.VCID= FlitVC;
					//if(NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB)
						flit.Tag= check_reserv_SW(local_id);
					if (flit.flit_type == FLIT_TYPE_HEAD) 
						NoximGlobalParams::SW_reserve[flit.dst_id][0]=local_id;
					TX_SWI=1;
					NoximGlobalParams::SW_Buf[flit.dst_id].push(flit);
					buffer[i][v].Pop();
				       current_level_tx_SWI[flit.dst_id]=1-current_level_tx_SWI[flit.dst_id];
					ready_tx_SWI[flit.dst_id].write(current_level_tx_SWI[flit.dst_id]);
					//cout<<"pop!!!!!!!!!!!!"<<endl;
					routed_flits++; 			// Update stats
					routed_UP_flits++;
					NoximCoord src_coord = id2Coord(local_id);
					NoximCoord dist_coord = id2Coord(flit.dst_id);
					int xs=src_coord.x;
					int ys=src_coord.y;
					int xd=dist_coord.x;
					int yd=dist_coord.y;
					hopFR+=1;
					hop_saving+=abs(xs-xd)+abs(ys-yd)-3;
					stats.power.Forward(local_id);
					stats.power.Link(local_id , flit.dst_id, o);
 					if(NoximGlobalParams::verbose_mode > VERBOSE_OFF) 
						cout << sc_time_stamp().to_double() / 1000
						<< ": Router[" << local_id << "], Input[" << i <<
						"]["<<v<<"] forward to Output[" << o << "]["<<vo<<"], flit: "
						<< flit << " MB: "<< flit.MB <<endl;
					if (flit.flit_type == FLIT_TYPE_TAIL ||flit.size==1)
			    			{
						reservation_table.release(Channel_out,local_id);
						if (flit.size==1)
						  {
						     flit.flit_type = FLIT_TYPE_TAIL; 
							//cout<<"releasing signal"<<endl;
						  }
						  req_SWI=flit;
						//cout<<"Router[" << local_id<<" ] release: "<<o <<
						//" for: "<<i<<" time: "<<
						//sc_time_stamp().to_double() / 1000<<endl;
						}
				}
				else 
				{
				    if((NoximGlobalParams::Arbitration_type != DISTRIBUTED_ARB &&
			       (grant_siganl.timestamp!=flit.timestamp || grant_siganl.src_id!=flit.src_id))
   			       ||(grant_SWI_D_Master[flit.dst_id].read()==0 && 
				NoximGlobalParams::Arbitration_type == DISTRIBUTED_ARB))
					wait_SWI_BM ++;
				   /* if(i==1 && local_id==6)// && sc_time_stamp().to_double() / 1000 <1200)
					cout << sc_time_stamp().to_double() / 1000 << 
					": Router[" << local_id << "], Input[" << i <<
					"]["<<v<<"] XXXXXXXXXXXXXXXXXX Output[" << o << "]["<<vo <<"] flit: "
					<< flit << " MB: "<<flit.MB <<" CB_input "<<CB_input[i] 
					<<" CB_output "<<CB_output[o]<<" current_level_tx_SWI "<< 
					current_level_tx_SWI[flit.dst_id]<<" ack_tx_SWI "
				        <<ack_tx_SWI[flit.dst_id].read()<<" grant: "<<grant_siganl.timestamp
					<<" flit.time: "<<flit.timestamp<< " free slots: " 		
					<<NoximGlobalParams::SWI_Free_slots[flit.dst_id][FlitVC]<<endl;*/
				}
			   // }			
			}
		   else if ((current_level_tx[o][vo] == ack_tx[o][vo].read()
	   ||((i==DIRECTION_UP)&&(o==DIRECTION_LOCAL)&&(NoximGlobalParams::SW_channel>0)))//recieved from up 
			&& (CB_input[i]==0 && CB_output[o]==0)   
	       && ((free_slots_neighbor[o][vo].read() > 1 || o==4) || (NoximGlobalParams::VC_No== 1 ))  )
		//&& (NoximRouter::TryWire(o,vo)) )
		//&& !((local_id==4) && (o==4))  )			//creat blocking factor
		    {
		    
		//------------off_chip Or on_chip Power via wired Forwarded--------------------               //Dr. Ammar and Issraa
		
		
               NoximCoord local_coord = id2Coord(local_id); // so u can using (local_coord.x & local_coord.y)
               bool power_link_flag=0;
					     	    
              for (int h = NoximGlobalParams::mesh_dim_chip_x; h < NoximGlobalParams::mesh_dim_x;
		        h = h + NoximGlobalParams::mesh_dim_chip_x)                                          // loop to start check off_chip in X direction

		 {

	             if ((local_coord.x == h - 1 && o == DIRECTION_EAST) || (local_coord.x == h && o == DIRECTION_WEST) 
			            )// condition to check the routers on the edge

			 {
				   
				  power_link_flag= 1; // put a flag to indicate the router on the edge
				  
		        } //   end of condition to check the routers on the edge

		 } //   end of loop to check off_chip in X direction
			                 
			            
	      for (int q = NoximGlobalParams::mesh_dim_chip_y; q < NoximGlobalParams::mesh_dim_y;
		        q = q + NoximGlobalParams::mesh_dim_chip_y) // loop to start check off_chip in Y direction

	         {
			    
	             if ((local_coord.y == q - 1 && o == DIRECTION_SOUTH) || (local_coord.y == q && o == DIRECTION_NORTH) 
			         ) // condition to check the routers on the edge

		         {
				  
				power_link_flag= 1; // put a flag to indicate the router on the edge
                               

		         } //   end of condition to check the routers on the edge

		 } //   end of loop to check off_chip in Y direction
					     
		cout << sc_time_stamp().to_double() / 1000<<"Roteroffchip0 =[" << local_id <<"],flag=[" <<power_link_flag
					     << "], flit: " << flit << "delay,["
					     << flit.delay_offchip_link << "]"  << endl;     		     
	             
		                        
				     
		      if ( (flit.delay_offchip_link=-1) && (power_link_flag==1) )
			         {
			             flit.delay_offchip_link=16;
			             
			             cout << sc_time_stamp().to_double() / 1000<<"Roteroffchip1 =[" << local_id <<"],flag=[" <<power_link_flag
				     << "], flit: " << flit << "delay,["
					    << flit.delay_offchip_link << "]"  << endl;
			         }
			            			            
		     else if ((flit.delay_offchip_link<=16)&&(flit.delay_offchip_link>0))
			           
			         { 
			              
			             flit.delay_offchip_link--;
			             
			           cout << sc_time_stamp().to_double() / 1000<<"Roteroffchip2 =[" << local_id  <<"],flag=[" <<power_link_flag
				     << "], flit: " << flit << "delay,["
					    << flit.delay_offchip_link << "]"  << endl;
		                 }
		                      
		      else if ((flit.delay_offchip_link==0) || (flit.delay_offchip_link==-1)) 
		                      
		                      {
		                      
		                          if (power_link_flag==0)
				              {
				     
				               stats.power.Forward(local_id);
				               stats.power.Link(local_id, flit.dst_id, o);      // forward the flit by using off_chip power link function
				               
				               cout << sc_time_stamp().to_double() / 1000<<"Roteronchip =[" << local_id  <<"],flag=[" <<power_link_flag
					       << "], flit: " << flit << "delay,["
					       << flit.delay_offchip_link << "]"  << endl;
		                              }
 
		                         else if (power_link_flag==1)
		                              {
					 
					        flit.delay_offchip_link==-1;    
		                               stats.power.Forward(local_id);
		                               stats.power.off_chip_Link();       // forward the flit by using off_chip power link function
		                               
		                              cout << sc_time_stamp().to_double() / 1000<<"Roteroffchip3 =[" << local_id  <<"],flag=[" <<power_link_flag
					       << "], flit: " << flit << "delay,["
					        << flit.delay_offchip_link << "]"  << endl;
		               
		                              }
		                      
			//Wire_Busy[o]=vo;	
			if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)//
			 {
			    cout << sc_time_stamp().to_double() / 1000<<": Router["<<local_id<<
				"], Input["<<i<<"]["<<v<<"] forward to Output["<<o<<"]["<<vo<<"] flit: "
				<<flit<<" MB: "<<flit.MB<<" MAB: "<<Bin2Integ(flit.MAB)<<
				" VCT setup: "<<flit.VCTsetup<<" flit.time: "<<flit.timestamp<<endl;
 			 }
			if((flit.MB==1)&&(NoximGlobalParams::BM_Mode==VCT)&& flit.VCTsetup==0)
			{
				forkFor[Channel_in][forkCounter[Channel_in]]=Channel_out;
				forkCounter[Channel_in]++;
				//if(local_id==4)
				  //cout<<"update forkfor, out: "<<Channel_out<<" in: "<<Channel_in<<"forkCounter: "<<forkCounter[Channel_in]<<endl;
				
			}
			CB_input[i]=1;
			CB_output[o]=1;
			flit.VCID= vo;					///vc assigned to flit
			flit_tx[o].write(flit);
			current_level_tx[o][vo] = 1 - current_level_tx[o][vo];
			req_tx[o][vo].write(current_level_tx[o][vo]);
			// remove flit if it is not multicast flit that been broadcasted using surface wave
			// but not yet drained  other wise it need to wait			//Ammar
			if((flit.MB==1)&&(check_reserv_SW(local_id)!=-1)&&
			   (NoximGlobalParams::BM_Mode==HYBRID_ARCH)&& (o == DIRECTION_LOCAL))
			{
				flit.MAB[local_id]=0;
				//cout<<"   buffer update MAB: "<<Bin2Integ(flit.MAB)<<endl;
				if(MABsize(flit.MAB)==0)
				{
  					buffer[i][v].Pop();
					//cout<<"after drain pop"<<endl;
				}
			}
			else if((flit.MB==1)&&(NoximGlobalParams::BM_Mode==VCT&& flit.VCTsetup==0)
				&& forkCounter[Channel_in]<VCT_fork[flit.src_id][flit.VCTentry])
			{// do not pop
			//cout<<"do not pop: "<< forkCounter[Channel_in]<<" VCT_fork "<<
			//	VCT_fork[flit.src_id][flit.VCTentry]<<" src_id "<<flit.src_id<<
			//	" VCTentry "<<flit.VCTentry<<endl;
			}	
			else
			{
				buffer[i][v].Pop();
				if(NoximGlobalParams::verbose_mode > VERBOSE_OFF)
				  {cout << sc_time_stamp().to_double() / 1000<<": Router["<<local_id<<
				   "], Input["<<i<<"]["<<v<<"] poped*****"<<forkCounter[Channel_in]<<
				   " VCT_fork "<<VCT_fork[flit.src_id][flit.VCTentry]<<" VCTdir: ";
				   for(int j=0; j<DIRECTIONS + 1; j++)
				    cout<<VCTdir[(flit.src_id*NoximGlobalParams::EntryVCT)+flit.VCTentry][j];
				   cout<<endl;
				  }
				if((flit.MB==1)&&(NoximGlobalParams::BM_Mode==VCT&& flit.VCTsetup==0))
				{
				  if (flit.size==1)
					forkCounter[Channel_in]=0;
				  for(int f=0;f<DIRECTIONS + 1;f++)
					forkFor[Channel_in][f]=NOT_RESERVED;				 
				}
			}
			
			if (flit.flit_type == FLIT_TYPE_TAIL||flit.size==1)
			   { 
				reservation_table.release(Channel_out,local_id);
			      	//cout<< "Router[" << local_id<<"] release: "<<Channel_out <<" for: "
				  // <<i<<" time: "<<sc_time_stamp().to_double() / 1000<<endl;
			   }

			// Update stats
		//if (((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) >  NoximGlobalParams::stats_warm_up_time){

			if (o == DIRECTION_LOCAL) 
			{
				if(flit.MB==1 || MABsize(flit.MAB)>1)			//MB statistics
				{
				drained_MB_flits++;
				if (NoximGlobalParams::verbose_mode > VERBOSE_OFF)
				cout << sc_time_stamp().to_double() / 1000
						<< ": *** Router[" << local_id 
						<< "], Input[" << i <<
						"]["<<v<<"] forward to Output[" << o << "]["<<vo<<"], flit: "
						<< flit << endl;
				}

			    stats.receivedFlit(sc_time_stamp().to_double() / 1000, flit);
    			    if (((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) >
			       NoximGlobalParams::stats_warm_up_time)	
			    		local_drained_flit++;

			    if ((NoximGlobalParams::max_volume_to_be_drained)
				&&(((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) >
			       NoximGlobalParams::stats_warm_up_time))				
				{
				if (drained_volume >=
				    NoximGlobalParams::
				    max_volume_to_be_drained)
					{
				    NoximGlobalParams::StopTime = sc_time_stamp().to_double() / 1000;
				    sc_stop();}
				else {
				    drained_volume++;
				    local_drained++;

				     }
			        }
			} else if (i != DIRECTION_LOCAL) 
				{
			    // Increment routed flits counter
			    routed_flits++;
				}
			
		  }//else not up
		  } //else if felay=-1 or =0
		/*else if(local_id==25 && (i==5||i==3)   && (sc_time_stamp().to_double() / 1000) <1800)
			{cout<<"$$$$$$$$$$$$  free_slots_neighbor["<<o<<"]["<<vo<<"]"<<
			free_slots_neighbor[o][vo].read()
			<<" current_level_tx: "<<current_level_tx[o][vo] << " ack_tx "
			<<ack_tx[o][vo].read()<<" CB_input["<<i<<"] "<<CB_input[i]<<" CB_output "
			<<CB_output[o]<<" flit "<<flit<<endl<<endl;}  
			//{
			 /*if( ((sc_time_stamp().to_double() / 1000)-flit.timestamp) > 10000)
			 {   cout << sc_time_stamp().to_double() / 1000 << ": R[" << local_id 
                                 << "], Input[" << i <<"]["<<v<<"]-->[" << Channel_out<<"], free slot:"
				<<free_slots_neighbor[o][vo].read()<<" flit: "<<flit<< " deadlock!!!!"<<endl;
			    for(int dd = 0; dd < ((DIRECTIONS + k)*NoximGlobalParams::VC_No) ; dd++)
			    {
				
			   	vector<int> out = reservation_table.getOutputPort(dd); 
			   	int ii= dd % (DIRECTIONS + k);			
			   	int vv= dd / (DIRECTIONS + k);
				
				//if(out[0] != -2 ||(dd==0 && local_id==13))
				{	
				  cout<<"Input["<< dd <<"] (size: "<<buffer[ii][vv].Size();
				  if (!buffer[ii][vv].IsEmpty())
				  	{
					NoximFlit Flitt = buffer[ii][vv].Front();
				  	cout <<"):"<<Flitt<<" MB: "<<Flitt.MB<<" MAB: "<<
					Bin2Integ(Flitt.MAB)<<" VCT set: "<<Flitt.VCTsetup;
					cout<<", forkFor is: ";
				  	for(int n=0; n< DIRECTIONS + k; n++)
					//cout << " "<<forkFor[dd][n];
					  cout<<VCTdir[(Flitt.src_id*NoximGlobalParams::EntryVCT)
						+Flitt.VCTentry][n];
					}
				  else
					cout<<") empty, >>>";	
			   	  for(int oo=0; oo< out.size() ;oo++)
					 cout<< " ["<<out[oo]<< "] ";
				  cout <<endl;
				}
			    }
                         }
			/*if((local_id==4 && i==2 && v==0))
			 for(int dd = 0; dd < DIRECTIONS + k; dd++)
			for (int cc = 0; cc < NoximGlobalParams::VC_No ; cc++)	
				//if(reservation_table.getOutputPort(dd)!=NOT_RESERVED)
					cout << sc_time_stamp().to_double() / 1000
					<< ": R[" << local_id
					<< "], Input[" << dd << "] ["<<cc<<"](" << buffer[dd][cc].
					Size() << " flits)" << ", reserved Output["
					<< reservation_table.getOutputPort(dd + (DIRECTIONS + k) * cc) << "]"<<endl;
				cout<<endl;*/

			
			//}
		
		}//if not reserved
//////////// sending the request signales of masters to slaves local arbiters ***************************

	if (NoximGlobalParams::Arbitration_type ==DISTRIBUTED_ARB )
	{
		assert(NoximGlobalParams::BM_Mode == HYBRID_ARCH);
		int Channel_in2= i+ (DIRECTIONS+k)* v+ (DIRECTIONS + k)* NoximGlobalParams::VC_No * flit.Tag;
		int Channel_out2;
		int OUT2;
		int oo;
		vector <int> out2; 
		out2 = reservation_table.getOutputPort(Channel_in2);
		for(unsigned int q=0; q < out2.size(); q++)		//check all reserved output 
		{
		    Channel_out2 = out2[q];
		    //if( local_id==6&& i==1)
			//cout<<out2[q]<<",";
		    OUT2 = Channel_out2 % ((DIRECTIONS + k)* NoximGlobalParams::VC_No);
		    oo = OUT2 % (DIRECTIONS + k);		
		    if(oo == DIRECTION_UP)		//if one is UP send the Req
		    {
			//ReqVector = VectorOR(ReqVector, flit.MAB); 				
			//cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 			//"],  send Req vector -> flit:" <<flit<<endl;
    			for(int jj=0; jj < ReqVector.size(); jj++)
			{
				if((ReqVector[jj] || flit.MAB[jj]) && jj!=local_id)
				{
					ReqVector[jj] = 1;
					//if( local_id==54 && sc_time_stamp().to_double() / 1000<1444)
						//cout<<"XXXXXXXX jj"<<jj<<" i "<<i<<" v "<<v<<" flit " <<
						//flit <<" timestamp "<<flit.timestamp<<endl;
				}
				else
				{
					ReqVector[jj]=0;
					//if(jj==5 && local_id==6)
					// cout<<"YYYYYYYYYYYYYYYYY j:"<<jj<<" MAB[j] "<<flit.MAB[jj]<<endl;
				}
			}
		     }
			//else if( local_id==57 && out2[0]==NOT_RESERVED && ( (i==0 && v==0)) )
				//cout<< "UP not reserved "<<endl;
		}
		//if( local_id==6&& i==1)
		//cout<<"]"<<endl;
	}

//******************************************************************************************************
	    }//if buffer not empty
	}//for 
	//sending request signals to slaves in distributed arbiter//////////////////////////////////////
	for(int z=0;z<NoximGlobalParams::mesh_dim_x*NoximGlobalParams::mesh_dim_y;z++)
	{
		if(ReqVector[z]==1 && z !=local_id)
		{
			req_SWI_D_Master[z].write(1);
			//if(local_id==57 && sc_time_stamp().to_double()/1000 <1800)
			//cout << sc_time_stamp().to_double()/1000<< ": Router[" << local_id<< 
 		         //    "],  send Req to node ID:" <<z<<endl;
		}
		else
			req_SWI_D_Master[z].write(0);
	}
	////////////end local arbiter/req ////////////////////////////////////////////////////////////////
    }				// else
    stats.power.Standby(local_id);

	start_from_port++;					///vc
        start_from_VC++;					///vc

for (int i = 0; i < DIRECTIONS+k; i++)
	{
        	CB_input[i]=0;
		CB_output[i]=0;
	}
	    if(((sc_time_stamp().to_double()/1000)-DEFAULT_RESET_TIME) <NoximGlobalParams::stats_warm_up_time)
		{
		stats.power.ClearP();
		hops=0;									//Ammar
		hopFR=0;								//Ammar
    		hop_saving=0;								//Ammar
		
		}

if (TX_SWI==1)
	Not_Ideal++;		//statistics 
else
	Ideal++;		//statistics 
//cout <<"TX end"<<endl;
}

NoximNoP_data NoximRouter::getCurrentNoPData() const
{
    NoximNoP_data NoP_data;

    for (int j = 0; j < DIRECTIONS; j++) {
	NoP_data.channel_status_neighbor[j].free_slots =
	    free_slots_neighbor[j][0].read();
	NoP_data.channel_status_neighbor[j].available =
	    (reservation_table.isAvailable(j));
    }

    NoP_data.sender_id = local_id;

    return NoP_data;
}

void NoximRouter::bufferMonitor()
{
//cout <<"bufferMonitor "<<endl;

    if (reset.read()) {
	for (int i = 0; i < DIRECTIONS + 1; i++)
	  for (int c = 0; c < NoximGlobalParams::VC_No ; c++)
	    free_slots[i][c].write(buffer[i][c].GetMaxBufferSize());

         for (int c = 0; c < NoximGlobalParams::VC_No ; c++)				
		NoximGlobalParams::SWI_Free_slots[local_id][c] = buffer[DIRECTION_UP][c].GetMaxBufferSize();

    } else {
	    // update current input buffers level to neighbors

	    for (int i = 0; i < DIRECTIONS + 1; i++)
	     for (int c = 0; c < NoximGlobalParams::VC_No ; c++)
		{free_slots[i][c].write(buffer[i][c].getCurrentFreeSlots());
			//if(free_slots[i][c]>0)
				//cout<<"free slots: "<<free_slots[i][c]<<endl;
		}
	    // update free slots for SWI input buffers
	    for (int c = 0; c < NoximGlobalParams::VC_No ; c++)				
		NoximGlobalParams::SWI_Free_slots[local_id][c] = buffer[DIRECTION_UP][c].getCurrentFreeSlots();

	if (NoximGlobalParams::selection_strategy == SEL_BUFFER_LEVEL ||
	    NoximGlobalParams::selection_strategy == SEL_NOP) 
        {
	    // NoP selection: send neighbor info to each direction 'i'
	    NoximNoP_data current_NoP_data = getCurrentNoPData();

	    for (int i = 0; i < DIRECTIONS; i++)
		NoP_data_out[i].write(current_NoP_data);
	}
    }
//cout <<"bufferMonitor end"<<endl;
}

bool NoximRouter::TryWire(const int port, const int VC)					///vc
{
int k=1;
if(NoximGlobalParams::SW_channel>0)				//where k is increase no. of dier
k=2;

assert(port >= 0 && port < (DIRECTIONS + k));
assert(VC >= 0 && VC < NoximGlobalParams::VC_No);

	if(Wire_Busy[port]== NOT_RESERVED)
	{
		
		return 1;
	}
	else
		return 0;	
}

void NoximRouter::ReleaseWire()					///vc
{
//int k=1;
//if(NoximGlobalParams::SW_channel>0)				//where k is increase no. of dier 
//k=2;

//assert(port >= 0 && port < (DIRECTIONS + k));
//if(port != DIRECTION_UP )|| (NoximGlobalParams::SW_channel==0){
for (int i = 0; i < DIRECTIONS +1 ; i++) 
	{if (Wire_Busy[i]!= NOT_RESERVED)
		{
		if(current_level_tx[i][Wire_Busy[i]] == ack_tx[i][Wire_Busy[i]].read())
			Wire_Busy[i]= NOT_RESERVED;
		}
	}
//}
}

vector <int >NoximRouter::routingFunction(const NoximRouteData & route_data)
{
/*bool d=0;
for(int i=0;i < DIRECTIONS; i++)
if((2 >= dist_SPF[route_data.dst_id][i])&&(dist_SPF[route_data.dst_id][i]!=-1))
		{
		d=1;
		//cout<<"SPF direction: "<<d<<"dist"<<dist_SPF[destinationS][i]<<endl;
		}*/

	 
	//cout<<"routing"<<endl;
    NoximCoord position = id2Coord(route_data.current_id);
    NoximCoord src_coord = id2Coord(route_data.src_id);
    NoximCoord dst_coord = id2Coord(route_data.dst_id);
    int dir_in = route_data.dir_in;

    switch (NoximGlobalParams::routing_algorithm) {
    case ROUTING_XY:
	return routingXY(position, dst_coord);

    case ROUTING_WEST_FIRST:
	return routingWestFirst(position, dst_coord);

    case ROUTING_NORTH_LAST:
	return routingNorthLast(position, dst_coord);

    case ROUTING_NEGATIVE_FIRST:
	return routingNegativeFirst(position, dst_coord);

    case ROUTING_ODD_EVEN:
	return routingOddEven(position, src_coord, dst_coord);
    //case ROUTING_ODD_EVEN_SW:							// add by Ammar
	//return routingOddEvenSW(position, src_coord, dst_coord);

    case ROUTING_DYAD:
	return routingDyAD(position, src_coord, dst_coord);

    case ROUTING_FULLY_ADAPTIVE:
	return routingFullyAdaptive(position, dst_coord);

    case ROUTING_TABLE_BASED:
	return routingTableBased(dir_in, position, dst_coord);
    case ROUTING_SPF:								// add by Ammar 
	return SPFrouting(route_data.dst_id);


    default:
	assert(false);
}

    // something weird happened, you shouldn't be here
    return (vector < int >) (0);
}

int NoximRouter::route( NoximRouteData & route_data)
{
    stats.power.Routing(local_id);
   //int zx=0; 
	//if(local_id==1 && route_data.dir_in==3)	
	//cout<<"rout() MB: "<<route_data.MB<<" SW_channel "<<NoximGlobalParams::SW_channel<<" BM_Mode "<<NoximGlobalParams::BM_Mode<<endl;
   if((route_data.MB==1)&&(NoximGlobalParams::SW_channel>0)&& 
   (NoximGlobalParams::BM_Mode==HYBRID_ARCH))		//Ammar
   {

	route_data.dst_id=Nearest_RF;
	if(Nearest_RF== local_id)
		{
		
		if (Need2Drain(route_data.MAB)== local_id)
			{
			if(local_id==9  && route_data.src_id==1 && route_data.dst_id==46)
			cout<<"RRRRRRRRRR RRRRRRRRR MAB: "<<Bin2Integ(route_data.MAB)<<" 2^local_id: "<< ((int)pow(2.0,local_id))
			<<" return local"<<endl;

			return DIRECTION_LOCAL;
			}
		else
			{
			if(local_id==9  && route_data.src_id==1 && route_data.dst_id==46)
			cout<<"RRRRRRRRR RRRRRRRRRR MAB: "<<Bin2Integ(route_data.MAB)<<" 2^local_id: "<< ((int)pow(2.0,local_id))<<" return up"<<endl;
			return DIRECTION_UP;
			//cout<<"MAB: "<<Bin2Integ(route_data.MAB)<<" 2^local_id: "<< ((int)pow(2.0,local_id))
			
			}
		}
    }
    else if((route_data.MB==1)&& (NoximGlobalParams::BM_Mode==VCT))		//Ammar
    {
	if(route_data.VCTsetup==1)	//need to update the VCT entery and rout the headers as unicast
	{
	   if(route_data.VCT_ID != VCT_ID[route_data.src_id][route_data.VCTentry])
	   {
		VCT_ID[route_data.src_id][route_data.VCTentry]=route_data.VCT_ID;
		VCT_fork[route_data.src_id][route_data.VCTentry]=0;
		for (int j = 0; j < (DIRECTIONS + 1); j++) 
			VCTdir[(route_data.src_id*NoximGlobalParams::EntryVCT)+route_data.VCTentry][j]=0;
	   }
	   int S;
	   if (route_data.dst_id == local_id)
		S= DIRECTION_LOCAL;	
	   else
	   {
	   	vector < int >candidate_channels = routingFunction(route_data);
	   	S=selectionFunction(candidate_channels, route_data);
	   }
		VCTdir[(route_data.src_id*NoximGlobalParams::EntryVCT)+route_data.VCTentry][S]=1;
		int Ones=0;
	      	for(int j=0; j<DIRECTIONS + 1; j++)
		   Ones=Ones +VCTdir[(route_data.src_id*NoximGlobalParams::EntryVCT)+route_data.VCTentry][j];
		VCT_fork[route_data.src_id][route_data.VCTentry]=Ones;
	//if(VCTdir[(route_data.src_id*NoximGlobalParams::EntryVCT)+route_data.VCTentry][S]==0)
	 //VCT_fork[route_data.src_id][route_data.VCTentry]=VCT_fork[route_data.src_id][route_data.VCTentry]+1;
	/*if(local_id==16)
		{
		cout<<" VCTsetup: "<<route_data.VCTsetup<<" MB: "<<route_data.MB;
		cout<<"Node: "<<local_id<<" VCT_fork["<<route_data.src_id<<"]["<<route_data.VCTentry<<"]: "<<VCT_fork[route_data.src_id][route_data.VCTentry]<<endl<<endl<<endl;
		}*/

    	   return S;	
	}
	else 				//not setup packet routed accourding to the table
	{
	int in=route_data.dir_in+ (DIRECTIONS + 1)* route_data.VC_in;
	int Ones=0;
	vector<int> out = reservation_table.getOutputPort(in);
    	for(int j=0; j<DIRECTIONS + 1; j++)
		Ones=Ones +forkRes[in][j];
	if(Ones==0 && out[0]== NOT_RESERVED)
	{

	   //cout<<"VCT table Node: "<< local_id;
	   for (int j = 0; j < (DIRECTIONS + 1); j++) 
		{
		int dir=(route_data.src_id*NoximGlobalParams::EntryVCT)+route_data.VCTentry;
		forkRes[in][j]=VCTdir[dir][j];
		//cout<<" "<< forkRes[in][j];
		}
	   //cout<<endl;
	}
	
	int i=0;
	while( i<DIRECTIONS + 1 && forkRes[in][i]!=1)
		{
		 i++;
		}
	//cout<<"out pot: "<<i<<" forkRes: "<<forkRes[in][i]<<endl;;
	if(i==5)
		i=NOT_RESERVED;
	//assert(i<DIRECTIONS + 1 && i>=0);

	return i;
	}
    }

if (route_data.dst_id == local_id)//||((route_data.MB==1)&&(route_data.src_id != local_id)))  //Ammar
	{
	//int zx=1;
	return DIRECTION_LOCAL;	
	}
	
    vector < int >candidate_channels = routingFunction(route_data);

    return selectionFunction(candidate_channels, route_data);
}

void NoximRouter::NoP_report() const
{
    NoximNoP_data NoP_tmp;
    cout << sc_time_stamp().to_double() /
	1000 << ": Router[" << local_id << "] NoP report: " << endl;

    for (int i = 0; i < DIRECTIONS; i++) {
	NoP_tmp = NoP_data_in[i].read();
	if (NoP_tmp.sender_id != NOT_VALID)
	    cout << NoP_tmp;
    }
}

//---------------------------------------------------------------------------

int NoximRouter::NoPScore(const NoximNoP_data & nop_data,
			  const vector < int >&nop_channels) const
{
    int score = 0;

    for (unsigned int i = 0; i < nop_channels.size(); i++) {
	int available;

	if (nop_data.channel_status_neighbor[nop_channels[i]].available)
	    available = 1;
	else
	    available = 0;

	int free_slots =
	    nop_data.channel_status_neighbor[nop_channels[i]].free_slots;

	score += available * free_slots;
    }

    return score;
}

int NoximRouter::selectionNoP(const vector < int >&directions,
			      const NoximRouteData & route_data)
{
    vector < int >neighbors_on_path;
    vector < int >score;
    int direction_selected = NOT_VALID;

    int current_id = route_data.current_id;

    for (uint i = 0; i < directions.size(); i++) {
	// get id of adjacent candidate
	int candidate_id = getNeighborId(current_id, directions[i]);

	// apply routing function to the adjacent candidate node
	NoximRouteData tmp_route_data;
	tmp_route_data.current_id = candidate_id;
	tmp_route_data.src_id = route_data.src_id;
	tmp_route_data.dst_id = route_data.dst_id;
	tmp_route_data.dir_in = reflexDirection(directions[i]);


	vector < int >next_candidate_channels =
	    routingFunction(tmp_route_data);

	// select useful data from Neighbor-on-Path input 
	NoximNoP_data nop_tmp = NoP_data_in[directions[i]].read();

	// store the score of node in the direction[i]
	score.push_back(NoPScore(nop_tmp, next_candidate_channels));
    }

    // check for direction with higher score
    int max_direction = directions[0];
    int max = score[0];
    for (unsigned int i = 0; i < directions.size(); i++) {
	if (score[i] > max) {
	    max_direction = directions[i];
	    max = score[i];
	}
    }

    // if multiple direction have the same score = max, choose randomly.

    vector < int >equivalent_directions;

    for (unsigned int i = 0; i < directions.size(); i++)
	if (score[i] == max)
	    equivalent_directions.push_back(directions[i]);

    direction_selected =
	equivalent_directions[rand() % equivalent_directions.size()];

    return direction_selected;
}

int NoximRouter::selectionBufferLevel(const vector < int >&directions)
{
    vector < int >best_dirs;
    int max_free_slots = 0;
    for (unsigned int i = 0; i < directions.size(); i++) {
	int free_slots = free_slots_neighbor[directions[i]][0].read();
	bool available = reservation_table.isAvailable(directions[i]);
	if (available) {
	    if (free_slots > max_free_slots) {
		max_free_slots = free_slots;
		best_dirs.clear();
		best_dirs.push_back(directions[i]);
	    } else if (free_slots == max_free_slots)
		best_dirs.push_back(directions[i]);
	}
    }

    if (best_dirs.size())
	return (best_dirs[rand() % best_dirs.size()]);
    else
	return (directions[rand() % directions.size()]);

    //-------------------------
    // TODO: unfair if multiple directions have same buffer level
    // TODO: to check when both available
//   unsigned int max_free_slots = 0;
//   int direction_choosen = NOT_VALID;

//   for (unsigned int i=0;i<directions.size();i++)
//     {
//       int free_slots = free_slots_neighbor[directions[i]].read();
//       if ((free_slots >= max_free_slots) &&
//        (reservation_table.isAvailable(directions[i])))
//      {
//        direction_choosen = directions[i];
//        max_free_slots = free_slots;
//      }
//     }

//   // No available channel 
//   if (direction_choosen==NOT_VALID)
//     direction_choosen = directions[rand() % directions.size()]; 

//   if(NoximGlobalParams::verbose_mode>VERBOSE_OFF)
//     {
//       NoximChannelStatus tmp;

//       cout << sc_time_stamp().to_double()/1000 << ": Router[" << local_id << "] SELECTION between: " << endl;
//       for (unsigned int i=0;i<directions.size();i++)
//      {
//        tmp.free_slots = free_slots_neighbor[directions[i]].read();
//        tmp.available = (reservation_table.isAvailable(directions[i]));
//        cout << "    -> direction " << directions[i] << ", channel status: " << tmp << endl;
//      }
//       cout << " direction choosen: " << direction_choosen << endl;
//     }

//   assert(direction_choosen>=0);
//   return direction_choosen;
}

int NoximRouter::selectionRandom(const vector < int >&directions)
{
	//return 5;  
	int direction1 = directions[rand() % directions.size()]; 
	//cout<<"Router"<<local_id<<" dir: "<<direction1<<endl; 
	return direction1;
}

int NoximRouter::selectionWRandom(const vector < int >&directions,
			      const NoximRouteData & route_data)					//Ammar
{
int Max_hop=NoximGlobalParams::mesh_dim_x+ NoximGlobalParams::mesh_dim_y-2;	//-3 RF=3*wire hop
//RF dynemic weight// if dist=Max hop w=100%
//double W=100*(dist_Hop[route_data.dst_id]-2)/(double)Max_hop;			
double W=((50/(double)(Max_hop-2))*(dist_Hop[route_data.dst_id]-2))+50;

	//cout<< "Weighted random  NoximGlobalParams::RF_Weight"<<NoximGlobalParams::RF_Weight<<endl;
   if(check_reserv_SW(local_id)!=-1)
    {
	if(NoximGlobalParams::RF_Weight>0)					//if weight is given
	{
		if((rand() % 100)<  NoximGlobalParams::RF_Weight)
		{
			//cout<<" forward RF,RF_Weight, selected: "<<directions[directions.size()-1]<<endl;
			return directions[directions.size()-1];	
		}
		else
		{
			int d= directions[rand() % (directions.size()-1)];
			//cout<<" do not forward to RF,RF_Weight ,selected: "<<d<<endl;
			return d;	
		}
	}
	else				//if weight is not given then it is propotional to distance 
	{
		if((rand() % 100)<  W)
		{
			//cout<<" forward RF,propotional: "<<W<<" selected: "<<directions[directions.size()-1]<<" hops "<<dist_Hop[route_data.dst_id]<<endl;
			return directions[directions.size()-1];	
		}
		else
		{
			int d= directions[rand() % (directions.size()-1)];
			//cout<<" do not forward to RF ,propotional: "<<W<<" selected: "<<d<<endl;
			return d;	
		}
	   }
     }

  else							//if it is not RF node 
 {
  int d=directions[rand() % directions.size()];
  //cout<<" not RF ,selected: "<<d<<endl;
  return d;
 }

}


int NoximRouter::selectionFunction(const vector < int >&directions,
				   const NoximRouteData & route_data)
{
    // not so elegant but fast escape ;)
    if (directions.size() == 1)
	return directions[0];

    stats.power.Selection(local_id);
    switch (NoximGlobalParams::selection_strategy) {
    case SEL_RANDOM:
	return selectionRandom(directions);
    case SEL_BUFFER_LEVEL:
	return selectionBufferLevel(directions);
    case SEL_NOP:
	return selectionNoP(directions, route_data);
    case SEL_W_RANDOM:									//Add Ammar
	return selectionWRandom(directions, route_data);
    default:
	assert(false);
    }

    return 0;
}

vector < int >NoximRouter::routingXY(const NoximCoord & current,
				     const NoximCoord & destination)
{
    vector < int >directions;

 if((check_reserv_SW(local_id)!=-1) &&(NoximGlobalParams::SW_channel > 0))//&&(d!=1)..if node is RF return UP       Ammar
 directions.push_back(DIRECTION_UP);
  /* {
	int h=0;
	for(int j=0;j<DIRECTIONS; j++)
		{
		  int n= getNeighborId(local_id,j);
		if(n!=NOT_VALID)
		 h= 1;
		}
	if(h!=1)
	 directions.push_back(DIRECTION_UP);
   }*/

    if (destination.x > current.x)
	directions.push_back(DIRECTION_EAST);
    else if (destination.x < current.x)
	directions.push_back(DIRECTION_WEST);
    else if (destination.y > current.y)
	directions.push_back(DIRECTION_SOUTH);
    else
	directions.push_back(DIRECTION_NORTH);

    return directions;
}

vector < int >NoximRouter::routingWestFirst(const NoximCoord & current,
					    const NoximCoord & destination)
{
    vector < int >directions;

    if (destination.x <= current.x || destination.y == current.y)
	return routingXY(current, destination);

    if (destination.y < current.y) {
	directions.push_back(DIRECTION_NORTH);
	directions.push_back(DIRECTION_EAST);
    } else {
	directions.push_back(DIRECTION_SOUTH);
	directions.push_back(DIRECTION_EAST);
    }

    return directions;
}

vector < int >NoximRouter::routingNorthLast(const NoximCoord & current,
					    const NoximCoord & destination)
{
    vector < int >directions;

    if (destination.x == current.x || destination.y <= current.y)
	return routingXY(current, destination);

    if (destination.x < current.x) {
	directions.push_back(DIRECTION_SOUTH);
	directions.push_back(DIRECTION_WEST);
    } else {
	directions.push_back(DIRECTION_SOUTH);
	directions.push_back(DIRECTION_EAST);
    }

    return directions;
}

vector < int >NoximRouter::routingNegativeFirst(const NoximCoord & current,
						const NoximCoord &
						destination)
{
    vector < int >directions;

    if ((destination.x <= current.x && destination.y <= current.y) ||
	(destination.x >= current.x && destination.y >= current.y))
	return routingXY(current, destination);

    if (destination.x > current.x && destination.y < current.y) {
	directions.push_back(DIRECTION_NORTH);
	directions.push_back(DIRECTION_EAST);
    } else {
	directions.push_back(DIRECTION_SOUTH);
	directions.push_back(DIRECTION_WEST);
    }

    return directions;
}


										
vector < int >NoximRouter::routingOddEven(const NoximCoord & current,
					  const NoximCoord & source,
					  const NoximCoord & destination)
{   vector < int >directions;
    int c0 = current.x;
    int c1 = current.y;
    int s0 = source.x;
    //  int s1 = source.y;
    int d0 = destination.x;
    int d1 = destination.y;
    int e0, e1;
	/*if ((check_reserv_SW(local_id)!=-1) &&(NoximGlobalParams::SW_channel > 0))
	{
	directions.push_back(DIRECTION_UP);
	return directions;
	}*/

    e0 = d0 - c0;
    e1 = -(d1 - c1);
    
    if (e0 == 0) {
	if (e1 > 0)
	    directions.push_back(DIRECTION_NORTH);
	else
	    directions.push_back(DIRECTION_SOUTH);
    } else {
	if (e0 > 0) {
	    if (e1 == 0)
		directions.push_back(DIRECTION_EAST);
	    else {
		if ((c0 % 2 == 1) || (c0 == s0)) {
		    if (e1 > 0)
			directions.push_back(DIRECTION_NORTH);
		    else
			directions.push_back(DIRECTION_SOUTH);
		}
		if ((d0 % 2 == 1) || (e0 != 1))
		    directions.push_back(DIRECTION_EAST);
	    }
	} else {
	    directions.push_back(DIRECTION_WEST);
	    if (c0 % 2 == 0) {
		if (e1 > 0)
		    directions.push_back(DIRECTION_NORTH);
		if (e1 < 0)
		    directions.push_back(DIRECTION_SOUTH);
	    }
	}
    }

    if (!(directions.size() > 0 && directions.size() <= 3)) {
	cout << "\n PICCININI, CECCONI & ... :";	// STAMPACCHIA
	cout << source << endl;
	cout << destination << endl;
	cout << current << endl;

    }
    assert(directions.size() > 0 && directions.size() <= 3);

   if ((check_reserv_SW(local_id)!=-1) &&(NoximGlobalParams::SW_channel > 0))//if node is RF return UP       Ammar
	{
	if (directions.size()==1)
		{
		int n = getNeighborId(local_id,directions[0]); 
		if(n!=coord2Id(destination))
			  {
			   directions.push_back(DIRECTION_UP);
			   //directions.push_back(DIRECTION_UP);return directions;			
			  }
		}
	else 
	{directions.push_back(DIRECTION_UP);
         //directions.push_back(DIRECTION_UP);
	 //directions.push_back(DIRECTION_UP);
         //directions.push_back(DIRECTION_UP);
	}
       }


    return directions;
}



// *********************************************************************
vector < int >NoximRouter::routingDyAD(const NoximCoord & current,
				       const NoximCoord & source,
				       const NoximCoord & destination)
{
    vector < int >directions;

    directions = routingOddEven(current, source, destination);

    if (!inCongestion())
	directions.resize(1);

    return directions;
}

vector < int >NoximRouter::routingFullyAdaptive(const NoximCoord & current,
						const NoximCoord &
						destination)
{
    vector < int >directions;

    if (destination.x == current.x || destination.y == current.y)
	return routingXY(current, destination);

    if (destination.x > current.x && destination.y < current.y) {
	directions.push_back(DIRECTION_NORTH);
	directions.push_back(DIRECTION_EAST);
    } else if (destination.x > current.x && destination.y > current.y) {
	directions.push_back(DIRECTION_SOUTH);
	directions.push_back(DIRECTION_EAST);
    } else if (destination.x < current.x && destination.y > current.y) {
	directions.push_back(DIRECTION_SOUTH);
	directions.push_back(DIRECTION_WEST);
    } else {
	directions.push_back(DIRECTION_NORTH);
	directions.push_back(DIRECTION_WEST);
    }

    return directions;
}

vector < int >NoximRouter::routingTableBased(const int dir_in,
					     const NoximCoord & current,
					     const NoximCoord &
					     destination)
{
    NoximAdmissibleOutputs ao =
	routing_table.getAdmissibleOutputs(dir_in, coord2Id(destination));

    if (ao.size() == 0) {
	cout << "dir: " << dir_in << ", (" << current.x << "," << current.
	    y << ") --> " << "(" << destination.x << "," << destination.
	    y << ")" << endl << coord2Id(current) << "->" <<
	    coord2Id(destination) << endl;
    }

    assert(ao.size() > 0);

    //-----
    /*
       vector<int> aov = admissibleOutputsSet2Vector(ao);
       cout << "dir: " << dir_in << ", (" << current.x << "," << current.y << ") --> "
       << "(" << destination.x << "," << destination.y << "), outputs: ";
       for (int i=0; i<aov.size(); i++)
       cout << aov[i] << ", ";
       cout << endl;
     */
    //-----    

    return admissibleOutputsSet2Vector(ao);
}
  
void NoximRouter::configure(const int _id,
			    const double _warm_up_time,
			    const unsigned int _max_buffer_size,
			    NoximGlobalRoutingTable & grt)
{
//cout<< "\n\n router conf \n\n\n\n\n";
    local_id = _id;
    stats.configure(_id, _warm_up_time);

    start_from_port = DIRECTION_LOCAL;
    start_from_VC = rand()% NoximGlobalParams::VC_No;
    if (grt.isValid())
	routing_table.configure(grt, _id);

    for (int i = 0; i < DIRECTIONS + 2; i++)
	buffer[i][0].SetMaxBufferSize(_max_buffer_size);
    //if(NoximGlobalParams::routing_algorithm== ROUTING_SPF)					//Ammar
	    {
		Dijk(); 
		//cout<< "\n\n This is Wrong \n\n\n\n\n";
	}

    //cout<<endl<<"end config"<<local_id<<endl;
    
}

unsigned long NoximRouter::getRoutedFlits()						//Ammar
{
    return routed_flits;
}
unsigned long NoximRouter::getTotalHops()						//Ammar
{
    return routed_flits;
    	
}
unsigned long NoximRouter::getTotalRFHops()						//Ammar
{
    return hopFR;	
}
unsigned long NoximRouter::getTotalHopSaving()						//Ammar
{
    return hop_saving;
}

unsigned long NoximRouter::getRoutedFlitsUP()						//Ammar
{
    return routed_UP_flits;
}

unsigned long NoximRouter::getdrainedBroadcastFlits()					//Ammar
{
    return drained_MB_flits;
}

unsigned long NoximRouter::getSWIwaitingCycles()					//Ammar
{
    return wait_SWI_BM;
}

double NoximRouter::getSWIidealcycles()							//Ammar
{
    if(check_reserv_SW(local_id)!=-1)
    	return (double)Ideal/(Not_Ideal+Ideal);
    else
	return 0;
}

unsigned int NoximRouter::getFlitsCount()
{
//if(NoximGlobalParams::SW_channel>0)			//where k is increase no. of dier
//int k=2;
//else
//int k=1;
    unsigned count = 0;

    for (int i = 0; i < DIRECTIONS + 2; i++)
	count += buffer[i][0].Size();

    return count;
}


double NoximRouter::getPower()
{
    return stats.power.getPower();
}

double NoximRouter::getincomingPower()			//Ammar
{
    return stats.power.gettotalPwrIncoming();
}

double NoximRouter::getforwardPower()			//Ammar
{
    return stats.power.gettotalPwrForward();
}

double NoximRouter::getstaticPower()			//Ammar
{
    return stats.power.gettotalPwrStandBy();
}
double NoximRouter::getlinkPower()			//Ammar
{
    return stats.power.gettotalPwrlink();
}

double NoximRouter::getLocalRouterPwr( int local_id)			//Ammar
{
    return stats.power.getLocalRouterPwr(local_id);
}


int NoximRouter::reflexDirection(int direction) const
{
    if (direction == DIRECTION_NORTH)
	return DIRECTION_SOUTH;
    if (direction == DIRECTION_EAST)
	return DIRECTION_WEST;
    if (direction == DIRECTION_WEST)
	return DIRECTION_EAST;
    if (direction == DIRECTION_SOUTH)
	return DIRECTION_NORTH;

    // you shouldn't be here
    assert(false);
    return NOT_VALID;
}

int NoximRouter::getNeighborId(int _id, int direction) const
{
    NoximCoord my_coord = id2Coord(_id);

    switch (direction) {
    case DIRECTION_NORTH:
	if (my_coord.y == 0)
	    return NOT_VALID;
	my_coord.y--;
	break;
    case DIRECTION_SOUTH:
	if (my_coord.y == NoximGlobalParams::mesh_dim_y - 1)
	    return NOT_VALID;
	my_coord.y++;
	break;
    case DIRECTION_EAST:
	if (my_coord.x == NoximGlobalParams::mesh_dim_x - 1)
	    return NOT_VALID;
	my_coord.x++;
	break;
    case DIRECTION_WEST:
	if (my_coord.x == 0)
	    return NOT_VALID;
	my_coord.x--;
	break;
    default:
	cout << "direction not valid : " << direction;
	assert(false);
    }

    int neighbor_id = coord2Id(my_coord);

    return neighbor_id;
}

bool NoximRouter::inCongestion()
{
    for (int i = 0; i < DIRECTIONS; i++) {
	int flits =
	    NoximGlobalParams::buffer_depth - free_slots_neighbor[i][0];
	if (flits >
	    (int) (NoximGlobalParams::buffer_depth *
		   NoximGlobalParams::dyad_threshold))
	    return true;
    }

    return false;
}

// return direction with minmum cost to distination				written by Ammar
vector < int > NoximRouter::SPFrouting(const int destinationS)
{
//cout<<"SPF begin"<<endl;
vector < int > directions;
vector<int> dir;
int n;
int d;
bool x=0;
//int cost[4];
int mcost=9999;
	//cout<<endl<<"distance from source:"<<local_id<<endl;
	//for(int j=0;j<16; j++)
	//{cout<<endl;
	//for(int i=0;i<4; i++)
	//cout<<" "<<dist_SPF[j][i];}
if(check_reserv_SW(local_id)!=-1)				//if the node is RF return UP       Ammar
	{
	 for(int i = 0; i < 4; i++)
		{
		int nei=getNeighborId(local_id,i);
		if(destinationS==nei)	// do not use RF if destination is next hop
			{
			directions.push_back(i);
			//cout<<"push ne "<<i<<"destination "<<destinationS<<endl;
			x=1;
			}
		}
	if(x==0)						//else always use up
	   {directions.push_back(DIRECTION_UP);
	   //cout<<"push up "<<"destinationS "<<destinationS<<endl;
	   }
	}
else{
	//mcost =dist_SPF[destinationS][0];
  for(int i = 0; i < DIRECTIONS; i++)
	{
	if((mcost > dist_SPF[destinationS][i])&&(dist_SPF[destinationS][i]!=-1))
		{
		mcost=dist_SPF[destinationS][i];
		d=i;
		//cout<<"SPF direction: "<<d<<"dist"<<dist_SPF[destinationS][i]<<endl;
		}

	/*n=getNeighborId(currentS,i);
	if(n !=NOT_VALID)
		{cost[i]=Dijk(n, destinationS);
		if(mcost>cost[i])
			{mcost=cost[i];
			d=i;}
		}*/
	}
	directions.push_back(d);
	//cout<<"push SPF "<<d<<endl;
	for(int i = 0; i < DIRECTIONS; i++)		//to ensure load palancing for paths with the same cost
	if((i!=d)&&(dist_SPF[destinationS][i]==mcost))
	{
	directions.push_back(i);
	
	}	
    }
//cout<<"SPF end"<<endl;
return directions;					//else	
}


// return the shortest distance between source and distination			written by Ammar 
void NoximRouter::Dijk()
{
	int c=0;	
	int RF_nodes[NoximGlobalParams::SW_channel];
	//int dist_SPF[1000][4]; 
	int size=NoximGlobalParams::mesh_dim_x* NoximGlobalParams::mesh_dim_y;
	//cout<<"size: "<<size<<endl;
	int adj[size][size];
	//vector<int> d;
	int dist[size];
	bool visit[size];
	int nodeT;
	int dis_alt;
	//queue<int> path[size];
	for(int i=0;i<size; i++)
	for(int j=0;j<size; j++)
	  adj[i][j]=9999;
	for(int i=0;i<size; i++)		//build the graph
	{
	if(check_reserv_SW(i)!= -1)
		{
		RF_nodes[c]=i;			//find RF nodes for broadcast
		c++;
		//for(int j=0;j<size; j++) 
			//adj[i][j]=2;
		}
	for(int j=0;j<DIRECTIONS; j++)
		{
		  int n= getNeighborId(i,j);
		if(n!=NOT_VALID)
		  adj[i][n]= 1;
		}
	adj[i][i]=0;
	}
	//cout<<"end graph "<<endl;
//for(int dir=0; dir< DIRECTIONS; dir++)				//find the best direction
  { //cout<<"dir"<<dir<<endl;
    //int SourceN=getNeighborId(local_id,dir);				////find the best direction
	int SourceN= local_id;
   // if(SourceN !=NOT_VALID)						////find the best direction
    {
	for(int i=0;i<size; i++)		 // Initialization
	{  
	  visit[i]=0;				//visited nodes
	  dist[i]=9999;				//distance infenity
	}
	dist[SourceN]=0;
	//cout<<"finish  Initialization"<<endl;

	//for(int i=0;i<size; i++)
	//{cout<<endl;
	//for(int j=0;j<size; j++)
	//cout<<" "<<adj[i][j];}
						//find SPF(graph, source)	
		
	for(int i=0; i<size; i++)		// The main loop
	{
	int dis_min= 9999;
		for(int j=0;j<size; j++)
		{
		   if((dis_min>dist[j])&&(visit[j]==0))
			{
			dis_min=dist[j];
			nodeT=j;
			}		
		}
		visit[nodeT]=1;
		for(int k=0;k<size; k++)
		{
		  if(adj[nodeT][k]!=9999)			// if it is a neighbor
		  {  
			//cout<<endl<<"distance from source:"<<SourceN<<endl;
			dis_alt=adj[nodeT][k]+dist[nodeT];	
		  if(dis_alt<dist[k])				//relaxation
		    dist[k]=dis_alt;
		  }		
		}
	}
	//cout<<endl<<"main loop"<<endl;
	int dist_RF=9999;					//finding nearest RF
	int RF;
	for(int i=0; i<NoximGlobalParams::SW_channel; i++)
	{
	RF= RF_nodes[i];
		if(dist_RF > dist[RF] )
		{
			Nearest_RF=RF;
			dist_RF=dist[RF];
		}
		
	//cout<<" RF node "<<RF<<" dist: "<<dist[RF] <<" Nearest_RF "<<Nearest_RF<<endl;}
	}
	
	Farest_node= 0;							////find the farest node for multicast power
	int Far_dist=dist[Farest_node];
	for(int i=1; i<size; i++)
	{
		if(Far_dist < dist[i] )
		{
			Farest_node=i;
			Far_dist=dist[i];
		}
		
	//cout<<" RF node "<<RF<<" dist: "<<dist[RF] <<" Nearest_RF "<<Nearest_RF<<endl;}
	}
	//cout<<" node: "<< local_id<<" Farest node: "<<Farest_node<<endl;		
	//cout<<endl<<"distance from source:"<<SourceN<<endl;
	for(int i=0; i<size; i++)
		{
		dist_Hop[i]=dist[i];
		//cout<<" "<<dist_Hop[i];
		}

	//cout<<" node: "<< local_id<<" Nearest_RF "<<Nearest_RF<<endl;		////find the best direction
	//for(int i=0; i<size; i++)
		//dist_SPF[i][dir]=dist[i];
     }
    /* else
     {	
	//cout<<endl<<"not valid direction"<<endl;				////find the best direction	
	for(int i=0; i<size; i++)
		dist_SPF[i][dir]=-1;
      }*/
	//cout<<endl<<"distance from source:"<<SourceN<<endl;
	//for(int i=0;i<size; i++)
	//cout<<" "<<dist[i];
   }
	
//return dist[distinationN];
//return d;	
}	

