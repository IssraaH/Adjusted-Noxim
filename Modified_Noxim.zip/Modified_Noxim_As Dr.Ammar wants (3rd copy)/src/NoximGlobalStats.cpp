/*
 * Noxim - the NoC Simulator
 *
 * (C) 2005-2010 by the University of Catania
 * For the complete list of authors refer to file ../doc/AUTHORS.txt
 * For the license applied to these sources refer to file ../doc/LICENSE.txt
 *
 * This file contains the implementaton of the global statistics
 */

#include "NoximGlobalStats.h"

using namespace std;

NoximGlobalStats::NoximGlobalStats(const NoximNoC * _noc, const double pwr)
{
    noc = _noc;
    pwr2 = pwr;

#ifdef TESTING
    drained_total = 0;
#endif
}

double NoximGlobalStats::getAverageDelay()
{
    unsigned int total_packets = 0;
    double avg_delay = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    unsigned int received_packets =
		noc->t[x][y]->r->stats.getReceivedPackets();

	    if (received_packets) {
		avg_delay +=
		    received_packets *
		    noc->t[x][y]->r->stats.getAverageDelay();
		total_packets += received_packets;
	    }
	}

    avg_delay /= (double) total_packets;

    return avg_delay;
}

//the function provide a vector show the variation of packet delay (QoS)
void NoximGlobalStats::getDelayVariation()
{

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) 
		noc->t[x][y]->r->stats.getDelayVariation();
		
// from here

 /*  vector < int >  total_delays;
cout<<" gloabl status begin"<<endl;
    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	 	{
		cout<<"tile["<<x<<"]["<<y<<"]"<<endl;
		  //vector<int> delays=noc->t[x][y]->r->stats.getDelayVariation();
		cout<<"1 is "<<delays.size()<<"<="<<total_delays.size()<<endl;
		if(delays.size() > total_delays.size())
			{
			cout<<" delays.size() > total_delays.size()"<<endl;
			total_delays.resize(delays.size(),0);
			//for(int s=total_delays.size(); s<delays.size(); s++)
			//	total_delays.push_back(0);
			}
		cout<<"is "<<delays.size()<<"<="<<total_delays.size()<<endl;
		for (int k=0; k < delays.size(); k++)
			{
			total_delays[k] = total_delays[k] + delays[k];
			}
		}
	}
cout<<" printing"<<endl;
ofstream myfile;
myfile.open ("data.txt", ios::out | ios::app);
    for (int k=0; k < total_delays.size(); k++)
	{
	myfile << total_delays[k]<<" ; "<< "\t";
	//cout<< total_delays[k]<<" ; "<< "\t"; 
	}
cout<<" gloabl status end"<<endl;   */

// to here
    return ;
}

double NoximGlobalStats::getAverageDelay(const int src_id,
					 const int dst_id)
{
    NoximTile *tile = noc->searchNode(dst_id);

    assert(tile != NULL);

    return tile->r->stats.getAverageDelay(src_id);
}

double NoximGlobalStats::getMaxDelay()
{
    double maxd = -1.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    NoximCoord coord;
	    coord.x = x;
	    coord.y = y;
	    int node_id = coord2Id(coord);
	    double d = getMaxDelay(node_id);
	    if (d > maxd)
		maxd = d;
	}

    return maxd;
}

double NoximGlobalStats::getMaxDelay(const int node_id)
{
    NoximCoord coord = id2Coord(node_id);

    unsigned int received_packets =
	noc->t[coord.x][coord.y]->r->stats.getReceivedPackets();

    if (received_packets)
	return noc->t[coord.x][coord.y]->r->stats.getMaxDelay();
    else
	return -1.0;
}

double NoximGlobalStats::getMaxDelay(const int src_id, const int dst_id)
{
    NoximTile *tile = noc->searchNode(dst_id);

    assert(tile != NULL);

    return tile->r->stats.getMaxDelay(src_id);
}

vector < vector < double > > NoximGlobalStats::getMaxDelayMtx()
{
    vector < vector < double > > mtx;

    mtx.resize(NoximGlobalParams::mesh_dim_y);
    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	mtx[y].resize(NoximGlobalParams::mesh_dim_x);

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    NoximCoord coord;
	    coord.x = x;
	    coord.y = y;
	    int id = coord2Id(coord);
	    mtx[y][x] = getMaxDelay(id);
	}

    return mtx;
}

double NoximGlobalStats::getAverageThroughput(const int src_id,
					      const int dst_id)
{
    NoximTile *tile = noc->searchNode(dst_id);

    assert(tile != NULL);

    return tile->r->stats.getAverageThroughput(src_id);
}

double NoximGlobalStats::getAverageThroughput()
{
    unsigned int total_comms = 0;
    double avg_throughput = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    unsigned int ncomms =
		noc->t[x][y]->r->stats.getTotalCommunications();

	    if (ncomms) {
		avg_throughput +=
		    ncomms * noc->t[x][y]->r->stats.getAverageThroughput();
		total_comms += ncomms;
	    }
	}

    avg_throughput /= (double) total_comms;

    return avg_throughput;
}

unsigned int NoximGlobalStats::getReceivedPackets()
{
    unsigned int n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    n += noc->t[x][y]->r->stats.getReceivedPackets();

    return n;
}

unsigned int NoximGlobalStats::getReceivedFlits()
{
    unsigned int n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->r->stats.getReceivedFlits();
#ifdef TESTING
	    drained_total += noc->t[x][y]->r->local_drained;
#endif
	}

    return n;
}

unsigned int NoximGlobalStats::getPEFlits(const int node_id)
{
 
    NoximCoord coord = id2Coord(node_id);
    return noc->t[coord.x][coord.y]->r->local_drained+ noc->t[coord.x][coord.y]->r->local_injected;

}

unsigned long NoximGlobalStats::getTransmitedFlits()
{
   unsigned long n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->pe->total_flit_tx;

	}

    return n;
}

unsigned long NoximGlobalStats::getTransmitedMulticastFlits()
{
    unsigned long n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->pe->total_flit_tx_BM;

	}

    return n;
}

unsigned long NoximGlobalStats::getVCTmatchedPackets()
{
    unsigned long n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->pe->total_match_VCT;

	}

    return n;
}

unsigned long NoximGlobalStats::getVCTunmatchedPackets()
{
    unsigned long n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->pe->total_unmatch_VCT;

	}

    return n;
}

unsigned long NoximGlobalStats::getVCTreplacedPackets()
{
    unsigned long n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->pe->total_replace_VCT;

	}

    return n;
}

unsigned long NoximGlobalStats::getMulticastCount()
{
    unsigned long n = 0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    n += noc->t[x][y]->pe->MulticastCount;

	}

    return n;
}

double NoximGlobalStats::getThroughput()
{
    int total_cycles =
	NoximGlobalParams::simulation_time -
	NoximGlobalParams::stats_warm_up_time;          //note of Dr. Ameer
	
	// cout << "\t"<< "Total cycles: "<<total_cycles << "\t" << endl;    //issraa_try
	

    //  int number_of_ip = NoximGlobalParams::mesh_dim_x * NoximGlobalParams::mesh_dim_y;
    //  return (double)getReceivedFlits()/(double)(total_cycles * number_of_ip);

    unsigned int n = 0;
    unsigned int trf = 0;
    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++) {
	    unsigned int rf = noc->t[x][y]->r->stats.getReceivedFlits();

	    if (rf != 0)
		n++;

	    trf += rf;
	}

    return (double) trf / (double) (total_cycles * n);

}

vector < vector < unsigned long > > NoximGlobalStats::getRoutedFlitsMtx()
{

    vector < vector < unsigned long > > mtx;

    mtx.resize(NoximGlobalParams::mesh_dim_y);
    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	mtx[y].resize(NoximGlobalParams::mesh_dim_x);

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    mtx[y][x] = noc->t[x][y]->r->getRoutedFlits();

    return mtx;
}

unsigned long  NoximGlobalStats::getRoutedFlitsUP()						//Ammar
{
    unsigned long  routedflitsUP=0;
    NoximCoord coord;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	coord.x =x;
	coord.y =y;
	routedflitsUP+= noc->t[x][y]->r->getRoutedFlitsUP();
	}

    return routedflitsUP;
}

unsigned long  NoximGlobalStats::getBroadcastFlits()						//Ammar
{
    unsigned long  Broad_flits=0;
    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	Broad_flits+= noc->t[x][y]->r->getdrainedBroadcastFlits();
	}

    //if (NoximGlobalParams::BM_Mode==HYBRID_ARCH)
    	return Broad_flits;
    //else if(NoximGlobalParams::BM_Mode==UNICAST	)
	//return Broad_flits; //(NoximGlobalParams::mesh_dim_y*NoximGlobalParams::mesh_dim_x);
}
unsigned long  NoximGlobalStats::getTotalHop()						//Ammar
{
    unsigned long  Broad_flits=0;
    NoximCoord coord;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	coord.x =x;
	coord.y =y;
	Broad_flits+= noc->t[x][y]->r->getTotalHops();
	}
 
    return Broad_flits;
}

unsigned long  NoximGlobalStats::getTotalRFHops()						//Ammar
{
    unsigned long  Broad_flits=0;
    NoximCoord coord;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	coord.x =x;
	coord.y =y;
	Broad_flits+= noc->t[x][y]->r->getTotalRFHops();
	}

    return Broad_flits;
}

unsigned long  NoximGlobalStats::getTotalHopSaving()						//Ammar
{
    unsigned long  Broad_flits=0;
    NoximCoord coord;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	coord.x =x;
	coord.y =y;
	Broad_flits+= noc->t[x][y]->r->getTotalHopSaving();
	}

    return Broad_flits;
}

double  NoximGlobalStats::getSWIwaitingCycles()						//Ammar
{
    double  avg_wait_cycle=0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	   avg_wait_cycle+= noc->t[x][y]->r->getSWIwaitingCycles();
	  // cout<<"wait_cycle"<<avg_wait_cycle<<endl;  //issraa_try
	   
	}
  if(NoximGlobalParams::SW_channel>0)  
    return avg_wait_cycle/(double)(NoximGlobalParams::SW_channel);
  else
	cout<<"error getSWIwaiting cycles"<<endl;
}

double  NoximGlobalStats::getSWIidealcycles()						//Ammar
{
    double  avg_Ideal_cycle=0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	{
	avg_Ideal_cycle+= noc->t[x][y]->r->getSWIidealcycles();
	}
  if(NoximGlobalParams::SW_channel>0)  
    return avg_Ideal_cycle/(double)(NoximGlobalParams::SW_channel);
  else
	cout<<"error getSWIwaiting cycles"<<endl;
}


double NoximGlobalStats::getPower()
{
    double power = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    power += noc->t[x][y]->r->getPower();

    if (NoximGlobalParams::SW_channel>0)		//add global arbiter power 		Ammar
    	power += pwr2;

    return power;
}


double NoximGlobalStats::getincomingPower()
{
    double power = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    power += noc->t[x][y]->r->getincomingPower();

    return power;
}
double NoximGlobalStats::getforwardPower()
{
    double power = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    power += noc->t[x][y]->r->getforwardPower();

    return power;
}
double NoximGlobalStats::getstaticPower()
{
    double power = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    power += noc->t[x][y]->r->getstaticPower() ;

    return power;
}

double NoximGlobalStats::getlinkPower()
{
    double power = 0.0;

    for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
	    power += noc->t[x][y]->r->getlinkPower();

    return power;
}

void NoximGlobalStats::showStats(std::ostream & out, bool detailed)
{
    out << "% Total received packets: " << getReceivedPackets() << endl;
    out << "% Total received flits: " << getReceivedFlits() << endl;
    out << "% Total transmited flits: " << getTransmitedFlits()<< endl;
    out << "% Global average delay (cycles): " << getAverageDelay() <<
	endl;
    out << "% Global average throughput (flits/cycle): " <<
	getAverageThroughput() << endl;
    out << "% Throughput (flits/cycle/IP): " << getThroughput() << endl;
    out << "% Max delay (cycles): " << getMaxDelay() << endl;
    out << "% Total energy (J): " << getPower() << endl;

    if (detailed) {
	out << endl << "detailed = [" << endl;
	for (int y = 0; y < NoximGlobalParams::mesh_dim_y; y++)
	    for (int x = 0; x < NoximGlobalParams::mesh_dim_x; x++)
		noc->t[x][y]->r->stats.showStats(y *
						 NoximGlobalParams::
						 mesh_dim_x + x, out,
						 true);
	out << "];" << endl;

	// show MaxDelay matrix
	vector < vector < double > > md_mtx = getMaxDelayMtx();

	out << endl << "max_delay = [" << endl;
	for (unsigned int y = 0; y < md_mtx.size(); y++) {
	    out << "   ";
	    for (unsigned int x = 0; x < md_mtx[y].size(); x++)
		out << setw(6) << md_mtx[y][x];
	    out << endl;
	}
	out << "];" << endl;

	// show RoutedFlits matrix
	vector < vector < unsigned long > > rf_mtx = getRoutedFlitsMtx();

	out << endl << "routed_flits = [" << endl;
	for (unsigned int y = 0; y < rf_mtx.size(); y++) {
	    out << "   ";
	    for (unsigned int x = 0; x < rf_mtx[y].size(); x++)
		out << setw(10) << rf_mtx[y][x];
	    out << endl;
	}
	out << "];" << endl;
    }

}

void NoximGlobalStats::showStats2(std::ostream & out, bool detailed)
{
  cout<< "\t" << getAverageDelay() << "\t" << getThroughput()<< "\t"<<getReceivedFlits()<< "\t"<<getPower()<<";"<<endl;
 


//  cout <<getVCTreplacedPackets() << "\t" << getVCTmatchedPackets()<< "\t"<<getVCTunmatchedPackets() <<endl;

//getDelayVariation();

//cout<<NoximGlobalParams::StopTime<< ": \t" <<"SWI average waiting"<< "\t"<<getSWIwaitingCycles()<<" Broadcast rate: "<<getBroadcastFlits()/(float)getReceivedFlits()*100<<"% \t MB-RX: "<< getBroadcastFlits()<<"\t MB-TX: "<<getTransmitedMulticastFlits()<<" multicast count: "<<getMulticastCount()<<" Ideal ratio: "<<getSWIidealcycles() << " Flits routed through SWI: " << getRoutedFlitsUP()<<endl;
//cout << getAverageDelay() << "\t" << getRoutedFlitsUP()/(float)getReceivedFlits()*100<< "\t"<<getTotalHopSaving()/(float)getTotalHop()*100<< "\t"<<getPower()<<";"<<endl;
//cout<<" RF use rate: "<<getRoutedFlitsUP()/(float)getReceivedFlits()*100<<"%"<<" Broadcast rate: "<<getBroadcastFlits()/(float)getReceivedFlits()*100<<"%"<<endl ;
//cout<<"incoming %: "<<getincomingPower()/getPower()*100<<"  forward %: "<<getforwardPower()/getPower()*100<<"  standby %: "<<getstaticPower()/getPower()*100<<"link %: "<<getlinkPower()/getPower()*100<<endl;
 //cout<<" total hops : "<<getTotalHop()<<" hops using RF %: "<<getTotalRFHops()/(float)getTotalHop()*100<<"  hops saved using RF %: "<<getTotalHopSaving()/(float)getTotalHop()*100<<endl;
  
 }

